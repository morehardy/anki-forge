---
asset_refs:
  - schema/package-build-result.schema.json
  - schema/writer-policy.schema.json
  - schema/build-context.schema.json
---

# Build

Local reference source anchors under `docs/source/rslib`:

- `docs/source/rslib/src/import_export/package/apkg/export.rs`
- `docs/source/rslib/src/import_export/package/colpkg/export.rs`
- `docs/source/rslib/src/import_export/package/meta.rs`
- `docs/source/rslib/src/import_export/package/media.rs`

Phase 3 build semantics use a staging-first materialization flow before optional
`.apkg` packaging. The reference source below constrains how package metadata,
collection payloads, and media payloads should align with modern Anki package
format behavior.

The reference source defines two closely related package export paths:

- `export_apkg` creates a temporary collection file, gathers media filenames,
  packages the collection and media through `export_collection()`, and
  atomically renames the temporary archive into place.
- `export_colpkg` closes the collection at the legacy or latest schema version,
  then calls `export_collection_file()`, which writes `meta`, the versioned
  collection payload, a dummy legacy `collection.anki2`, media files, and the
  `media` map into the archive.

In `meta.rs`, package version determines the collection filename, supported
schema version, zstd compression usage, and whether the `media` listing is
encoded as a legacy JSON hashmap or as structured media entries.

For latest APKG output, the writer emits package metadata version 3, a zstd-compressed
`collection.anki21b`, a schema11 dummy `collection.anki2`, zstd-compressed media
payloads, and a zstd-compressed protobuf `MediaEntries` map. The latest collection is
constructed directly as a V18-compatible SQLite database using vendored schema anchors;
it is not a byte-for-byte replay of Anki's full Rust upgrade path. Note row `flds`
stores normalized field values as HTML-ready Anki field text separated by U+001F.
The writer does not HTML-escape normalized fields again. `sfld` is derived from
the field marked as the notetype sort field, or the first notetype field when no
field is marked. `csum` follows Anki/rslib duplicate-check behavior: it is always
the SHA-1 first four bytes of the first notetype field after HTML stripping, even
when `sfld` comes from another sort field. The HTML stripping step removes tags,
comment bodies, script/style bodies, and decodes HTML entities while preserving
filenames from `img`, `audio`, `video`, `source`, and `object` `src`/`data`
attributes. `notes.mod` uses explicit `notes[].mtime_secs` when supplied and
deterministic fallback `1` otherwise; callers that need chronological APKG
reimport updates must supply `mtime_secs`.

Writer media payloads are read from the content-addressed media store. Staging
media files are copy/reflink-derived inspect artifacts and are not the writer's
source of truth. The writer validates normalized media invariants and CAS object
integrity, but media semantics such as unused bindings, missing references,
unsafe references, and MIME mismatch are normalization responsibilities.

In `media.rs`, imported media filenames are safety-checked and normalized, and
archives that omit the `media` entry are treated as a legacy-compatible empty
media map during import rather than as an immediate error.

For `Phase 5A`, the writer also preserves product-layer template metadata:

- field-label metadata lowers into authoring field metadata and is carried into
  staged and packaged output
- browser appearance declarations are carried onto matching templates during
  lowering and preserved through build materialization
- note deck names and template target deck names are resolved into one stable
  package deck registry during staging and APKG materialization
- template configs only receive a nonzero/resolved `target_deck_id` from
  `template.target_deck_name`; templates without deck override keep Anki's
  native `0`/none target-deck representation
- card rows use Anki's routing order:
  `template.target_deck_name ?? note.deck_name`; this keeps per-note deck
  import semantics separate from template deck override semantics
- card rows use normalized template ordinals for Anki card ordinals and are
  emitted only when the template generation requirement is satisfied by the
  note's stripped, non-empty field values
