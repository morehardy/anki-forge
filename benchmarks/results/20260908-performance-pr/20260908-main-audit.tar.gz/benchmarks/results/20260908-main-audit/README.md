# 2026-09-08 main 性能审计证据

主报告：[main 性能复核与优化方案](../../../docs/superpowers/specs/2026-09-08-main-performance-audit.md)。当前运行时基线为 `c665271b0af9ec7badd2be57b516bf58afac15cd`；本目录是本地探索性审计，不是跨平台性能承诺。

- `audit.png` / `audit.svg`：从归档样本生成的图；`SHA256SUMS`：本目录全部证据的最终校验清单。
- `summary.json`：正式计时/RSS分别汇总、全部样本值、阶段比例与HTML完整格。
- `matrix/`：20格 Rust/genanki 原始尝试、完整产物核验、固定 Anki 导入与供电。
- `runs/`：扩展输入、API、稳定身份比较、流式原型与持久同步诊断。每次计划含输入/二进制/基线哈希。
- `verification/`、`comparison-equivalence.json`：27个补充独立产物、所有成功尝试的精确哈希绑定，以及compare的唯一预期guid来源变化。
- `api-source/`、`api-initial-source/`、两份 `*-source.patch`、`build-*.json`：私有原型和插桩源码身份。正式库未修改。
- `completion.json`、`quality-summary.json`、`logs.tar.gz`：完成条件、功能验证与原始日志，包括环境调整/预算停止/夹具失败。
- `scripts/`：实际使用过的脚本，保留历史失败流程；重放时应先读主报告的失败说明。原 `run_more.py` 的匿名compare预热失败，修正后的比较在 `run_api.py`。不应把历史脚本不加区分地顺序执行。

## 本机复现

恢复同一源码和锁文件，按 `benchmarks/README.md` 准备工具。当前标准矩阵可用：

```sh
benchmarks/.venv/bin/python benchmarks/.work/main-audit-20260908/guarded_matrix.py \
  --name NEW-UNUSED-NAME --inputs benchmarks/.work/readme-comparison/fixtures
```

其余输入身份在 `cases.json`，9个补充形状沿用此前 `remaining-opportunities` / `post-streaming-audit` 归档的生成脚本。本次没有重生成或改写这些冻结夹具。跨机器重放需要恢复并核对这些输入及对应媒体，不能只复制JSON而丢失相对媒体路径。

脚本按 `benchmarks/.work/<audit>/` 定位仓库根，归档内路径用于证据审阅；执行前复制到新的独立 `.work` 目录并修正记录中的本机路径。先编译并冻结正式/私有二进制，结束编译和功能测试，再按计划顺序计时。API比较必须带相同的稳定项目ID、匹配基线与Complete断言；所有验证/Anki导入在计时之后完成。

不使用诊断进程的时间/RSS当正式得分，不混合时间和RSS轮次，不把不同会话的绝对耗时相减。HTML 32KiB公开导出格只有两次正式样本且触发预算，没有完整中位数。比较包与普通包的GUID来源元数据预期不同，不能强制整包等同。

原生 collector 有效导出为 2,044 次；HTML 单进程函数探针另有 45 次公开导出调用，计时范围不同。`write_report.py` 是初稿生成脚本，最终 Markdown 已经过后续编辑校对；`render_chart.py` 可在原工作目录结构中重建图。
