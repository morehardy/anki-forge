# Media export benchmark

Timing: 10 independent processes per cell; RSS: 5 separate processes.

| Profile | Notes | Rust ms | genanki ms | Time reduction | Rust RSS MiB | genanki RSS MiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| basic-audio-unique-v2 | 100 | 45.284 | 139.177 | 67.5% | 18.75 | 28.42 |
| basic-audio-unique-v2 | 200 | 65.801 | 161.242 | 59.2% | 20.92 | 29.05 |
| basic-audio-unique-v2 | 500 | 120.730 | 229.125 | 47.3% | 27.84 | 31.80 |
| basic-audio-unique-v2 | 1000 | 212.092 | 341.017 | 37.8% | 39.06 | 36.33 |
| basic-image-unique-v2 | 100 | 51.529 | 143.787 | 64.2% | 19.80 | 28.17 |
| basic-image-unique-v2 | 200 | 73.391 | 170.918 | 57.1% | 22.22 | 28.95 |
| basic-image-unique-v2 | 500 | 138.368 | 256.200 | 46.0% | 28.48 | 31.67 |
| basic-image-unique-v2 | 1000 | 251.415 | 398.209 | 36.9% | 39.59 | 36.08 |
| basic-mixed-shared-v2 | 100 | 41.582 | 129.759 | 68.0% | 19.03 | 28.17 |
| basic-mixed-shared-v2 | 200 | 44.163 | 130.471 | 66.2% | 20.88 | 28.55 |
| basic-mixed-shared-v2 | 500 | 63.925 | 138.055 | 53.7% | 25.98 | 29.91 |
| basic-mixed-shared-v2 | 1000 | 90.233 | 149.363 | 39.6% | 34.33 | 33.09 |
| basic-mixed-text-v1 | 100 | 30.572 | 117.130 | 73.9% | 14.09 | 28.02 |
| basic-mixed-text-v1 | 200 | 35.478 | 119.582 | 70.3% | 15.83 | 28.52 |
| basic-mixed-text-v1 | 500 | 51.663 | 125.957 | 59.0% | 20.89 | 29.70 |
| basic-mixed-text-v1 | 1000 | 75.840 | 136.418 | 44.4% | 29.83 | 32.44 |
| basic-mixed-unique-v2 | 100 | 45.028 | 135.036 | 66.7% | 19.19 | 28.20 |
| basic-mixed-unique-v2 | 200 | 58.434 | 153.095 | 61.8% | 21.41 | 29.20 |
| basic-mixed-unique-v2 | 500 | 106.613 | 209.548 | 49.1% | 27.78 | 31.44 |
| basic-mixed-unique-v2 | 1000 | 187.260 | 303.213 | 38.2% | 37.59 | 34.97 |

Cells meeting the proposed 30% reduction: 20/20.

All successful samples passed original SQLite row/template and exact media payload checks. Anki evidence, when enabled, covers one package per cell/adapter. No GUI or audible playback is checked.
