"""Add persistent-media diagnosis to the existing PRIVATE coarse source tree.

Generation only: this script never builds, measures, or edits production files.
The original measured stage source is copied and hash-verified before any edit.
Run once after ongoing measurements finish, then build the private manifest.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil


WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
SRC = WORK / "profile-source"
ORIGINAL = WORK / "stages-original-source"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tree_hashes(root):
    return {
        str(path.relative_to(root)): sha(path)
        for path in sorted(root.rglob("*"))
        if path.is_file() and "target" not in path.relative_to(root).parts
    }


def edit(file, old, new):
    path = SRC / file
    text = path.read_text()
    assert text.count(old) == 1, (file, old, text.count(old))
    path.write_text(text.replace(old, new))


def accum_function(file, function, label):
    path = SRC / "anki_forge/src" / file
    text = path.read_text()
    matches = list(re.finditer(r"\bfn " + re.escape(function) + r"\s*(?:<[^\n]*>)?\s*\(", text))
    assert len(matches) == 1, (file, function, len(matches))
    offset = text.index("{", matches[0].end()) + 1
    text = text[:offset] + f'\n    let _audit_persistent_total = crate::diag::Accum::new("{label}");' + text[offset:]
    path.write_text(text)


DIAGNOSTICS = '''
// Accumulate on the calling thread: no per-file logging or shared mutex.
// The retained CAS-ingest and staging-copy paths currently run on main.
use std::{cell::RefCell, collections::BTreeMap};
thread_local! {
    static PERSISTENT_TOTALS: RefCell<BTreeMap<&'static str, (u128, usize)>> =
        const { RefCell::new(BTreeMap::new()) };
}
pub struct Accum(&'static str, Instant);
impl Accum {
    pub fn new(label: &'static str) -> Self { Self(label, Instant::now()) }
}
impl Drop for Accum {
    fn drop(&mut self) {
        let elapsed = self.1.elapsed().as_nanos();
        PERSISTENT_TOTALS.with(|totals| {
            let mut totals = totals.borrow_mut();
            let total = totals.entry(self.0).or_default();
            total.0 += elapsed;
            total.1 += 1;
        });
    }
}
pub fn report_persistent() {
    PERSISTENT_TOTALS.with(|totals| {
        for (label, (elapsed, count)) in std::mem::take(&mut *totals.borrow_mut()) {
            eprintln!("[DEBUG-scale-opt] {} {}", label, elapsed);
            eprintln!("[DEBUG-post-audit-count] {} {}", label, count);
        }
    });
}
pub struct PersistentReport;
impl Drop for PersistentReport {
    fn drop(&mut self) { report_persistent(); }
}
'''


def main():
    assert SRC.is_dir(), f"Missing existing coarse source: {SRC}"
    assert not ORIGINAL.exists(), f"Refusing to overwrite {ORIGINAL}"
    assert not (WORK / "persistent-probe-source.json").exists()
    production_before = tree_hashes(ROOT / "anki_forge")
    before = tree_hashes(SRC)
    recorded = json.loads((WORK / "build-stages.json").read_text())
    assert before == recorded["source_sha256"], "Coarse source no longer matches its measured build"
    shutil.copytree(SRC, ORIGINAL, ignore=shutil.ignore_patterns("target"))
    assert tree_hashes(ORIGINAL) == before, "Original stage snapshot differs"
    (WORK / "stages-original-source-evidence.json").write_text(json.dumps({
        "source_sha256": before,
        "build_record": recorded,
        "build_record_sha256": sha(WORK / "build-stages.json"),
        "coarse_probe_source_record_sha256": sha(WORK / "probe-source.json"),
        "snapshot": str(ORIGINAL),
    }, indent=2) + "\n")

    diag = SRC / "anki_forge/src/diag.rs"
    assert "struct Accum" not in diag.read_text()
    diag.write_text(diag.read_text() + DIAGNOSTICS)

    adapter = "benchmarks/adapters/rust/src/main.rs"
    # Construct the dump guard first so it runs after adapter.total's guard on
    # success, Result errors, and unwinding. Fatal abort/SIGKILL cannot dump.
    edit(adapter,
         '    let _audit_total = anki_forge::diag::Scope::new("adapter.total");',
         '    let _audit_persistent_report = anki_forge::diag::PersistentReport;\n'
         '    let _audit_total = anki_forge::diag::Scope::new("adapter.total");')
    edit(adapter,
         "        deck.write_apkg(output)?.ensure_success()?;",
         '        match std::env::var("ANKI_AUDIT_MODE").unwrap_or_else(|_| "deck".into()).as_str() {\n'
         '            "deck" => { deck.write_apkg(output)?.ensure_success()?; }\n'
         '            "persistent" => {\n'
         '                deck.build(BuildOptions::new().output(output)\n'
         '                    .artifacts_dir(Path::new(output).parent().context("output parent")?.join("retained")))?\n'
         '                    .ensure_success()?;\n'
         '            }\n'
         '            mode => bail!("unsupported private coarse probe mode: {mode}"),\n'
         '        }')

    accum_function("authoring_core/media_io.rs", "ingest_media_read_source_to_cas", "persistent.cas_ingest_total")
    accum_function("writer_core/media.rs", "copy_verified_cas_object_to_path", "persistent.staging_copy_total")
    # Only the sync call is timed: flush, hashing, read/write, error mapping,
    # cleanup, and rename remain outside these two inner intervals.
    edit("anki_forge/src/authoring_core/media_io.rs",
         "    temp.as_file()\n        .sync_all()\n        .map_err(|err| MediaIoError::CasWrite {",
         "    let audit_sync_result = {\n"
         '        let _audit_sync = crate::diag::Accum::new("persistent.cas_sync");\n'
         "        temp.as_file().sync_all()\n"
         "    };\n"
         "    audit_sync_result.map_err(|err| MediaIoError::CasWrite {")
    edit("anki_forge/src/writer_core/media.rs",
         "    if let Err(err) = output.sync_all() {",
         "    let audit_sync_result = {\n"
         '        let _audit_sync = crate::diag::Accum::new("persistent.staging_sync");\n'
         "        output.sync_all()\n"
         "    };\n"
         "    if let Err(err) = audit_sync_result {")

    for path in SRC.rglob("*"):
        if path.is_file() and "target" not in path.relative_to(SRC).parts:
            os.utime(path, None)
    assert tree_hashes(ORIGINAL) == before, "Original coarse source changed"
    assert tree_hashes(ROOT / "anki_forge") == production_before, "Production source changed"
    (WORK / "persistent-probe-source.json").write_text(json.dumps({
        "script_sha256": sha(Path(__file__)),
        "source_sha256": tree_hashes(SRC),
        "original_source_snapshot": str(ORIGINAL),
        "original_build_binary_sha256": recorded["binary_sha256"],
        "production_source_sha256": production_before,
        "mode": "ANKI_AUDIT_MODE=persistent; fresh output-parent/retained directory per invocation",
        "manifest": str(SRC / "benchmarks/adapters/rust/Cargo.toml"),
        "scopes": {
            "persistent.cas_ingest_total": "Sum of main-thread CAS ingest calls, inclusive of cas_sync; nested in normalize.core.",
            "persistent.cas_sync": "Only temp.as_file().sync_all calls; excludes flush, map_err and rename.",
            "persistent.staging_copy_total": "Sum of main-thread verified CAS-to-staging copies, inclusive of staging_sync; nested in writer.staging.",
            "persistent.staging_sync": "Only output.sync_all calls; excludes validation, map_err, cleanup and rename.",
        },
        "counts": "DEBUG-post-audit-count records attempted calls, including a failed sync or failed enclosing call.",
        "interpretation": "All timings are inclusive elapsed wall time. Never add an inner sync interval to its enclosing ingest/copy or coarse scope. Native exporter time includes final log dumping; adapter.total excludes dumping.",
        "limitations": "Main-thread totals only; no per-file logs. This diagnoses fresh retained-artifact builds, not reuse of an existing artifact directory or storage durability guarantees.",
    }, indent=2) + "\n")
    print("Persistent private probe source prepared; no build or workload executed.")


if __name__ == "__main__":
    main()
