from pathlib import Path
import shutil
W=Path(__file__).resolve().parent
shutil.copytree(W/'api-source',W/'api-initial-source')
shutil.copy2(W/'build-api.json',W/'build-api-before-stream64.json')
shutil.copy2(W/'binaries/api',W/'binaries/api-before-stream64')
p=W/'api-source/src/main.rs'; s=p.read_text()
old='        "persistent" => {'
new='''        "stream64-prototype" => {
            let scratch = Path::new(output).with_extension("private.apkg");
            let report = deck.write_apkg(&scratch)?;
            report.ensure_success()?;
            let artifact = report.artifact.as_ref().context("missing artifact")?;
            let mut source = std::fs::File::open(artifact.path())?;
            let mut destination = std::fs::File::create(output)?;
            let mut buffer = [0_u8; 64 * 1024];
            loop {
                let count = match std::io::Read::read(&mut source, &mut buffer) {
                    Ok(n) => n,
                    Err(err) if err.kind() == std::io::ErrorKind::Interrupted => continue,
                    Err(err) => return Err(err.into()),
                };
                if count == 0 { break; }
                std::io::Write::write_all(&mut destination, &buffer[..count])?;
            }
            std::fs::remove_file(&scratch)?;
        },
'''+old
assert s.count(old)==1; p.write_text(s.replace(old,new))
