from pathlib import Path
import difflib,hashlib,json,shutil,tarfile
W=Path(__file__).resolve().parent; R=W.parents[2]; D=R/'benchmarks/results/20260908-main-audit'; D.mkdir(exist_ok=False)
M=R/'benchmarks/.work/runs/main-audit-20260908-matrix'
for p in W.glob('*.json'): shutil.copy2(p,D/p.name)
for name in ['html-complexity.jsonl','html-complexity.stderr']:
    shutil.copy2(W/name,D/name)
S=D/'scripts'; S.mkdir()
for p in W.glob('*.py'): shutil.copy2(p,S/p.name)
for p in W.glob('*.sh'): shutil.copy2(p,S/p.name)
for name in ['extra-timing','extra-rss','stages','api-timing','api-rss','compare-timing','compare-rss','stream-timing','stream-rss','persistent-stages-check','api-failed-missing-project-id']:
    dest=D/'runs'/name; dest.mkdir(parents=True)
    for file in ['plan.json','attempts.jsonl','launches.jsonl','summary.json']:
        if (W/name/file).is_file(): shutil.copy2(W/name/file,dest/file)
(D/'matrix').mkdir()
for name in ['manifest.json','attempts.jsonl','verified.jsonl','power.jsonl','summary.json','report.md']:
    if (M/name).is_file(): shutil.copy2(M/name,D/'matrix'/name)
with tarfile.open(D/'matrix/verification.tar.gz','w:gz') as tar:
    for p in sorted(M.rglob('*')):
        if p.name in ['verification.json','anki.json','oracle.stdout.log','oracle.stderr.log']:
            tar.add(p,arcname=str(p.relative_to(M)))
shutil.copytree(W/'verification',D/'verification')
for name in ['api-source','api-initial-source']:
    shutil.copytree(W/name,D/name)
for name in ['stages-original-source','profile-source']:
    source=W/name; changes=[]
    for folder in ['anki_forge','benchmarks/adapters/rust']:
        for p in sorted((source/folder).rglob('*.rs')):
            rel=p.relative_to(source); original=R/rel
            a=original.read_text().splitlines(keepends=True) if original.exists() else []
            b=p.read_text().splitlines(keepends=True)
            if a!=b: changes.extend(difflib.unified_diff(a,b,fromfile='a/'+str(rel),tofile='b/'+str(rel)))
    (D/(name+'.patch')).write_text(''.join(changes))
with tarfile.open(D/'logs.tar.gz','w:gz') as tar:
    for p in W.glob('*.log'): tar.add(p,arcname=p.name)
    for folder in [p for p in W.iterdir() if p.is_dir() and ((p/'attempts.jsonl').exists())]:
        for p in folder.rglob('*.log'): tar.add(p,arcname=str(p.relative_to(W)))
# Frozen baseline validation is retained without generated APKG bytes.
for name in ['baselines','update-baselines']:
    dest=D/name; dest.mkdir()
    for p in (W/name).glob('*.json'): shutil.copy2(p,dest/p.name)
print(D)
