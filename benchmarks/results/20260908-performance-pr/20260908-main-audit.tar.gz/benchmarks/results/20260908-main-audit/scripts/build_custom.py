from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
W=Path(__file__).resolve().parent; R=W.parents[2]
name=sys.argv[1]; source=W/('api-source' if name=='api' else 'profile-source'); manifest=source/('Cargo.toml' if name=='api' else 'benchmarks/adapters/rust/Cargo.toml')
binary=R/'benchmarks/adapters/rust/target/release/anki-forge-benchmark'
cmd=['cargo','build','--release','--locked','--offline','--manifest-path',str(manifest)]
env=dict(os.environ,CARGO_TARGET_DIR=str(R/'benchmarks/adapters/rust/target'))
for p in source.rglob('*'):
    if p.is_file(): os.utime(p,None)
started=time.monotonic()
try:
    with (W/f'build-{name}.log').open('w') as log: subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    shutil.copy2(binary,W/'binaries'/name)
    (W/f'build-{name}.json').write_text(json.dumps({'command':cmd,'elapsed_s':time.monotonic()-started,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_sha256':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}},indent=2)+'\n')
    print(name,'built',round(time.monotonic()-started,2),flush=True)
finally:
    shutil.copy2(W/'binaries/current',binary)
    assert hashlib.sha256(binary.read_bytes()).digest()==hashlib.sha256((W/'binaries/current').read_bytes()).digest()
