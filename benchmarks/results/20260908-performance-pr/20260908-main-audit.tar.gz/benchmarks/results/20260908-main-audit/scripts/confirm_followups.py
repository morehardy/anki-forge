from pathlib import Path
import shutil,subprocess
W=Path(__file__).resolve().parent; R=W.parents[2]; py=str(R/'benchmarks/.venv/bin/python')
subprocess.run([py,str(W/'add_stream64.py')],check=True)
subprocess.run([py,str(W/'build_custom.py'),'api'],check=True)
for v in ('stream-control','stream-vec','stream-default','stream64'): shutil.copy2(W/'binaries/api',W/'binaries'/v)
subprocess.run([py,str(W/'add_persistent_probe.py')],check=True)
subprocess.run([py,str(W/'build_custom.py'),'persistent-stages'],check=True)
vs={'stream-control':'deck','stream-vec':'write-to','stream-default':'write-to-stream-prototype','stream64':'stream64-prototype'}
for role,n in [('timing',7),('rss',5)]:
    cmd=[py,str(W/'run.py'),f'stream-{role}',*vs,'--cases','text-1000','image-1000','image-64x1m','--warmups','2','--repeats',str(n)]
    for v,mode in vs.items(): cmd+=['--env',f'{v}:ANKI_AUDIT_MODE={mode}']
    subprocess.run(cmd,check=True)
subprocess.run([py,str(W/'run.py'),'persistent-stages-check','persistent-stages','--cases','image-1000','image-64x1m','--warmups','1','--repeats','3','--env','persistent-stages:ANKI_AUDIT_MODE=persistent'],check=True)
print('Additional checks complete',flush=True)
