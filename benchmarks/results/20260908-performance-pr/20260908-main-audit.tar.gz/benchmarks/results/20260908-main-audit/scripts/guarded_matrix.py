from pathlib import Path
import json,subprocess,sys
W=Path(__file__).resolve().parent; R=W.parents[2]
sys.path.insert(0,str(R/'benchmarks'))
import bench,media_bench
original=media_bench.collect_attempt
expected=subprocess.check_output(['pmset','-g','batt'],text=True).splitlines()[0]
def guarded(case,row,command,env):
    before=subprocess.check_output(['pmset','-g','batt'],text=True)
    if before.splitlines()[0]!=expected: raise RuntimeError('power source changed before launch')
    try: return original(case,row,command,env)
    finally:
        after=subprocess.check_output(['pmset','-g','batt'],text=True)
        bench.append(case.parent/'power.jsonl',dict(id=row['id'],before=before,after=after))
        if after.splitlines()[0]!=expected: raise RuntimeError('power source changed during export')
media_bench.collect_attempt=guarded
media_bench.main()
