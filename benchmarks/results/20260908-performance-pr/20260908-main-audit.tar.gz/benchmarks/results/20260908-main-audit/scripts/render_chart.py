"""Render descriptive plots directly from the archived sample summary."""
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DATA = ROOT / 'benchmarks/results/20260908-main-audit'
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / 'benchmarks/.work/main-audit-20260908/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

s = json.loads((DATA / 'summary.json').read_text())
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.titleweight': 'bold', 'svg.fonttype': 'none'})
fig, axes = plt.subplots(1, 3, figsize=(15, 5.4))
fig.patch.set_facecolor('#fafaf7')
fig.subplots_adjust(left=.065, right=.98, bottom=.25, top=.72, wspace=.38)
fig.text(.065, .925, 'Where the current export paths spend time and memory', fontsize=19, weight='bold')
fig.text(.065, .86, 'main c665271  |  macOS ARM64  |  2026-09-08  |  One local session; descriptive results', color='#596069')
blue, red, green = '#31629c', '#bf593d', '#238477'
for ax in axes:
    ax.set_facecolor('#fafaf7')
    ax.grid(axis='y', alpha=.18)
    ax.set_axisbelow(True)

ax = axes[0]
for kind, label, color in [('unclosed_lt', 'Repeated unclosed <', red), ('plain_a', 'Plain A text', blue)]:
    rows = [x for x in s['html'] if x['operation'] == 'public_export' and x['input'] == kind and x['bytes'] <= 16384]
    xs = [x['bytes'] / 1024 for x in rows]
    ys = [x['median_ns'] / 1e6 for x in rows]
    ax.plot(xs, ys, 'o-', color=color, label=label)
    if kind == 'unclosed_lt':
        for x, y in zip(xs, ys):
            ax.annotate(f'{y:,.0f} ms', (x,y), xytext=(0,8), textcoords='offset points', ha='center', fontsize=9)
ax.set_yscale('log')
ax.set_ylim(8,4000)
ax.set_xticks([4,8,16])
ax.set_xlabel('Front size (KiB)')
ax.set_ylabel('Single-note build call (ms, log scale)')
ax.set_title('1  HTML: near-quadratic growth', loc='left', pad=20, fontsize=12)
ax.legend(loc='upper left', fontsize=9, frameon=False)
ax.text(0,-.36, 'Median of 5 calls after 1 warmup.\n32 KiB stopped after 2 measured calls; omitted.', transform=ax.transAxes, fontsize=9, color='#596069', va='top')

ax = axes[1]
stream = next(x['variants'] for x in s['stream'] if x['case']=='image-1000')
keys = ['stream-control', 'stream-vec', 'stream64']
labels = ['Deck file', 'write_to\ncurrent Vec', 'write_to\n64 KiB prototype']
vals = [stream[k]['rss_mib']['median'] for k in keys]
ax.bar(range(3), vals, color=[blue, red, green], width=.58)
for i,k in enumerate(keys):
    vals_i = stream[k]['rss_mib']
    q1,q3 = np.percentile(vals_i['samples'],[25,75])
    ax.errorbar(i, vals_i['median'], yerr=[[vals_i['median']-q1],[q3-vals_i['median']]], fmt='none', color='#17212b', capsize=4)
    ax.text(i, vals_i['median']+4, f"{vals_i['median']:.1f}", ha='center', weight='bold')
ax.set_xticks(range(3), labels, fontsize=9)
ax.set_ylabel('Process peak RSS (MiB)')
ax.set_ylim(0,125)
ax.set_title('2  Bounded copy saves memory', loc='left', pad=20, fontsize=12)
ax.text(0,-.36, '1,000 images; RSS median / IQR, n = 5.\nVec → 64 KiB: 300.2 → 303.3 ms (n = 7).', transform=ax.transAxes, fontsize=9, color='#596069', va='top')

ax = axes[2]
compare = next(x['variants'] for x in s['compare'] if x['case']=='text-10000')
keys = ['stable-control', 'stable-compare']
vals = [compare[k]['rss_mib']['median'] for k in keys]
ax.bar(range(2), vals, color=[blue, red], width=.5)
for i,k in enumerate(keys):
    stats=compare[k]['rss_mib']
    q1,q3=np.percentile(stats['samples'],[25,75])
    ax.errorbar(i,stats['median'],yerr=[[stats['median']-q1],[q3-stats['median']]],fmt='none',color='#17212b',capsize=4)
    ax.text(i,stats['median']+16,f"{stats['median']:.1f}",ha='center',weight='bold')
ax.set_xticks(range(2), ['No comparison','compare_to'], fontsize=9)
ax.set_ylabel('Process peak RSS (MiB)')
ax.set_ylim(0,680)
ax.set_title('3  Full comparison adds cost',loc='left',pad=20,fontsize=12)
ax.text(0,-.36,'10,000 text notes; RSS median / IQR, n = 5.\nTime: 587.7 → 1,701.9 ms (n = 7).',transform=ax.transAxes,fontsize=9,color='#596069',va='top')
for suffix in ('png','svg'):
    fig.savefig(DATA/f'audit.{suffix}',dpi=180,facecolor=fig.get_facecolor())
print(DATA/'audit.png')
