from pathlib import Path
import json,os,shutil,subprocess,sys
W=Path(__file__).resolve().parent; R=W.parents[2]; py=str(R/'benchmarks/.venv/bin/python')
sys.path.insert(0,str(R/'benchmarks')); import bench,verify
names=['text-1000','text-10000','long-back-quadruple-1000','image-1000','image-64x1m']
variants={'api-control':'deck','borrowed-retain-deck':'project','borrowed-move-deck':'project-move','write-to':'write-to','stream-prototype':'write-to-stream-prototype','persistent':'persistent'}
for name in [*variants,'stable-control','stable-compare']: shutil.copy2(W/'binaries/api',W/'binaries'/name)
shutil.copy2(R/'benchmarks/adapters/rust/target/release/html_complexity',W/'binaries/html-complexity')
(W/'update-baselines').mkdir(exist_ok=False)
for case in json.loads((W/'cases.json').read_text()):
    if case['name'] not in names: continue
    output=W/'update-baselines'/f"{case['name']}.apkg"
    env=dict(os.environ,ANKI_AUDIT_MODE='deck',ANKI_AUDIT_STABLE_ID='main-performance-audit')
    subprocess.run([str(W/'binaries/api'),case['path'],str(output)],env=env,check=True)
    checked=verify.verify_artifact(output,json.loads(Path(case['path']).read_text()),bench.INSPECTOR)
    (output.with_suffix('.verification.json')).write_text(json.dumps(checked,indent=2)+'\n'); assert checked['status']=='passed'
def run(name,vs,n,envs):
    cmd=[py,str(W/'run.py'),name,*vs,'--cases',*names,'--warmups','2','--repeats',str(n),'--distinct-containers']
    for v,key,value in envs: cmd+=['--env',f'{v}:{key}={value}']
    print('RUN',name,flush=True); subprocess.run(cmd,check=True)
for role,n in [('timing',7),('rss',5)]:
    run(f'api-{role}',['current',*variants],n,[(v,'ANKI_AUDIT_MODE',mode) for v,mode in variants.items()])
compare_env=[(v,'ANKI_AUDIT_STABLE_ID','main-performance-audit') for v in ['stable-control','stable-compare']]+[('stable-control','ANKI_AUDIT_MODE','deck'),('stable-compare','ANKI_AUDIT_MODE','compare')]
for role,n in [('timing',7),('rss',5)]: run(f'compare-{role}',['stable-control','stable-compare'],n,compare_env)
with (W/'html-complexity.jsonl').open('w') as out,(W/'html-complexity.stderr').open('w') as err:
    subprocess.run([str(W/'binaries/html-complexity')],stdout=out,stderr=err,check=True,timeout=180)
print('API, comparison and HTML measurements complete',flush=True)
