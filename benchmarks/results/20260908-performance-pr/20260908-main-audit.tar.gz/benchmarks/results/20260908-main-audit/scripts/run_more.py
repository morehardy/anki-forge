from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
W=Path(__file__).resolve().parent; R=W.parents[2]; python=str(R/'benchmarks/.venv/bin/python')
cases=json.loads((W/'cases.json').read_text()); api_cases=['text-1000','text-10000','long-back-quadruple-1000','image-1000','image-64x1m']
extras=['text-10000','long-back-1000','boundary-65536','boundary-65537','image-256x256k','image-64x1m','image-skewed-128','long-back-quarter-1000','long-back-quadruple-1000']
stages=['text-100','text-1000','text-10000','image-1000','audio-1000','mixed-1000','shared-1000','long-back-1000','long-back-quadruple-1000','image-64x1m']
variants={'api-control':'deck','borrowed-retain-deck':'project','borrowed-move-deck':'project-move','write-to':'write-to','stream-prototype':'write-to-stream-prototype','persistent':'persistent','compare':'compare'}
for name in variants: shutil.copy2(W/'binaries/api',W/'binaries'/name)
shutil.copy2(R/'benchmarks/adapters/rust/target/release/html_complexity',W/'binaries/html-complexity')
sys.path.insert(0, str(R/'benchmarks'))
import bench, verify
(W/'baselines').mkdir(exist_ok=False)
for case in cases:
    if case['name'] in api_cases:
        baseline=W/'baselines'/f"{case['name']}.apkg"
        subprocess.run([str(W/'binaries/current'),case['path'],str(baseline)],check=True)
        checked=verify.verify_artifact(baseline,json.loads(Path(case['path']).read_text()),bench.INSPECTOR)
        (W/'baselines'/f"{case['name']}.verification.json").write_text(json.dumps(checked,indent=2)+'\n')
        assert checked['status']=='passed',checked

def run(name,vs,cs,n,envs=(),distinct=False):
    cmd=[python,str(W/'run.py'),name,*vs,'--cases',*cs,'--warmups','2','--repeats',str(n)]
    for v,mode in envs: cmd+=['--env',f'{v}:ANKI_AUDIT_MODE={mode}']
    if distinct: cmd+=['--distinct-containers']
    print('RUN',name,flush=True); subprocess.run(cmd,check=True)
run('extra-timing',['current'],extras,7)
run('extra-rss',['current'],extras,5)
run('stages',['current','stages'],stages,5)
run('api-timing',['current',*variants],api_cases,7,variants.items(),True)
run('api-rss',['current',*variants],api_cases,5,variants.items(),True)
with (W/'html-complexity.jsonl').open('w') as out,(W/'html-complexity.stderr').open('w') as err:
    subprocess.run([str(W/'binaries/html-complexity')],stdout=out,stderr=err,check=True,timeout=180)
print('All measurements complete',flush=True)
