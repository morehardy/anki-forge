from pathlib import Path
import json,statistics
W=Path(__file__).resolve().parent; R=W.parents[2]
def read(p): return json.loads(p.read_text())
def rows(name): return [json.loads(s) for s in (W/name/'attempts.jsonl').read_text().splitlines()]
def stats(xs):
    xs=sorted(xs); q=statistics.quantiles(xs,n=4,method='inclusive')
    return dict(n=len(xs),median=statistics.median(xs),iqr=q[2]-q[0],min=min(xs),max=max(xs),samples=xs)
def paired(prefix):
    ts=rows(prefix+'-timing'); ms=rows(prefix+'-rss'); result=[]
    for case in sorted({r['case'] for r in ts}):
        entry=dict(case=case,variants={})
        for variant in sorted({r['variant'] for r in ts}):
            t=[r for r in ts if r['case']==case and r['variant']==variant and r['sample']>=0]
            m=[r for r in ms if r['case']==case and r['variant']==variant and r['sample']>=0]
            entry['variants'][variant]=dict(time_ms=stats([r['measurement']['elapsed_ns']/1e6 for r in t]),rss_mib=stats([r['measurement']['peak_rss_bytes']/2**20 for r in m]),apkg_bytes=t[0]['artifact_bytes'])
        result.append(entry)
    return result
phase=[]
for case in sorted({r['case'] for r in rows('stages')}):
    rs=[r for r in rows('stages') if r['case']==case and r['variant']=='stages' and r['sample']>=0]
    ss={k:stats([r['stages_ns'][k]/1e6 for r in rs]) for k in rs[0]['stages_ns']}
    fractions={k:statistics.median(r['stages_ns'][k]/r['stages_ns']['adapter.total'] for r in rs) for k in ss}
    phase.append(dict(case=case,inclusive_ms=ss,median_fraction_of_adapter_total=fractions))
result=dict(source_commit='c665271b0af9ec7badd2be57b516bf58afac15cd',matrix=read(R/'benchmarks/.work/runs/main-audit-20260908-matrix/summary.json'),extra=paired('extra'),api=paired('api'),compare=paired('compare'),stream=paired('stream'),persistent_phases=read(W/'persistent-stages-check/summary.json'),phases=phase,html=[json.loads(s) for s in (W/'html-complexity.jsonl').read_text().splitlines() if json.loads(s)['kind']=='summary'],quality=read(W/'quality-summary.json'),html_budget_events=[json.loads(s) for s in (W/'html-complexity.jsonl').read_text().splitlines() if json.loads(s)['kind']=='budget_exceeded'])
(W/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
for section in ('api','compare','stream'):
    for c in result[section]: print(section,c['case'],{v:(round(s['time_ms']['median'],2),round(s['rss_mib']['median'],2)) for v,s in c['variants'].items()})
for c in result['html']: print('html',c['operation'],c['input'],c['bytes'],round(c['median_ns']/1e6,3))
