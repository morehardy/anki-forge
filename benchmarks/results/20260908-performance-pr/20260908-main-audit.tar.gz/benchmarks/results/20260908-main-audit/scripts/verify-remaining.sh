#!/usr/bin/env bash
set -euo pipefail
npm --prefix bindings/node run example:minimal
npm --prefix bindings/node run check:package
cargo build -p contract_tools --release
env PYTHONPATH="$PWD/bindings/python/src" python3 -m pytest bindings/python/tests -q --ignore=bindings/python/tests/test_import_isolation.py
env PYTHONPATH="$PWD/bindings/python/src" python3 bindings/python/examples/minimal_flow.py
cargo run -p contract_tools -- verify --manifest "$PWD/contracts/manifest.yaml"
cargo run -p contract_tools -- summary --manifest "$PWD/contracts/manifest.yaml"
cargo run -p contract_tools -- package --manifest "$PWD/contracts/manifest.yaml" --out-dir "$PWD/dist"
benchmarks/.venv/bin/python -m unittest discover -s benchmarks/tests -v
