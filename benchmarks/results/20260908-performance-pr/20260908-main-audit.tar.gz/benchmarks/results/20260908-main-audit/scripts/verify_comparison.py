from pathlib import Path
import json,sqlite3,sys,tempfile
W=Path(__file__).resolve().parent; R=W.parents[2]; sys.path.insert(0,str(R/'benchmarks')); import verify,bench
cases={c['name']:c for c in json.loads((W/'cases.json').read_text())}; findings={}
for name in ['text-1000','text-10000','image-1000','image-64x1m','long-back-quadruple-1000']:
    inputs=json.loads(Path(cases[name]['path']).read_text()); dbs=[]
    with tempfile.TemporaryDirectory(dir=W) as folder:
        for v in ['stable-control','stable-compare']:
            apkg=W/'compare-timing'/f'{name}-{v}-0/output.apkg'; raw,_=verify.read_package(apkg,inputs)
            p=Path(folder)/f'{v}.sqlite'; p.write_bytes(raw); dbs.append(sqlite3.connect(p))
        tables=[x[0] for x in dbs[0].execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        assert tables==[x[0] for x in dbs[1].execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        count=0
        for table in tables:
            a=sorted(dbs[0].execute(f'SELECT * FROM "{table}"').fetchall(),key=repr); b=sorted(dbs[1].execute(f'SELECT * FROM "{table}"').fetchall(),key=repr)
            if table!='notes': assert a==b,(name,table); continue
            cols=[x[1] for x in dbs[0].execute('PRAGMA table_info(notes)')]; idx=cols.index('data')
            assert len(a)==len(b)==inputs['note_count']
            for l,r in zip(a,b):
                assert l[:idx]+l[idx+1:]==r[:idx]+r[idx+1:]
                left,right=json.loads(l[idx]),json.loads(r[idx]); identity=left['anki_forge_identity']; observed=right['anki_forge_identity']
                assert identity['guid_source']=='current_derivation' and observed['guid_source']=='previous_apkg'
                observed['guid_source']='current_derivation'; assert left==right
                count+=1
        for db in dbs: db.close()
    assert bench.sha256(W/'update-baselines'/f'{name}.apkg')==bench.sha256(W/'compare-timing'/f'{name}-stable-control-0/output.apkg')
    findings[name]={'status':'passed','tables_checked':tables,'notes_checked':count,'only_difference':'notes.data.anki_forge_identity.guid_source changes current_derivation -> previous_apkg; all other original row values including IDs, fields, tags, times and checksums equal'}
(W/'comparison-equivalence.json').write_text(json.dumps(findings,indent=2)+'\n')
print('comparison exact row equivalence passed with explicit provenance-only difference')
