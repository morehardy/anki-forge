from pathlib import Path
import hashlib,json,subprocess,sys
from collections import Counter
W=Path(__file__).resolve().parent; R=W.parents[2]
sys.path.insert(0,str(R/'benchmarks'))
import bench,verify
cases={c['name']:c for c in json.loads((W/'cases.json').read_text())}
V=W/'verification'; V.mkdir(exist_ok=True)
known={}; mappings={}; count=0
for run_name in ('extra-timing','stages','api-timing','compare-timing','stream-timing','persistent-stages-check'):
    run=W/run_name
    rows=[json.loads(line) for line in (run/'attempts.jsonl').read_text().splitlines()]
    for row in rows:
        if row['sample']!=0: continue
        name=row['case']; variant=row['variant']; case=cases[name]
        output=run/f'{name}-{variant}-0/output.apkg'; key=(case['input_sha256'],row['artifact_sha256'])
        assert bench.sha256(output)==row['artifact_sha256']
        if key not in known:
            folder=V/f'{name}-{variant}-{run_name}'; folder.mkdir(exist_ok=True)
            document=json.loads(Path(case['path']).read_text())
            if (folder/'raw.json').is_file() and (folder/'anki.json').is_file():
                checked=json.loads((folder/'raw.json').read_text())
                assert checked['status']=='passed' and checked['artifact_sha256']==row['artifact_sha256']
                assert json.loads((folder/'anki.json').read_text())['status']=='passed'
            else:
                result=verify.verify_artifact(output,document,bench.INSPECTOR)
                (folder/'raw.json').write_text(json.dumps(result,indent=2)+'\n')
                assert result['status']=='passed',result
                with (folder/'oracle.stdout.log').open('w') as out,(folder/'oracle.stderr.log').open('w') as err:
                    subprocess.run([str(bench.ORACLE),case['path'],str(output),str(folder/'anki.json')],stdout=out,stderr=err,timeout=120,check=True)
                assert json.loads((folder/'anki.json').read_text())['status']=='passed'
            known[key]=str(folder.relative_to(W))
            count+=1
        mappings[f'{run_name}/{name}/{variant}']=known[key]
        print('verified',run_name,name,variant,flush=True)
for name in ('extra-timing','extra-rss','stages','api-timing','api-rss','compare-timing','compare-rss','stream-timing','stream-rss','persistent-stages-check'):
    rows=[json.loads(line) for line in (W/name/'attempts.jsonl').read_text().splitlines()]
    plan=json.loads((W/name/'plan.json').read_text())
    assert (W/name/'summary.json').is_file(), (name,'missing completed summary')
    expected=Counter((c['name'],v,i) for c in plan['cases'] for v in plan['args']['variants'] for i in range(-plan['args']['warmups'],plan['args']['repeats']))
    assert Counter((r['case'],r['variant'],r['sample']) for r in rows)==expected,(name,'incomplete sample set')
    assert len(rows)==len((W/name/'launches.jsonl').read_text().splitlines())
    assert all(r['measurement']['reaped'] and not any(r['measurement'][k] for k in ('exit_code','signal','spawn_error','leftover_descendants','interrupted_signal')) for r in rows)
    power=plan['initial_power'].splitlines()[0]
    assert all(r[s].splitlines()[0]==power for r in rows for s in ('power_before','power_after'))
    assert all(bench.sha256(Path(v['path']))==v['sha256'] for v in plan['baseline_identities'].values())
    for row in rows:
        assert (cases[row['case']]['input_sha256'],row['artifact_sha256']) in known
        if row['variant']=='stable-compare':
            assert 'comparison=Complete' in (W/name/f"{row['case']}-stable-compare-{row['sample']}"/'stdout.log').read_text()
    mappings[name]={'verified_attempts':len(rows),'method':'Every SHA-256 matches independently verified exact bytes for the same input.'}
api=[json.loads(line) for line in (W/'api-timing/attempts.jsonl').read_text().splitlines()]
for name in {r['case'] for r in api}:
    hashes={r['variant']:r['artifact_sha256'] for r in api if r['case']==name and r['sample']==0}
    assert len({hashes[v] for v in ('current','api-control','write-to','stream-prototype','borrowed-retain-deck','borrowed-move-deck')})==1,(name,hashes)
    assert bench.sha256(W/'baselines'/f'{name}.apkg')==hashes['current']
compare=[json.loads(line) for line in (W/'compare-timing/attempts.jsonl').read_text().splitlines()]
for name in {r['case'] for r in compare}:
    hashes={r['variant']:r['artifact_sha256'] for r in compare if r['case']==name and r['sample']==0}
    assert hashes['stable-control']==bench.sha256(W/'update-baselines'/f'{name}.apkg')
    assert json.loads((W/'comparison-equivalence.json').read_text())[name]['status']=='passed'
stream=[json.loads(line) for line in (W/'stream-timing/attempts.jsonl').read_text().splitlines()]
for name in {r['case'] for r in stream}:
    assert len({r['artifact_sha256'] for r in stream if r['case']==name})==1
(V/'summary.json').write_text(json.dumps({'status':'passed','unique_raw_and_anki_checks':count,'bindings':mappings,'api_equality':'current/control/write_to/stream prototype/both Project paths are byte-identical; complete compare preserves all raw row values except the explicitly verified guid_source provenance transition; persistent independently verified'},indent=2)+'\n')
print('verification complete:',count,'distinct artifacts',flush=True)
