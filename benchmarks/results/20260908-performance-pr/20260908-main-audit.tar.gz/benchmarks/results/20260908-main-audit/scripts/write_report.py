from pathlib import Path
import json
W=Path(__file__).resolve().parent; R=W.parents[2]; D=R/'benchmarks/results/20260908-main-audit'; S=json.loads((W/'summary.json').read_text())
report=R/'docs/superpowers/specs/2026-09-08-main-performance-audit.md'
evidence='../../../benchmarks/results/20260908-main-audit'
labels={'basic-mixed-text-v1':'纯文字','basic-image-unique-v2':'独立图片','basic-audio-unique-v2':'独立音频','basic-mixed-unique-v2':'混合独立媒体','basic-mixed-shared-v2':'复用媒体'}
main='\n'.join(f"| {labels[x['profile']]} | {x['rust']['median_ms']:.2f} | {x['genanki']['median_ms']:.2f} | {x['reduction']*100:.1f}% | {x['rust']['rss_max_mib']:.2f} |" for x in S['matrix'] if x['size']==1000)
extra='\n'.join(f"| {x['case']} | {x['variants']['current']['time_ms']['median']:.2f} | {x['variants']['current']['rss_mib']['median']:.2f} |" for x in S['extra'])
phases=[]
for name in ['text-1000','text-10000','image-1000','long-back-quadruple-1000']:
    p=next(x for x in S['phases'] if x['case']==name)['inclusive_ms']
    phases.append('| '+name+' | '+' | '.join(f"{p[k]['median']:.2f}" for k in ['adapter.registration','adapter.notes','normalize.with_identity','sqlite.total','pipeline.inspect','adapter.total'])+' |')
phase='\n'.join(phases)
compare=[]
for c in S['compare']:
    a,b=c['variants']['stable-control'],c['variants']['stable-compare']
    compare.append(f"| {c['case']} | {a['time_ms']['median']:.2f} → {b['time_ms']['median']:.2f} | {b['time_ms']['median']/a['time_ms']['median']:.2f}× | {a['rss_mib']['median']:.2f} → {b['rss_mib']['median']:.2f} |")
compare='\n'.join(compare)
c=next(x for x in S['stream'] if x['case']=='image-1000')
stream='\n'.join(f"| {label} | {c['variants'][v]['time_ms']['median']:.2f} | {c['variants'][v]['time_ms']['iqr']:.2f} | {c['variants'][v]['rss_mib']['median']:.2f} |" for v,label in [('stream-control','Deck.write_apkg 对照'),('stream-vec','当前 write_to → Vec → File'),('stream-default','原型：验收后 std::io::copy'),('stream64','原型：验收后固定 64 KiB 拷贝')])
text=f'''# main 性能复核与优化方案

日期：2026-09-08。已将干净的 `main` 从 `ab7d261` 快进到 `c665271b0af9ec7badd2be57b516bf58afac15cd`，与本次获取的 `origin/main` 一致。本轮完成当前版本的运行验证、性能复测、隔离原型和一手资料研究；**没有修改生产 Rust/Node/Python 实现，没有提交或推送**。

当前默认导出表现稳定；优化优先级应转向算法极端输入和不同导出入口，不能继续复用旧报告的热点排序。

- **应先修复畸形 HTML 的平方扫描。** 一张卡的 Front 为 16 KiB 连续 `<` 时，公开导出约 2 秒；32 KiB 两次采样约 7.93–7.97 秒，触发探针累计预算停止。
- **新建持久化媒体目录是最大已测慢路径。** 1,000 张图片约 12.88 秒；相同私有适配器的默认导出约 0.262 秒。分段探针确认每个媒体的 CAS 与 staging 各同步落盘一次，2,000 次 `sync_all` 累计约 9.47 秒，占探针内部总时间约 71%。
- **`compare_to` 的完整检查与比较成本明显。** 未修改学习内容的万条文字，从 0.588 秒 / 141.95 MiB 增至 1.702 秒 / 560.52 MiB。这里使用相同稳定项目 ID 的单独对照。
- **`write_to` 强制整包 Vec 是明确内存机会。** 固定 64 KiB 拷贝原型将 1,000 张图片的峰值 RSS 中位数从 100.56 降至 39.02 MiB，但耗时约增加 1%；可确认内存收益，不能宣称提速。
- **默认文字路径仍应拆解 SQLite 成本。** 万条文字的 SQLite 构建约 182 ms，其中填充约 125 ms、压实约 54 ms，约占探针内部总时间的三分之一。已有事务、语句复用与 `VACUUM INTO`，不能把这些重复列为待办。

![本轮关键性能证据]({evidence}/audit.png)

## 测量范围与可复现性

macOS ARM64，Rust 1.92.0 release、默认 public features、system allocator；比较器为原生 CPython 3.11 / genanki 0.13.1。默认适配器复用了与当前 **199 个 crate/adapter 文件逐一哈希一致**的已锁定二进制，并校验工具执行前后的哈希；诊断与 API 原型另行编译并记录源码/二进制身份。没有把旧源码探针当成当前数据。

时间使用原生 collector，从进程创建到退出，包含输入解析、注册、构建、检查、输出与清理。每个导出独立进程，单个导出顺序运行；时间与 OS 峰值 RSS 分开采样，测量阶段没有同时编译或测试。逐次检查原生电源来源为 AC Power；文件缓存未控制为冷缓存，未控制系统其他活动/CPU 频率，热状态接口不可读。

- 默认 5 场景 × 100/200/500/1,000 共 20 格，每实现每格 3 次预热 + 10 次计时，另 3 次预热 + 5 次 RSS。
- 9 个补充形状、普通 API 和更新比较：每配置 2 次预热 + 7 次计时，另 2 次预热 + 5 次 RSS。
- 粗阶段探针：2 次预热 + 5 次采样；同步落盘诊断：1 次预热 + 3 次采样。探针只用于归因，不混入正式时间/RSS。阶段是包含子阶段的墙钟时间，不能将父子相加。
- 以下均为单次本机会话的描述性统计，原始样本、IQR、供电、输入和工具身份见[证据目录]({evidence}/README.md)。不计算跨会话“提速”，不以今天和昨天的绝对耗时差判断回退。

## 默认路径：20 格全部完成

本轮 **20/20 格**相对同轮 genanki 耗时降低至少 30%。这是当前本机结果，不是跨平台保证。1,000 条结果如下；时间是 10 次中位数，RSS 是另 5 次进程峰值中的最大值。

| 1,000 条场景 | Rust ms | genanki ms | 耗时降低 | Rust RSS 最大 MiB |
| --- | ---: | ---: | ---: | ---: |
{main}

完整 20 格见[矩阵报告]({evidence}/matrix/report.md)。两实现输出内容相当，包格式、压缩和默认附加验证不同；大小/时间包括这些默认行为差异。

补充形状的时间与峰值 RSS 中位数：

| 场景 | 时间 ms | RSS MiB |
| --- | ---: | ---: |
{extra}

65,536/65,537 字节两组没有复现旧的明显台阶。64 个大文件与 1,000 个小文件也改变了 note 数；不得把两组总耗时之差全部归因于文件数。这些大 PNG 主要使用合法 ancillary 随机填充测字节压力，不能代表所有真实图片的压缩率。

## 当前默认路径的阶段分布

下表为诊断进程内部各阶段的中位数（ms），最后一列不含进程启动前段。SQLite 属于 generate；归一化含身份与媒体准备，图片场景其中媒体准备约 58.24 ms。不要再将它与归一化相加。

| 场景 | 媒体注册 | 笔记添加 | 归一化+身份 | SQLite 总计 | 成品 inspect | adapter 内部总计 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
{phase}

万条文字归一化+身份约占 17%；同步图片注册约占图片案例的 31%。注册在 `add` 返回前取内容指纹，是即时错误和来源变化检测的一部分，不能简单延迟到 build 来“消除”时间。应继续拆 open/read/hash/尺寸解析，再决定优化位置。

粗探针与同轮未插桩对照的中位时间差，在 100 条小包约 -7.5%，其余约 -3.7%～+2.6%；这是探针与噪声的实用限制，因此只使用粗比例定位，不将阶段数值当成精确节省承诺。逐样本比例见 [summary.json]({evidence}/summary.json)。

## 持久化：主要是同步落盘，不只是压缩

普通 API 对照中，`image-1000` 默认 261.89 ms，设置新 `artifacts_dir` 后 12,879.41 ms，约 49.2 倍；`image-64x1m` 为 191.96 → 1,530.40 ms。每次使用新目录，结论覆盖首次/冷 CAS 写入，**没有测复用现有 CAS 的后续构建**。

独立诊断的 1,000 图片进程中位时间约 13,251 ms，测得 1,000 次 CAS `sync_all` 和 1,000 次 staging `sync_all`；两者逐样本相加的中位数约 9,469 ms，占 adapter 内部总时间的中位比例约 71%。64 文件样本则为 128 次同步，累计约 599 ms。

证据位置：[CAS 写入](../../../anki_forge/src/authoring_core/media_io.rs#L223)、[staging 同步](../../../anki_forge/src/writer_core/media.rs#L166)、[诊断样本]({evidence}/runs/persistent-stages-check/attempts.jsonl)。每文件串行同步等待已被确认。仅调整 zstd context 无法消除这部分成本。

研究有界并行 CAS/staging 写入和同步，保留单文件验收、原子提交、确定错误顺序、共享 CAS 竞争与失败清理；先量 1/2/4 个并行任务的吞吐，不能预先承诺 4 倍收益。热 CAS 还应单独检查是否可以避免对最终丢弃的重复临时对象同步：当前在判定目标对象已存在之前已写入并同步临时文件。不要直接移除实际持久对象的同步要求。

若调用方只要一个 APKG，现有默认 `Deck::write_apkg` 已覆盖高效路径；显式目录适用于确实需要保留中间产物的流程。

## 输出 API：有内存收益，也有负面实验

以下是固定缓冲确认轮的相同输入、相同私有适配器结果；1,000 张图片，File sink。API 内部仍先构建并验收完整候选，原型只改变验收后的拷贝方式。

| 入口 | 时间中位 ms | 时间 IQR ms | 峰值 RSS 中位 MiB |
| --- | ---: | ---: | ---: |
{stream}

`std::io::copy` 原型比当前 Vec 路径约慢 18.5%，不能直接采用它作为加速。64 KiB 原型时间约 +1.0%，RSS 约 -61.2%；64 个 1 MiB 文件时，RSS 91.73 → 27.64 MiB，时间约 +1.2%。这是消除整包额外缓冲的证据，尚不是生产实现；只测了 File sink，没有验证短写、慢 sink、写失败和多所有者生命周期。

未来只改 `write_to` 等便利出口的内部拷贝，保留 `to_apkg_bytes` 必须返回完整 Vec 的语义；用有限缓冲，保持构建失败不开始输出、正确传播中途写错误、临时产物清理和重复调用。`Package` 同类路径由源码确认，尚未实测，不将这些 Rust Deck 数字外推到 Package。

[源码入口](../../../anki_forge/src/deck/export.rs#L91)、[确认轮]({evidence}/runs/stream-timing/summary.json)、[固定缓冲原型源码]({evidence}/api-source/src/main.rs)。

## 更新比较与 Project 所有权

以下对照双方均显式设置相同项目稳定 ID，基线在计时外生成、验证并锁定哈希；每次 compare 都断言 `ComparisonStatus::Complete`。

| 场景 | 无比较 → 比较 ms | 时间倍数 | RSS MiB，前 → 后 |
| --- | ---: | ---: | ---: |
{compare}

学习内容未修改，但比较后 `notes.data.anki_forge_identity.guid_source` 会从 `current_derivation` 变为 `previous_apkg`，因此整包 SHA 不同是预期行为。已逐表检查所有原始行：除这个明确的来源标记外，字段、GUID、ID、时间、校验值及其他表值全部相同；没有删除该字段来计算性能分数。完整核验见 [comparison-equivalence.json]({evidence}/comparison-equivalence.json)。

优先分离 baseline/current 完整 inspection、observation fingerprint、diff 的分配与 CPU；尝试借用索引、避免重复 Value 树和 canonical String。必须保持完整原始产物检查与 canonical 比较规则，不能用构建前的预期摘要替代成品证据。只测了内容未变化的比较，未测 1%/100% 更新或完整 lockfile 工作流。

Project 对照还区分了 `Project::from(deck.clone())` 保留原 Deck，与 `Project::from(deck)` 移交原 Deck。保留原 Deck 的长字段案例 RSS 为 156.06 MiB，私有默认对照为 123.28 MiB；万条为 153.66 对 139.11 MiB。移交原 Deck 改变了调用者对象的存活条件，不能把它的低内存全归因于借用/消费 lowering。该实验从 Deck 转 Project，并非从零构造 Project 的完整基准。

Node NativeDeck 的 clone→Project 借用路径由源码确认，可能遗漏 Rust 最新的文本所有权优化，但本轮没有运行 Node/Python 性能计时；它们的功能测试已运行。细节见[源码审查](2026-09-08-performance-source-audit.md)。

## HTML 复杂度：已复现，正常 add 是路径对照

直接运行实际 `strip_html_preserving_media_filenames` 源函数，并另测公开 `basic().note().add()` 和实际 `Deck::build`。输入为连续 `<`，普通 A 文本作对照。每格 1 次预热 + 5 次采样；输出与身份断言在计时外。

| Front 大小 | 清洗函数中位 ms | 公开单卡导出中位 ms | 普通文本公开导出 ms |
| --- | ---: | ---: | ---: |
| 4 KiB | 41.18 | 139.82 | 13.70 |
| 8 KiB | 164.30 | 511.23 | 13.52 |
| 16 KiB | 657.48 | 2,000.07 | 14.53 |
| 32 KiB | 2,634.96 | 未完成：两次正式样本 7,966.90 / 7,934.54 | 14.91 |

清洗输入翻倍，耗时约四倍；普通文本清洗约线性。公开 add 也约线性，32 KiB 约 0.57 ms，证明不能把这个问题归因到加卡时身份哈希。真正 export 会调用 HTML 清洗，已经显著受影响。

最后一个公开导出格在预热及两次采样累计 23.84 秒后触发 20 秒协作预算；检查发生在单次调用返回之后，故不是硬中断在第 20 秒。**该格没有完整 5 样本统计，不发布中位数或将其混入普通基准**。其他 23 格完成，全部记录见 [原始探针日志]({evidence}/html-complexity.jsonl)。

根因在 [html_text.rs:17](../../../anki_forge/src/authoring_core/html_text.rs#L17)：每遇到无闭合的 `<`，从其后扫描到字符串末尾，失败后只前进一个字符。优先改为语义等价的有界/线性扫描。可先验证“完全没有 `>` 时保留原文并解码实体”的快速路径；完整修复还必须处理引号状态、未闭合注释、raw-text 伪闭合标签、Unicode 与媒体文件名。不能不区分引号状态就把某次失败后的整个后缀标成无效。

## 实施排序与验收

| 顺序 | 工作 | 本轮证据与验收方式 |
| --- | --- | --- |
| P0 | HTML 扫描复杂度 | 已复现到公开导出。先把当前畸形 corpus 固定为差分/复杂度回归，目标随输入增长近线性，并保持正常文本、标签、sfld/checksum 和卡片生成行为 |
| P1，持久化用户 | CAS/staging 同步落盘调度 | 两处同步约占 71%。先拆新/热 CAS，再验证有界并发；保持持久对象的同步、原子性、并发竞争和失败行为 |
| P1，大包出口 | `write_to` 有界拷贝 | 64 KiB 原型 RSS 下降约 61%，暂无时间收益。验证短写/Interrupted/失败/生命周期及小包回退后再接入；公开 bytes API 不改语义 |
| P1，更新工作流 | 完整比较的借用数据流 | 万条约 2.9× 时间、3.9× RSS。单独测完整 inspect/fingerprint/diff，再试借用索引与流式 canonical 序列化；保持全部证据与来源元数据 |
| P2，默认大文本 | SQLite 参数缓冲和执行成本 | 先拆参数构造/绑定/step/commit/VACUUM。保留原始统计表、schema、ID、revision 与包确定性，不重复已失败的 PRAGMA/延后索引实验 |
| P2，绑定与复杂模型 | Node 消费路径、Python 边界、Cloze/多模板 | 当前只有源码线索。扩展真实绑定、常驻/并发、宽模型、lockfile 和冷缓存负载后再决定，不套用 Basic 默认数字 |

除已经测试的 File 拷贝原型外，表中候选均是下一步方案，没有实现或承诺收益。一手官方资料、已落地/已否决方案、SQLite/zstd 版本限制见[优化研究](2026-09-08-performance-optimization-research.md)。

## 验证结果与保留的失败

- 1,015 项 Rust 工作区测试通过，25 项原有忽略；Rust capabilities、格式、Clippy、契约检查通过。Node raw/structured/product/parity/installed、包与示例检查通过；Python 107 项及 5 个 subtest 通过；基准工具 43 项通过。
- `make verify-ci` 原命令先受沙箱禁止本地监听影响；提升本地安装测试权限后通过。后续系统默认 Python 3.14 缺 pytest，使用已安装且符合项目要求的 Python 3.11 续跑剩余关卡通过。没有宣称原命令未经调整一次性全绿。
- **2,044 次有效导出**覆盖计时、RSS、预热与阶段探针。默认矩阵 840 次逐份原始 SQLite/媒体检查，其中 40 份 Anki 导入/渲染通过。补充 1,204 次通过精确 SHA 关联到 27 份独立原始内容与 Anki 核验的产物；所有配置的预声明样本集合、成功退出与供电记录完整。
- 普通出口与两个 Project 路径保持相同 APKG 字节；持久化路径允许原有容器顺序差异，独立核验内容；compare 的预期来源标记变化已逐表检查，见上文。
- 首个 API 预热因夹具缺稳定项目 ID 被正确拒绝，只有 1 次失败尝试；整批排除，保留日志。随后单独构造身份一致的更新比较组并从预热重跑。
- HTML 最后一个格的预算终止、比较来源标记导致初始“整包必须相等”断言失败、以及更慢的 `std::io::copy` 原型都保留。比较断言已改为精确验证唯一预期来源差异，没有重测或挑选快样本。
- 正式适配器已恢复；当前 199 个运行时/适配器源文件仍与同步后的 main 一致。诊断源码和日志仅存在隔离工作目录与证据归档。

本轮提供了 Rust 主链与几个重要入口的实际证据，不能称所有产品用法均已做性能验证。尚缺：实际 Node/Python 性能、Cloze/自定义多卡、共享热 CAS、self-contained/inline 大媒体、长期并发和任务后驻留、Linux/其他 CPU、真实冷缓存及真实媒体分布。
'''
report.write_text(text)
(D/'README.md').write_text('''# 2026-09-08 main 性能审计证据

主报告：[main 性能复核与优化方案](../../../docs/superpowers/specs/2026-09-08-main-performance-audit.md)。当前运行时基线为 `c665271b0af9ec7badd2be57b516bf58afac15cd`；本目录是本地探索性审计，不是跨平台性能承诺。

- `summary.json`：正式计时/RSS分别汇总、全部样本值、阶段比例与HTML完整格。
- `matrix/`：20格 Rust/genanki 原始尝试、完整产物核验、固定 Anki 导入与供电。
- `runs/`：扩展输入、API、稳定身份比较、流式原型与持久同步诊断。每次计划含输入/二进制/基线哈希。
- `verification/`、`comparison-equivalence.json`：27个补充独立产物、所有成功尝试的精确哈希绑定，以及compare的唯一预期guid来源变化。
- `api-source/`、`api-initial-source/`、两份 `*-source.patch`、`build-*.json`：私有原型和插桩源码身份。正式库未修改。
- `completion.json`、`quality-summary.json`、`logs.tar.gz`：完成条件、功能验证与原始日志，包括环境调整/预算停止/夹具失败。
- `scripts/`：实际使用过的脚本，保留历史失败流程；重放时应先读主报告的失败说明。原 `run_more.py` 的匿名compare预热失败，修正后的比较在 `run_api.py`。不应把历史脚本不加区分地顺序执行。

## 本机复现

恢复同一源码和锁文件，按 `benchmarks/README.md` 准备工具。当前标准矩阵可用：

```sh
benchmarks/.venv/bin/python benchmarks/.work/main-audit-20260908/guarded_matrix.py \\
  --name NEW-UNUSED-NAME --inputs benchmarks/.work/readme-comparison/fixtures
```

其余输入身份在 `cases.json`，9个补充形状沿用此前 `remaining-opportunities` / `post-streaming-audit` 归档的生成脚本。本次没有重生成或改写这些冻结夹具。跨机器重放需要恢复并核对这些输入及对应媒体，不能只复制JSON而丢失相对媒体路径。

脚本按 `benchmarks/.work/<audit>/` 定位仓库根，归档内路径用于证据审阅；执行前复制到新的独立 `.work` 目录并修正记录中的本机路径。先编译并冻结正式/私有二进制，结束编译和功能测试，再按计划顺序计时。API比较必须带相同的稳定项目ID、匹配基线与Complete断言；所有验证/Anki导入在计时之后完成。

不使用诊断进程的时间/RSS当正式得分，不混合时间和RSS轮次，不把不同会话的绝对耗时相减。HTML 32KiB公开导出格只有两次正式样本且触发预算，没有完整中位数。比较包与普通包的GUID来源元数据预期不同，不能强制整包等同。
''')
print(report)
