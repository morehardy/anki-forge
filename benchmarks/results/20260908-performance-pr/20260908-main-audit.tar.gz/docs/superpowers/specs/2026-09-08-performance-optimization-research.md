# 当前 Rust 导出的后续性能优化研究

本文件记录资料研究与候选设计；当日实测已进一步确认 HTML 复杂度和持久化同步等待，结果与最终优先级见 [main 性能复核与优化方案](2026-09-08-main-performance-audit.md)。

日期：2026-09-08。源码基线：`c665271b0af9ec7badd2be57b516bf58afac15cd`（合并 PR #46 后的 main）。本文只做源码核对、一手资料研究与实验设计，没有编译、运行新的基准或修改生产代码。表中旧测量明确标注为历史结果，候选的收益全部待验证；当天的重新测量应以本次性能审计报告为准。

优先研究两个范围明确的问题：**默认导出的 SQLite 参数准备、插入和压实成本，以及现有 Basic 基准没有覆盖的便利 API 整包内存副本**。其次验证长字段 revision 哈希的中间缓冲，以及持久化媒体路径的编码器上下文生命周期。不要继续把已经实现的上下文复用、媒体流水线、临时 Project 字段移动，或已经失败的 PRAGMA 调整当成新方案。

## 已有证据与边界

已逐项阅读 [ADR 0018](../../adr/0018-build-owned-media-streaming.md)、[ADR 0019](../../adr/0019-consume-temporary-project-text.md)、[有界媒体池实现](../../../benchmarks/results/20260907-bounded-media/implementation.md)和[文本所有权报告](../../../benchmarks/results/20260907-text-ownership/README.md)，并用当前源码确认以下状态。

| 已经完成 | 当前边界 |
| --- | --- |
| 默认临时构建把源检查、SHA-1/BLAKE3、MIME 取样、zstd 编码放进一次读取 | 注册仍先同步读取完整内容取得指纹；构建必须识别注册后的源变化 |
| 最多 4 个媒体 worker；有界动态任务窗口；每个 worker 复用一个 CCtx | 编码缓冲池 4.5 MiB 不是总 RSS 上限，也不包含 zstd 原生分配 |
| 成品检查按块并行哈希；复用解码器工作区；ZIP 写入与包 SHA-1 重叠 | 成品检查、CRC、解码预算、按序摘要及最终发布前同步仍须执行 |
| 临时 Project 的 HTML 所有权转移，并提前释放临时笔记和身份缓存 | 原始 Deck 仍由调用者持有，公开借用式 API 保持可重复导出 |
| SQLite 已有事务、循环外预编译 notes/cards 语句、按模型准备字段布局、VACUUM INTO | 不能把“改成事务”“缓存 notes 插入语句”“使用 VACUUM INTO”再列成待办 |
| revision 和 notes.data 已使用借用结构直接序列化 | revision 仍先形成完整 JSON String 再计算 BLAKE3；不是仍在构造旧 JSON Value 树 |

源码：[媒体准备](../../../anki_forge/src/prepared_media.rs)、[数据库写入](../../../anki_forge/src/writer_core/apkg.rs)、[revision](../../../anki_forge/src/writer_core/note_revision.rs)、[notes.data](../../../anki_forge/src/writer_core/note_data.rs)。

下表只用于排除重复实验，不可与当天的绝对时间相减，也不可把几轮收益相加。

| 历史候选或改动 | 既有结果 | 本轮判断 |
| --- | --- | --- |
| 临时 SQLite 缓存 8 MiB | 万条文本耗时约 +0.9%，诊断 RSS +17.66 MiB；长字段耗时约 +3.1%、RSS +20.12 MiB | 不再默认放大缓存 |
| 整次构建保留身份映射 | 万条耗时约 -1.2%、RSS +2.58 MiB；长字段耗时约 +3.7%、RSS +6.80 MiB | 不恢复跨阶段的大型缓存 |
| 临时库 `synchronous=OFF` | 万条仅约 0.31% 改善，RSS 增加 | 不降低同步要求 |
| `journal_mode=MEMORY` | 万条与长字段均变慢，RSS 增加 | 不采用 |
| 7 个非唯一索引延后创建 | 万条约 1.46% 改善、长字段约 1.44% 回退；`sqlite_stat1` 严格等价失败 | 不能忽略统计表后重新宣称等价 |
| 提高单个媒体暂存阈值 | 大文件更快，但总 RSS 明显增大 | 后续已用共享总预算池解决，不能恢复每任务扩容 |
| 临时 Project 文本所有权转移 | 四倍长 Back 的 RSS 155.39 → 124.20 MiB；耗时 359.213 → 348.278 ms | 已落地；这是内存优化的既有证据，不是本轮的新收益 |

前两项见[流式后续实验](../../../benchmarks/results/20260907-streaming-followup/implementation.md)，中间四项见[流式后瓶颈复查](../../../benchmarks/results/20260907-post-streaming-audit/README.md)，最后一项见[文本所有权正式对照](../../../benchmarks/results/20260907-text-ownership/README.md)。

## 优先级与最小实验

| 优先级 | 独立候选 | 目标与可观测收益 | 首先验证什么 |
| --- | --- | --- | --- |
| P1：默认大文本路径 | SQLite 参数缓冲复用；小批量 INSERT 分别试验 | 降低每 note/card 的 Rust 分配、绑定或 VM 调用成本 | 先拆开参数生成、绑定、step、commit、VACUUM；不能用整个“SQLite 阶段”作为预计节省量 |
| P1：扩大覆盖后决定 | `Deck::write_to`、`Package::write_to`、`Package::write_apkg` 避免中间整包 Vec | 让输出适配层的额外内存不再随 APKG 大小线性增长 | 用实际 File/计数 Write sink 测量；`Vec<u8>` sink 自己会保留整包 |
| P2 | revision JSON 缓冲序列化到 Hasher | 减少单条长字段的临时分配与复制 | 比较现状、直接写 Hasher、固定缓冲写 Hasher；短字段可能回退 |
| P2：持久化场景 | 持久化媒体 writer 在连续条目间复用 CCtx | 减少每媒体条目的 codec 初始化和原生分配 | 先测 `artifacts_dir`/CAS 路径，不能用默认临时路径的既有收益代替 |
| P3：并发场景 | worker 数、阈值和调度预算 | 改善常驻服务多个同时构建的吞吐与尾延迟 | 1/2/4/8 个并发 build；同时记录 RSS、线程数和 p95，不只看单请求最短时间 |

这些优先级是研究排序，不代表上述候选已经证实值得合并。

## SQLite：先拆开原生成本与调用侧成本

当前 `create_latest_collection_file` 有一个 schema 事务，随后 `populate_latest_collection` 用另一个事务写入全部行，最后执行 `VACUUM INTO`。notes/cards 已在循环外 prepare，并按递增 row ID 插入。SQLite 一次只允许一个 writer，给同一数据库添加写线程不等于并行插入；WAL 的读写并发优势也不直接对应这个私有、单写者、随后读取的导出流程。[当前写入实现](../../../anki_forge/src/writer_core/apkg.rs#L433)；[SQLite 事务文档](https://sqlite.org/lang_transaction.html)。

建议在隔离探针中分别统计：schema/prepare、`note_storage_values`、标签拼接、`fresh_identity_note_data`、绑定、`sqlite3_step`、commit、VACUUM 以及最终库字节数。现有“note insert”计时包含身份 JSON 参数生成，不能全部归因于 SQLite。增加 `SQLITE_STMTSTATUS_VM_STEP/RUN/REPREPARE` 与连接级 `CACHE_USED/HIT/MISS/WRITE/SPILL`；前者描述语句执行工作，后者帮助辨别缓存容量和重复页写。它们是计数器，不是 CPU 时间。[语句计数定义](https://sqlite.org/c3ref/c_stmtstatus_counter.html)；[连接计数定义](https://sqlite.org/c3ref/c_dbstatus_options.html)。

本仓库锁定 `rusqlite 0.32.1`、`libsqlite3-sys 0.30.1`，本地 bundled SQLite 头文件版本为 **3.46.0**。在线文档可能描述较新版本；探针只能使用该头文件实际提供的计数器，不能直接抄入新文档的 `TEMPBUF_SPILL`。`rusqlite::Statement::get_status` 已可读取语句计数，不必为此修改生产 API。[依赖锁定](../../../Cargo.lock)；[本地头文件](/Users/hp/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/sqlite3/sqlite3.h)；[本地 rusqlite Statement](/Users/hp/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rusqlite-0.32.1/src/statement.rs)。

最小候选应分开运行：

1. **复用每行参数缓冲。** 对 `flds`、tags、notes.data 使用构建内短生命周期的可清空缓冲，保留原有序列化器、字段顺序和标签行为。当前 `flds` 每条 `join`、notes.data 每条新 String；复用只减少调用侧分配，不会消除最终 SQL 存储或绑定复制。长字段后接大量小字段时应限制保留容量，避免一个异常大字段使整个构建一直持有大缓冲。[参数构造](../../../anki_forge/src/writer_core/apkg.rs#L620)。
2. **小批量 INSERT。** 如果绑定/step 边界确实占比可观，再比较固定批大小，例如 8/32/128 行。保留明确分配的 note/card ID 和原顺序；不能依赖批量插入后的隐式 rowid。多行 SQL 仍需绑定所有参数并维护索引，不承诺它能消除每行数据库工作。参数数量以运行时 SQLite limit 为准，并覆盖尾批。[SQLite 参数绑定与变量限制](https://sqlite.org/c3ref/bind_blob.html)。
3. **只在小包固定成本显著时试合并两个事务。** schema 和 populate 合并可以减少一次 commit，但收益上界仅是这次边界成本；VACUUM 必须在事务结束后执行。需要覆盖 schema/populate 中途失败与清理路径。不要把这项 O(1) 候选包装成万条数据的主要优化。[当前事务边界](../../../anki_forge/src/writer_core/apkg.rs#L443)；[VACUUM 的事务约束](https://sqlite.org/lang_vacuum.html)。

`VACUUM INTO` 已避免把压实后的数据库复制回源库，但仍会重建一个紧凑库；backup API 不能自动提供同样的压实结果。若这一段主导长字段时间，首先记录输入/输出页数与实际写入字节，查明是否重复重写内容。直接取消压实、改变页面布局或使用未经验证的数据库模板，都应作为独立格式/确定性实验，不是低风险默认参数调整。[SQLite VACUUM 说明](https://sqlite.org/lang_vacuum.html)。

不要以 `SQLITE_STATIC` FFI 替换安全绑定作为第一步。当前 rusqlite 的非空文本使用 `SQLITE_TRANSIENT`，SQLite 会在 bind 返回前复制；STATIC 要求内存直到 statement finalize 或同参数重新绑定前持续有效，`reset()` 本身不会清除绑定。可清空/扩容的 Rust String 容易违反这个条件。先证明绑定复制是实质热点，再决定是否值得新增专门所有权封装。[SQLite 生命周期规则](https://sqlite.org/c3ref/bind_blob.html)；[锁定版本的绑定实现](/Users/hp/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rusqlite-0.32.1/src/lib.rs#L301)。

数据库候选必须核验原始 schema、所有表（包括 `sqlite_stat1`）、字段顺序、tags、notes.data、cards、mtime、GUID、lockfile、解码后的 collection 字节及完整 APKG。只通过 Anki 导入但统计表不同，不能宣称满足当前严格等价门槛。

## 输出 API：存在标准基准未覆盖的整包副本

当前 `Deck::write_to` 和 `Package::write_to` 都调用 `to_apkg_bytes()`，再 `write_all`；`Package::write_apkg` 也先取得完整 `Vec<u8>` 再 `fs::write`。因此这些入口在向文件或网络适配器写入前，至少需要容纳一个完整 APKG 的用户态输出缓冲。现有 Rust adapter 测量的是 `Deck::write_apkg`，无法证明这些 API 在大包时没有额外内存成本。[公开入口](../../../anki_forge/src/deck/export.rs#L63)；[基准调用](../../../benchmarks/adapters/rust/src/main.rs#L127)。

可保留当前构建、完整检查和候选生命周期，然后从受控临时成品以固定缓冲或 `std::io::copy` 写入调用者的 `Write`。这能去掉 API 内部强制整包物化的设计；RSS 下降多少和耗时是否改善仍需测量。`to_apkg_bytes()` 的返回类型明确要求整包 Vec，应继续保留该语义。[Rust 流式 copy 文档](https://doc.rust-lang.org/std/io/fn.copy.html)。

验证矩阵应包含 64 KiB、数十 MiB、数百 MiB 成品，以及 File sink、丢弃但计数的 Write sink、慢 sink、短写、`Interrupted`、写若干字节后失败、临时目录清理和重复调用。不能以写进 `Vec<u8>` 的 RSS 当成流式入口的内存结论，也不能因为用了 `write_to` 就把尚未完成验收的候选字节提前送到外部。通用 `Write` 发生中途错误本来就可能已经输出前缀；目标是保持其错误传播和构建失败时不开始输出的行为。已有 `ApkgArtifact::persist_to` 的原子复制与多所有者生命周期另有契约，不要改成移动来省掉复制。[候选验收顺序](../../../anki_forge/src/product/project/pipeline.rs#L156)；[artifact 复制契约](../../../anki_forge/src/build/artifact.rs#L64)。

## 内容哈希：减少中间表示，保留独立成品证据

`NoteRevision::from_note` 当前把借用 Payload 序列化成完整 JSON String，然后 `blake3::hash`。同一个方法也用于从 SQLite 解码出的笔记检查。因此一个局部候选是保持同样的 canonical 序列化规则，把字节经固定缓冲送入 `blake3::Hasher`。`serde_json::to_writer` 可以序列化到 Write，锁定版本 BLAKE3 1.8.4 的 Hasher 已实现 Write；无需增加算法或全局缓存。[当前 revision 实现](../../../anki_forge/src/writer_core/note_revision.rs#L17)；[serde_json 官方 API](https://docs.rs/serde_json/latest/serde_json/fn.to_writer.html)；[锁定版本 BLAKE3 源码](/Users/hp/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/blake3-1.8.4/src/lib.rs#L1627)。

必须比较三种单变量实现：现有完整 String、直接写 Hasher、16/64 KiB 固定缓冲写 Hasher。JSON 转义会产生碎写，而 BLAKE3 的 SIMD 利用受到每次输入块大小影响，减少分配不保证降低耗时。缓冲要在 finalize 前显式 flush，并在每条 note 开始前重置，不能遗留上条字节。已有 property tests 可继续用旧 canonical 输出做 oracle；增加空字段、宽模型、排序字段、Unicode、转义、重复/空格 tags、`preserve_order` 特性统一以及超长单字段场景。[BLAKE3 官方 Hasher 文档](https://docs.rs/blake3/latest/blake3/struct.Hasher.html)；[现有差分测试](../../../anki_forge/src/writer_core/note_revision.rs#L60)。

检查复用要按证据来源区分：

| 证据来源 | 可研究的复用 | 不能直接省略的工作 |
| --- | --- | --- |
| 同一不可变 normalized note 内的派生字符串 | 在该局部生命周期复用已计算结果，减少重复编码或短期分配 | canonical 内容、标签归一化与身份/修订算法 |
| 注册时的外部媒体指纹 | 作为构建时重新读取内容的预期值 | 构建时的真实字节读取和源变化检测；mtime/size 不足以代替内容比较 |
| 私有媒体准备后的已编码 payload | 已有私有所有权链可复用 SHA-1/BLAKE3/CRC 与条目长度 | 对最终 ZIP 的读取、CRC、解码资源限额和媒体内容核验 |
| 准备阶段计算的 note revision | 可供 reconcile 使用 | 从最终 SQLite 重新生成 revision；否则 writer 丢字段或写错字段可能被自己的预期摘要掩盖 |
| 外部 APKG、CAS 或上一轮持久成品 | 只有重新取得当前真实内容证据后，才讨论局部结果复用 | 根据路径、旧摘要或“上次通过”直接跳过当前验证 |

依据：[ADR 0018 的信任与所有权边界](../../adr/0018-build-owned-media-streaming.md)、[成品笔记摘要生成](../../../anki_forge/src/writer_core/inspect.rs#L658)、[注册指纹比较](../../../anki_forge/src/prepared_media.rs#L309)。`BuildOptions::inspect(false)` 当前只控制返回报告是否附带摘要，pipeline 仍执行成品比较/检查；不能把它当成用户已授权关闭校验。[pipeline](../../../anki_forge/src/product/project/pipeline.rs#L463)。

## zstd 与 worker：区分已经复用的路径和未测路径

默认媒体路径已经在每个 worker 外建立 CCtx，连续媒体用 `Encoder::with_context`；检查端也复用 decoder workspace。这里再加“context pool”不会自动创造新的复用机会。持续保留跨 build 的池还会延长 codec 峰值内存的存活时间，必须用常驻场景验证。[当前 worker 生命周期](../../../anki_forge/src/prepared_media.rs#L140)；[ADR 0018](../../adr/0018-build-owned-media-streaming.md)。

持久化/CAS 的 `write_zstd_file_entry` 每个条目调用 `Encoder::new`，可以在这一条独立路径验证连续条目复用。每帧必须完整 finish；参数、字典和 session 状态需明确初始化，前一条异常后不能带着残留状态处理下一条。zstd 允许跨操作复用 context，且部分参数会保留；官方在线手册标为 1.5.1，本文同时核对了锁定的 **1.5.7** 头文件与 zstd crate 0.13.3 源码。[持久路径](../../../anki_forge/src/writer_core/apkg.rs#L418)；[zstd v1.5.7 官方源码](https://github.com/facebook/zstd/blob/v1.5.7/lib/zstd.h)；[Rust wrapper 源码](https://docs.rs/zstd/0.13.3/src/zstd/stream/raw.rs.html)。

不要默认开启每个 encoder 的 `nbWorkers`。当前 crate 的默认 features 不包含 `zstdmt`；zstd 的内部多线程需要相应构建支持，会增加线程及内存。应用层已有最多 4 个独立媒体任务，再加帧内线程可能过度竞争；对同一个大 collection 帧是否有利，是另一项实验。压缩 level、pledged source size、字典、线程划分还可能改变编码帧和完整包字节，不能仅凭解码内容相同就视为现有确定性测试已通过。[crate 默认 features](/Users/hp/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zstd-0.13.3/Cargo.toml#L58)；[zstd 多线程参数定义](https://facebook.github.io/zstd/zstd_manual.html)；[当前 collection 未指定 source size 的原因](../../../anki_forge/src/writer_core/apkg.rs#L412)。

如要研究 worker 调整，应在同一机器比较单个与 1/2/4/8 个同时构建，按总吞吐、p50/p95、进程 RSS、线程数、排队时间和临时 spill 字节决策。必须继续保留有限任务窗口、有限 payload 总预算、顺序提交、失败回收和无法创建线程时的既有行为。先量常驻服务的资源竞争，再决定是否需要内部并发预算；本轮不建议直接增加公开配置面。

## 验收与停止条件

继续保留既有 29 个冻结场景，并按候选增加有针对性的维度：多模板/多模型/Cloze；单超长字段与多宽字段；大包 `write_to`/Package；持久 artifacts/CAS；同一个 Deck/Project 重复导出；常驻并发。已有随机 ancillary 数据的大 PNG 是吞吐与落盘压力样本，还应加入实际可压缩性不同的媒体；不能把单一合成分布当成全部图片/音频场景。

每个候选先在隔离副本做一个因素的筛选：固定源码/依赖/编译参数/输入哈希；独立进程，A/B 交错，预声明预热与采样次数，逐样本记录原生电源来源。正式时间与 RSS 分开测量；Rust 分配探针和 SQLite/zstd 原生状态探针不混入正式耗时。完整保留失败与慢样本，编译、测试、压测和计时分阶段串行进行。

通过条件是目标负载出现可重复的改善，常用负载无材料性回退，并且通过同一输入下的完整包确定性、原始 SQLite/媒体检查、身份与 revision/lockfile、错误次序、失败清理、源变更、预算边界，以及固定上游 Anki 的导入与渲染核验。可以在开跑前把“目标端到端至少约 5%”或“明确消除随包大小增长的额外输出缓冲”作为工程筛选门槛；这是建议的决策规则，不是预言收益。未跨过门槛就保留研究证据而不合并，不通过放宽校验来达标。

## 资料取得说明

使用 research 与 agent-reach 技能。Jina 网页路由在此环境解析失败，随后使用可用网页工具直接核实 SQLite、Rust、zstd、serde_json/BLAKE3 的一手页面，并以本机锁定依赖源码校对版本。部分固定版本 docs.rs 页面不可访问，本文不把读取失败的页面当成证据；相关 API 以本地版本源码和明确标注的在线文档交叉核对。`agent-reach check-update` 因该 CLI 未安装而未能执行，不影响上述一手资料研究，也没有安装或更新环境组件。
