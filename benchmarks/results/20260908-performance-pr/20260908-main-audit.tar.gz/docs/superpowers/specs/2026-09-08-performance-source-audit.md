# 当前 main 性能源码审查

本文件记录实测前的源码假设；已完成的当日实验、确认结果与最终优先级见 [main 性能复核与优化方案](2026-09-08-main-performance-audit.md)。

日期：2026-09-08；源码：`c665271`。本次是只读静态审查：未编译、运行测试或产生新性能数据，避免干扰并行进行的实测。下面区分已经落地的优化、历史测量证据和可证伪假设；源码中存在复制或循环不等于它就是端到端瓶颈。

## 现状与历史证据

已阅读 ADR 0013/0015/0017/0018/0019，以及原接口媒体报告、流式后续报告、文本所有权报告。历史 Basic 默认临时导出成绩不能外推至 Project 借用入口、`compare_to`、持久化、Node/Python 或并发服务。

- 单事务、notes/cards SQL 复用、`PreparedNotetype`、借用 GUID 索引、`VACUUM INTO` 都已存在，见 [apkg.rs](../../../anki_forge/src/writer_core/apkg.rs#L433)。不应再次作为“待添加”的优化。
- 无 baseline 走实际 APKG 的摘要 projection；已有逐行计数，省掉完整 note observation/revision/fingerprint，见 [comparison.rs:90](../../../anki_forge/src/product/comparison.rs#L90)、[inspect.rs:1550](../../../anki_forge/src/writer_core/inspect.rs#L1550)。不能把取消最终检查作为默认方案。
- typed staging 已借用 IR，manifest 已逐项流式序列化并累计哈希，见 [build.rs:91](../../../anki_forge/src/writer_core/build.rs#L91)、[staging.rs:372](../../../anki_forge/src/writer_core/staging.rs#L372)。普通导出不存在旧报告中的整份 staging JSON clone/重读链。
- Rust Deck 已通过 `from_deck(self).into_build(options)` 消费临时 Project，移交 HTML 后释放临时内容；原调用者仍保留可编辑 Deck，见 [export.rs:84](../../../anki_forge/src/deck/export.rs#L84)、[input.rs:21](../../../anki_forge/src/product/project/input.rs#L21)、[project.rs:1029](../../../anki_forge/src/product/project.rs#L1029)。
- 媒体动态调度、共享 4.5 MiB 编码缓冲、256 KiB 分块检查哈希、包哈希与写入重叠均已实现。旧 64 KiB 检查边界和固定跨步 worker 分配问题已不是现状，见 [ADR 0018](../../adr/0018-build-owned-media-streaming.md)。
- 默认运行时已只在内存解包并缓存 writer defaults，见 [embedded.rs:24](../../../anki_forge/src/runtime/embedded.rs#L24)。历史诊断约 2.5 ms，旧约 31 ms 的冷启动数字已失效。

[最新文本所有权对照](../../../benchmarks/results/20260907-text-ownership/README.md)的 29 场景覆盖 Basic 文字、媒体和长 Back，1,000 条短文本为 59.817 ms / 29.53 MiB；10,000 条为 477.831 ms / 140.53 MiB；四倍长 Back 为 348.278 ms / 124.20 MiB。这是 2026-09-07 的独立进程历史数据，不是本次复测。

同报告的 [阶段探针](../../../benchmarks/results/20260907-text-ownership/runs/stage-check/summary.json)中，采用版 10K 的 normalization + identity 为 84.555 ms，prepare 为 95.640 ms，reconcile 为 33.145 ms；父子区间不能相加。更早的 [剩余机会诊断](../../../benchmarks/results/20260907-remaining-opportunities/README.md)显示 SQLite 10K 填充约 103 ms、压实约 45 ms，但版本/会话不同，应在当前源码重新分段后判断权重。

## 优先验证的假设

### 1. 默认文字导出：SQLite 构建/压实仍有较大成本，但缓存加大已有反证

每次 build 创建源数据库，执行 schema 迁移、逐 note/card INSERT，再 `VACUUM INTO` 到第二个文件；默认临时路径把压缩后的 collection 先写临时文件，再复制进顺序 ZIP。位置：[apkg.rs:433](../../../anki_forge/src/writer_core/apkg.rs#L433)、[apkg.rs:608](../../../anki_forge/src/writer_core/apkg.rs#L608)、[apkg.rs:233](../../../anki_forge/src/writer_core/apkg.rs#L233)。

**可证伪预测：**若 SQLite 仍主导默认文字耗时，1K/10K note 数增长时 `populate` 和 `VACUUM INTO` 应占主要增量；若 collection 临时文件往返重要，固定 note 数增加字段字节时 encode/write/copy 增量应显著。先分别测 schema、fill、vacuum、encode、copy、inspect，不直接依据历史 ms 修改参数。

**候选：**先把 SQLite 阶段拆成字段/标签/身份 JSON 参数生成、绑定、step、commit 与压实；如果调用侧分配占比可观，试验复用参数缓冲，再独立评估小批量 INSERT，保持 ID、行顺序与尾批行为。对小 collection 可另测有严格上限的编码缓冲，保留大文件溢写与相同 ZIP 字节，计入峰值内存与输出大小。现有 [后续报告](../../../benchmarks/results/20260907-streaming-followup/implementation.md)已经否定“SQLite cache 改为 8 MiB”：10K 慢约 0.9%，RSS 多 17.66 MiB。[流式后复查](../../../benchmarks/results/20260907-post-streaming-audit/README.md)也已否定延后 7 个非唯一索引：10K 仅约 1.46% 改善、长字段约 1.44% 回退，且 `sqlite_stat1` 严格等价失败。两者均列为已否决候选，不再推荐恢复；不能忽略统计表来宣称等价。

### 2. `compare_to`：完整 inspection/fingerprint/diff 副本未被默认摘要优化覆盖

baseline 在准备开始前完整检查并保存在 `BaselineSnapshot`，供身份恢复与后续 diff 共用，不重复读取 baseline 路径；当前包也走完整检查：[pipeline.rs:185](../../../anki_forge/src/product/project/pipeline.rs#L185)、[comparison.rs:38](../../../anki_forge/src/product/comparison.rs#L38)、[comparison.rs:116](../../../anki_forge/src/product/comparison.rs#L116)。

完整 fingerprint 递归 clone observation map，再通用 `to_canonical_json` 生成另一份 Value 和 String：[inspect.rs:416](../../../anki_forge/src/writer_core/inspect.rs#L416)、[inspect.rs:456](../../../anki_forge/src/writer_core/inspect.rs#L456)、[canonical_json.rs:4](../../../anki_forge/src/writer_core/canonical_json.rs#L4)。diff 为两侧建立拥有 Value 的索引，每条共同 selector 又递归复制并序列化，连完全相同的 baseline 也执行：[diff.rs:38](../../../anki_forge/src/writer_core/diff.rs#L38)、[diff.rs:125](../../../anki_forge/src/writer_core/diff.rs#L125)。

**可证伪预测：**同输入 `compare_to` 相对无 baseline 的额外耗时/分配会随 observation 字节量增加；0% 与 1% 修改时仍有接近相同的大部分比较成本。用短字段/长字段、1K/10K、0%/1%/100% 修改对照，单列 baseline inspect、current inspect、fingerprint、diff、RSS。

**候选：**diff 索引改为借用 `&str -> &Value`，递归按现有非语义字段规则比较；fingerprint 用借用 canonical serializer 直接写 hasher。必须保持 canonical 字节/哈希、数组顺序、重复 selector 的最后值覆盖、缺失 domain、数字表示与 evidence 完全一致。不能仅凭 Value `PartialEq` 或哈希相等取代现有序列化比较语义。该方向目前只有静态证据，无收益承诺。

### 3. Node Deck：没有接入 Rust Deck 的文本所有权优化

NativeDeck 的 Validate/Build/Diff 先执行 `context.project = Project::from(deck.clone())`，Build 再借用这个 Project；任务结束后该快照仍属于 context：[state.rs:184](../../../bindings/node/native/src/state.rs#L184)。`apkgBytes` 也另造 cloned Deck/Project，借用构建后整包读入 Vec：[state.rs:302](../../../bindings/node/native/src/state.rs#L302)。相比之下，Rust Deck 的 `from_deck` 只逐条 clone note，避免复制 Deck 身份/索引缓存，然后消费临时 Project：[deck_import.rs:18](../../../anki_forge/src/product/project/deck_import.rs#L18)。

**可证伪预测：**1,000 条大 Back 或大量 identity payload 下，Node Deck build 的原生活跃堆高于直接 Rust Deck build；单对象重复 build 后保留的 context Project 增加任务间驻留内存。RSS 未回落本身不足以证明对象泄漏，应观测实际存活分配或可解释的对象生命周期。

**候选：**NativeDeck 的 Build 直接在 worker 调公开 `deck.build(options)`，保留 Node Project 的借用路径；另检查 Validate/Diff 是否需要永久保留 snapshot。用同输入 Node Deck/Node Project/Rust Deck，以及重复导出和媒体失败后修复重试验证。不得破坏 Busy/Ready、panic retirement、Worker 终止后释放语义。Node 已是 napi 进程内 binding，且使用 `spawn_blocking`，不能描述为 CLI 或“待异步化”：见 [tasks.rs:8](../../../bindings/node/native/src/tasks.rs#L8)、[ADR 0017](../../adr/0017-native-node-product-sdk.md)。

### 4. 持久化：显式目录会走另一条媒体 I/O 与编码路径

`artifacts_dir`、`media_store_dir`、`base_dir` 或 self-contained 任一条件使默认 prepared-media 优化不适用：[pipeline.rs:200](../../../anki_forge/src/product/project/pipeline.rs#L200)。持久化 staging 复制并校验 CAS，writer 再校验 CAS、重新打开并逐条压缩，最后重读整包算指纹：[staging.rs:359](../../../anki_forge/src/writer_core/staging.rs#L359)、[apkg.rs:370](../../../anki_forge/src/writer_core/apkg.rs#L370)、[apkg.rs:418](../../../anki_forge/src/writer_core/apkg.rs#L418)、[apkg.rs:212](../../../anki_forge/src/writer_core/apkg.rs#L212)。

**可证伪预测：**冻结相同媒体内容，仅设置 `artifacts_dir` 后，读取/写入字节、串行 verify/encode 与 wall time 会增加，且与媒体总字节相关；固定总字节增加文件数可区分 open/metadata 与吞吐成本。

**候选：**保留物理 CAS/staging 产物和可复查性，研究校验与压缩在同次读取完成、校验合格的私有结果按序落包；外部 CAS 不能只信任早期检查。不同存储模式 ZIP 顺序本来可以不同，应比解码内容和身份，同一模式仍要求字节确定性。self-contained 还包括 base64 数据，应独立计输入驻留，不能套用 4.5 MiB payload 上限。

### 5. Project/Cloze/多模型：重复身份解析与 card planning 需扩展负载验证

借用 Project 分别在 payload、source-map、normalize 后身份提取时解析身份：[project.rs:1015](../../../anki_forge/src/product/project.rs#L1015)、[project.rs:1245](../../../anki_forge/src/product/project.rs#L1245)、[input.rs:36](../../../anki_forge/src/product/project/input.rs#L36)。省略 ID 的 Basic/Cloze 会渲染整份 fields；自定义模型身份又线性寻找 note type、构建 field-key map：[project.rs:1849](../../../anki_forge/src/product/project.rs#L1849)、[project.rs:1884](../../../anki_forge/src/product/project.rs#L1884)、[project.rs:1932](../../../anki_forge/src/product/project.rs#L1932)。这是借用路径差异，不能与 ADR 0019 已采用的 owned identity reuse 混为一谈。

card planning 在预先 counts、writer 验证、写行时重复发生。Cloze 每次重建字段集合、扫描内容；writer 验证对每 note clone/排序相同的模型字段：[pipeline.rs:23](../../../anki_forge/src/product/project/pipeline.rs#L23)、[staging.rs:751](../../../anki_forge/src/writer_core/staging.rs#L751)、[staging.rs:778](../../../anki_forge/src/writer_core/staging.rs#L778)、[card_plan.rs:48](../../../anki_forge/src/writer_core/card_plan.rs#L48)、[apkg.rs:650](../../../anki_forge/src/writer_core/apkg.rs#L650)。authoring normalize 的字段集合和 writer SQL 的布局已按模型准备，余下重复属于 staging/card planner，不能笼统再说“每 note 都重建所有布局”。

**可证伪预测：**固定总笔记和字段字节，把模型数从 1 增到 32/128，或增至 8 个模板，会放大相关 stage 耗时；显式 ID/隐式 ID 的 Project 对照能隔离 identity 计算。长 Cloze 同时增加 marker 数，观察重复扫描是否成为可观比例。

**候选：**仅把不可变模型元数据与模板解析结果按 build 预计算；对借用 Project 的 identity reuse 重新以此类负载单独验证。此前通用身份复用原型在 10K 仅约 1.2% 时间改善，RSS +2.58 MiB，长字段反而更慢，已被拒绝；不应不加区分重新引入长生命周期缓存。

### 6. 极端文本：HTML 清洗存在可构造的平方扫描

`strip_html_preserving_media_filenames` 遇到未闭合 `<` 时，`find_html_tag_end` 扫描剩余字符串后仅前进一个字符；输入 `"<".repeat(n)` 导致逐个后缀重扫：[html_text.rs:17](../../../anki_forge/src/authoring_core/html_text.rs#L17)、[html_text.rs:51](../../../anki_forge/src/authoring_core/html_text.rs#L51)。raw-text tag 搜索在每个伪闭合候选后再次 lowercase 整个后缀：[html_text.rs:68](../../../anki_forge/src/authoring_core/html_text.rs#L68)。

**可证伪预测：**分开测实际源码函数直接调用、公开 `Deck::basic().note().add()` 和真正 APKG export；输入为 4/8/16/32 KiB 连续 `<`，同长度 `A` 为对照。直接清洗应呈近平方增长，真实 export 应通过 writer 的 sfld/checksum 清洗体现这一成本。Basic add 的身份路径只做 Unicode/换行规范化及 canonical hash，不调用此 HTML 清洗函数，因而是路径隔离对照，不能从直接清洗的曲线推断 add 也平方增长。每次仅一条笔记、限制最大输入及进程时长。含 `</scriptx>` 重复候选再加合法 `</script>` 可另检验 raw-text 扫描。

**候选：**记录没有闭合 tag 的后缀状态、避免重复 lowercase，或采用语义等价的单向游标。此函数直接影响 writer 的 sfld/checksum，以及 card planner 中相应字段判定；Basic add 的身份规范化不在此函数内，见 [identity.rs:107](../../../anki_forge/src/deck/identity.rs#L107)。回归应比较清洗输出、字段/卡片和包结果，并确认 GUID 不变，不能笼统称为修改 identity 算法。源码层面复杂度明确，本静态审查未运行重现；直接函数、公开 add 与真实 export 的测量结果应分别报告，不能作为普通 Basic 基准变慢的证据。

## Binding 与验证覆盖缺口

Python 每次导出重新校验并构造完整 product dict，`json.dumps` 成完整字符串、写临时文件，然后启动 CLI；Rust 子进程再解析。位置：[project.py:107](../../../bindings/python/src/anki_forge/project.py#L107)、[project.py:161](../../../bindings/python/src/anki_forge/project.py#L161)、[runtime.py:151](../../../bindings/python/src/anki_forge/runtime.py#L151)。先分离 Python serialization、spawn/runtime、Rust build 与报告解析，再判断流式 JSON 写入或进程内 binding 的收益。后者是交付、崩溃隔离和状态语义设计，不能仅凭“少一次 subprocess”决定。

当前历史基准明确[未包含 Node/Python](../../../benchmarks/README.md#L3)。下一批矩阵至少应有：

| 维度 | 最小覆盖 |
| --- | --- |
| 导出入口 | Rust Deck、借用 Project、Node Deck/Project、Python Project；首次/常驻后续构建分开 |
| 文本/模板 | Basic 显式/隐式 ID、Cloze、1/32/128 自定义模型、1/8 模板、短/长/宽字段、畸形 HTML |
| 更新 | 无 baseline、相同 baseline、1%/100% 修改、lockfile 更新、损坏/超预算 baseline |
| 存储 | 默认临时、artifacts、独立 CAS/base_dir、self-contained、bytes/write_to 返回整包 |
| 媒体 | path/inline、文件数/总字节分别控制、同内容复用、冷/热 CAS |
| 服务 | 1/2/4 个独立任务，吞吐与 p50/p95、宿主加所有子进程的 RSS、事件循环延迟、任务后驻留 |

每个候选采用同会话交错对照；单独测 RSS/分配，记录源码/输入/二进制/供电身份，测量期间不编译。默认路径保持实际输出 inspection、来源变更检测、资源限额、身份修订、原子发布与错误顺序。优先级以当前实测阶段占比调整；本报告没有宣称这些候选已经加速或完成验收。
