# 2026-09-08 性能优化验证证据

实现、结论与限制见 [实施报告](../../../docs/superpowers/specs/2026-09-08-performance-optimization-implementation.md)。基线为 main `c665271`；此目录记录本地 macOS ARM64 同轮对照，不是跨平台性能承诺。

- `summary.json`：29 种默认输入和三种目标出口的独立计时/RSS样本、分位范围。
- `runs/`：预先声明的输入、二进制/基线哈希、全部启动/完成记录与供电检查。每组自身的前后 APKG 必须逐字节相等。
- `verification-final/`：原始 SQLite/媒体、固定 Anki 后端导入/渲染，以及旧/新完整 inspection report 精确相同的最终核验；每次成功导出用 SHA-256 关联到已独立验证的产物。`verification/` 保留测量工具修正前的初次核验。
- `build-final.json`、`initial.json`：冻结的源码、二进制与验证工具身份；生产改动另存 `production.patch`，新文件也包括在内。
- `measurement-correction.json`：首次默认组的优化后可执行文件因共用 Cargo target 目录而成为私有 API 探针。`runs/default-timing` 与 `runs/default-rss` 的 928 次导出和初次核验完整保留，但排除出默认路径结论；单独 target 重建后的 `runs/default-standard-*` 才是报告使用的 29 格对照。
- `html-attempts.jsonl`、`html_before.rs`：相同 HTML 探针的前后结果及旧实现 oracle。旧版 32 KiB 公开导出在上轮达到预算，本轮预先不运行该格，未据此生成速度比。
- `quality.json`、`logs.tar.gz`：完整 CI、额外特性验证、故意失败的回归、编译/测量过程日志。`preserve_order` 的旧数据库字节测试在未修改 main 上同样失败；没有删掉或改写固定资产来让它通过。
- `api-source/`、`scripts/`：实际测量工具。复制到相同 `.work/main-optimization-20260908` 结构再执行，或按元数据修正路径；原脚本中的输出目录禁止覆盖，重复测量应使用新目录名称。依赖与输入生成参照前一轮审计和 `benchmarks/README.md`。

不归档生成 APKG 或可执行文件；重放需要同一基线/生产补丁、锁文件、冻结输入及其相对媒体文件。前后 builds 均为 release/system allocator/default public features。`write_to` 使用 File sink；持久化每次新建目录，热 CAS 只有功能验证。时间与 RSS 分开采样，HTML 为单进程内调用计时，不能与进程端到端耗时相减。
