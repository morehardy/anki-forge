from pathlib import Path
import subprocess,json,sys
W=Path(__file__).resolve().parent
R=W.parents[2]
P=R/'benchmarks/.venv/bin/python'

def run(name,args):
    with (W/f'{name}.log').open('w') as log:
        subprocess.run([str(P),str(W/'run.py'),name,*args],stdout=log,stderr=subprocess.STDOUT,check=True)
    print(name,'complete',flush=True)

def pairs(name,variants,cases=None,overrides=None,warm=2,time_n=7,rss_n=5):
    args=list(variants)
    if cases:args+=['--cases',*cases]
    for variant,env in (overrides or {}).items():
        for key,value in env.items():args+=['--env',f'{variant}:{key}={value}']
    run(name+'-timing',args+['--warmups',str(warm),'--repeats',str(time_n)])
    run(name+'-rss',args+['--warmups',str(warm),'--repeats',str(rss_n)])

# Correctness work finishes before timing, not concurrently with it.
with (W/'html-differential-final.log').open('w') as log:
    subprocess.run([str(W/'binaries/html-differential-final')],stdout=log,stderr=subprocess.STDOUT,check=True)
html=[]
for variant,binary in [('before','before-html'),('after','after-html-final')]:
    for operation in ['strip','public_export']:
        for kib in [4,8,16,32]:
            if variant=='before' and operation=='public_export' and kib==32:continue
            command=[str(W/'binaries'/binary),operation,'unclosed_lt',str(kib)]
            power=subprocess.check_output(['pmset','-g','batt'],text=True)
            assert 'AC Power' in power.splitlines()[0]
            result=subprocess.run(command,capture_output=True,text=True,timeout=90)
            record={'variant':variant,'operation':operation,'kib':kib,'returncode':result.returncode,'power':power,'stdout':result.stdout,'stderr':result.stderr}
            with (W/'html-attempts.jsonl').open('a') as output:output.write(json.dumps(record)+'\n')
            assert result.returncode==0,record
print('HTML direct/public measurements complete',flush=True)
pairs('default',['before-current','after-current'])
cases=['text-1000','text-10000','long-back-quadruple-1000','image-1000','image-64x1m']
pairs('copy',['before-api','after-api'],cases,{v:{'ANKI_AUDIT_MODE':'write-to'} for v in ['before-api','after-api']})
pairs('compare',['before-api','after-api'],cases,{v:{'ANKI_AUDIT_MODE':'compare','ANKI_AUDIT_STABLE_ID':'main-performance-audit'} for v in ['before-api','after-api']})
pairs('persistent',['before-api','after-api'],['text-1000','image-1000','image-64x1m'],{v:{'ANKI_AUDIT_MODE':'persistent'} for v in ['before-api','after-api']},warm=1,time_n=5,rss_n=3)
print('ALL MEASUREMENTS COMPLETED',flush=True)
