"""Rerun the full default matrix after isolating the standard adapter build."""
from pathlib import Path
import subprocess

W=Path(__file__).resolve().parent
R=W.parents[2]
for metric,repeats in [('timing',7),('rss',5)]:
    name=f'default-standard-{metric}'
    with (W/f'{name}.log').open('w') as log:
        subprocess.run([str(R/'benchmarks/.venv/bin/python'),str(W/'run.py'),name,
                        'before-current','after-standard','--warmups','2','--repeats',str(repeats)],
                       stdout=log,stderr=subprocess.STDOUT,check=True)
    print(name,'complete',flush=True)
