from pathlib import Path
import json

W=Path(__file__).resolve().parent
R=W.parents[2]
summary=json.loads((W/'summary.json').read_text())
assert summary['verification']['status']=='passed'
report=R/'docs/superpowers/specs/2026-09-08-performance-optimization-implementation.md'
marker='\n### HTML：连续未闭合 `<`\n'
prefix=report.read_text().split(marker)[0].rstrip()
parts=[marker]
parts.append('每格 1 次预热 + 5 次函数调用。HTML 探针逐格检查 AC Power，但前后实现分块运行，没有交替单次调用。公开导出只计 `Deck::build`，不含输入准备、加卡、进程启动和销毁；不能与 collector 的端到端时间直接相减。\n')
parts.append('| Front 大小 | 清洗前 ms | 清洗后 ms | 单卡构建前 ms | 单卡构建后 ms |\n| --- | ---: | ---: | ---: | ---: |')
html={(h['variant'],h['operation'],h['bytes']//1024):h['median_ns']/1e6 for h in summary['html']}
for k in [4,8,16,32]:
    before_export=html.get(('before','public_export',k))
    before_text=f'{before_export:.3f}' if before_export is not None else '预先排除，未测'
    parts.append(f"| {k} KiB | {html['before','strip',k]:.3f} | {html['after','strip',k]:.6f} | {before_text} | {html['after','public_export',k]:.3f} |")
parts.append('\n16 KiB 公开单卡构建耗时降低约 99.3%。旧版 32 KiB 公开导出在前一轮触发累计预算，因此本轮预先不运行该格，不发布它的前后速度比。其他 15 格的所有 90 次调用均完成，包含 42 次公开构建。43.6 万组差分检查之外，正式复杂度回归还覆盖带闭合符但被引号遮蔽、未闭合注释和 raw-text 伪闭合前缀，避免只修复这一种输入。\n')

def table(group):
    lines=['| 场景 | 前 ms | 后 ms | 耗时变化 | 前 RSS MiB | 后 RSS MiB |',
           '| --- | ---: | ---: | ---: | ---: | ---: |']
    for row in summary['groups'][group]:
        before=next(v for k,v in row['variants'].items() if k.startswith('before'))
        after=next(v for k,v in row['variants'].items() if k.startswith('after'))
        lines.append(f"| {row['case']} | {before['time_ms']['median']:.2f} | {after['time_ms']['median']:.2f} | {-row['time_reduction']*100:+.1f}% | {before['rss_mib']['median']:.2f} | {after['rss_mib']['median']:.2f} |")
    return '\n'.join(lines)

parts.extend(['### `write_to`：大包内存降低\n',table('copy'),
              '\n1,000 图片和 64 个 1 MiB 文件的峰值 RSS 分别降低约 60.4% 和 69.4%。这是峰值进程内存，不是只统计输出缓冲。纯文字仍可能由卡片、SQLite 或检查阶段决定峰值；万条文字和长字段没有测得内存收益。1,000 文字耗时增加约 3.2%，64 个大文件约增加 0.5%，因此不能把有界拷贝概括为普遍提速。\n',
              '### `compare_to`：减少观察数据复制\n',table('compare'),
              '\n万条文字耗时降低约 33.2%，峰值 RSS 降低约 38.6%。64 个大文件耗时增加约 3.5%；该组前后时间 IQR 分别约 24.22 / 25.35 ms，当前数据不支持此负载提速。这里只测内容未修改、身份一致的完整比较；没有测 1%/100% 更新或完整 lockfile 工作流。\n',
              '### 持久化：保留同步屏障，重叠 I/O 等待\n',table('persistent'),
              '\n1,000 图片耗时降低约 26.3%，64 个大文件降低约 21.1%；内存中位数各增加约 0.64 / 0.34 MiB。并发上限为四个任务，不能据此承诺四倍吞吐。无媒体的文字对照没有并发媒体任务，仍测得约 +5.4% 的端到端差异；五次样本不能据此判定稳定回退或完成归因，也不能宣称全部持久化场景都更快。上述结果没有减少每文件 `sync_all`，也不覆盖热 CAS 性能。\n',
              '### 默认导出：完整 29 格\n'])
changes=[-r['time_reduction']*100 for r in summary['groups']['default']]
parts.append(f'下表采用隔离 target 目录重新构建的标准适配器。29 格中位耗时变化为 {min(changes):+.1f}%～{max(changes):+.1f}%，不是统计显著性判定或跨机器的回退保证。默认出口没有本轮目标慢路径的同等幅度收益。\n')
parts.append(table('default'))
parts.append('\n其中 `image-64x1m` 的中位耗时增加约 4.8%，前后 IQR 为 10.90 / 13.30 ms；`mixed-200` 增加约 3.1%。保留这些负向结果，不将默认矩阵描述为全部提速或已证明没有回退。')
v=summary['verification']
parts.extend(['\n## 产物核验与测量修正\n',
              f"本报告采用的 collector 记录共 **{v['collector_exports']:,} 次成功导出**，包含预热、计时与 RSS；每组预声明的案例、实现和样本编号集合完整，全部正常退出，没有遗留子进程。每个模式内，前后实现及所有重复的 APKG 均逐字节相同。全部导出通过输入 SHA-256 与产物 SHA-256 关联到 **{v['distinct_raw_and_anki_artifacts']} 份独立验证的内容组合**：原始 SQLite 行/媒体、固定 Anki 后端导入及渲染均通过。旧/新检查器对同一实际文件输出的完整 inspection JSON 也精确相同，覆盖全部 observation、evidence ref、状态及 artifact fingerprint。\n",
              'HTML 差分 oracle 在最终源码重新编译后再次完成 435,928 组等价检查。最终验证同时核对生产源码、私有适配器源码、标准适配器源码、各二进制和 collector/inspection/Anki 工具的冻结哈希；正式标准适配器路径已恢复为正确的新版本。\n',
              '首轮普通路径测量在产物核验后发现工具身份问题：标准适配器和私有 API 探针共用了 Cargo target 目录，输出文件同名，首次 `after-current` 与 `after-api` 实际字节相同。首轮默认组的 **928 次成功导出全部排除出默认路径结论**，完整保留原始记录及初次核验。随后使用独立 target 构建标准适配器，重跑全部 29 格时间和 RSS，没有按性能挑选重跑格或样本。其他三组一直使用成对的同一私有适配器，无需因此重测。具体修正见 [measurement-correction.json](../../../benchmarks/results/20260908-main-optimization/measurement-correction.json)。\n',
              '所有原始样本、构建身份、完整 CI 和额外特性的失败日志、回归测试修复前失败、最终源码补丁及重放脚本见 [证据目录](../../../benchmarks/results/20260908-main-optimization/README.md)；产物核验索引见 [verification-final/summary.json](../../../benchmarks/results/20260908-main-optimization/verification-final/summary.json)。没有删除失败样本或修改固定旧数据库资产。\n',
              '## 后续范围\n',
              '本轮完成审计中优先级最高的四项实现。默认万条文字的 SQLite 参数构造、绑定、step/commit/VACUUM 分解，以及实际 Node/Python 性能、Cloze/多模板、热 CAS、长期并发和 Linux/其他存储设备仍需独立测量。没有把当前 Rust Basic/File sink 的结果外推到这些场景。改动保留在当前工作区，未提交或推送。\n'])
report.write_text(prefix+'\n'+ '\n'.join(parts))
print(report)
