from pathlib import Path
import json,statistics
W=Path(__file__).resolve().parent

def stats(values):
 values=sorted(values)
 q=statistics.quantiles(values,n=4,method='inclusive')
 return {'n':len(values),'median':statistics.median(values),'min':min(values),'max':max(values),'iqr':q[2]-q[0],'samples':values}
summary={'base_commit':'c665271b0af9ec7badd2be57b516bf58afac15cd','quality':json.loads((W/'quality.json').read_text()),'groups':{}}
for group,prefix in {'default':'default-standard','copy':'copy','compare':'compare','persistent':'persistent'}.items():
 timed=[json.loads(l) for l in (W/f'{prefix}-timing/attempts.jsonl').read_text().splitlines()]
 rss=[json.loads(l) for l in (W/f'{prefix}-rss/attempts.jsonl').read_text().splitlines()]
 rows=[]
 for case in sorted({r['case'] for r in timed}):
  entry={'case':case,'variants':{}}
  for variant in sorted({r['variant'] for r in timed}):
   t=[r for r in timed if r['case']==case and r['variant']==variant and r['sample']>=0]
   m=[r for r in rss if r['case']==case and r['variant']==variant and r['sample']>=0]
   entry['variants'][variant]={'time_ms':stats([r['measurement']['elapsed_ns']/1e6 for r in t]),'rss_mib':stats([r['measurement']['peak_rss_bytes']/2**20 for r in m]),'artifact_sha256':t[0]['artifact_sha256']}
  before=next(v for k,v in entry['variants'].items() if k.startswith('before'))
  after=next(v for k,v in entry['variants'].items() if k.startswith('after'))
  entry['time_reduction']=1-after['time_ms']['median']/before['time_ms']['median']
  entry['rss_reduction']=1-after['rss_mib']['median']/before['rss_mib']['median']
  rows.append(entry)
 summary['groups'][group]=rows
html=[]
for l in (W/'html-attempts.jsonl').read_text().splitlines():
 r=json.loads(l)
 for data in map(json.loads,r['stdout'].splitlines()):
  if data['kind']=='summary':html.append(dict(variant=r['variant'],**data))
summary['html']=html
summary['verification']=json.loads((W/'verification-final/summary.json').read_text()) if (W/'verification-final/summary.json').exists() else 'pending'
summary['measurement_correction']=json.loads((W/'measurement-correction.json').read_text())
(W/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for group,rows in summary['groups'].items():
 print(group)
 for row in rows:
  print(row['case'],{k:(round(v['time_ms']['median'],3),round(v['rss_mib']['median'],2)) for k,v in row['variants'].items()},'time saved',round(row['time_reduction']*100,1))
