from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[2]
sys.path.insert(0,str(R/'benchmarks'))
import bench,verify
cases={c['name']:c for c in json.loads((W/'cases.json').read_text())}
V=W/'verification-final';V.mkdir(exist_ok=True)
run_prefixes={'default':'default-standard','copy':'copy','compare':'compare','persistent':'persistent'}
known={};bindings={};count=0
for run_name in [f'{prefix}-timing' for prefix in run_prefixes.values()]:
 rows=[json.loads(line) for line in (W/run_name/'attempts.jsonl').read_text().splitlines()]
 for row in rows:
  if row['sample']!=0:continue
  name=row['case'];variant=row['variant'];case=cases[name]
  artifact=W/run_name/f'{name}-{variant}-0/output.apkg'
  key=(case['input_sha256'],row['artifact_sha256'])
  assert bench.sha256(artifact)==row['artifact_sha256']
  if key not in known:
   dest=V/f'{run_name}-{name}-{variant}';dest.mkdir(exist_ok=True)
   document=json.loads(Path(case['path']).read_text())
   raw=verify.verify_artifact(artifact,document,bench.INSPECTOR)
   (dest/'raw.json').write_text(json.dumps(raw,indent=2)+'\n')
   assert raw['status']=='passed',raw
   # The independent pre-change inspector must emit exactly the same full
   # observation report and fingerprint for this same path and actual bytes.
   previous=subprocess.run([str(W/'binaries/before-inspector'),'inspect','--apkg',str(artifact),'--output','contract-json'],capture_output=True,timeout=120,check=True)
   old_hash=hashlib.sha256(previous.stdout).hexdigest()
   assert old_hash==raw['semantic']['inspection_sha256'],(name,'inspection report changed')
   (dest/'report-equivalence.json').write_text(json.dumps({'status':'passed','exact_inspection_report_sha256':old_hash,'includes':'all observations, evidence refs, statuses and artifact fingerprint'},indent=2)+'\n')
   with (dest/'oracle.stdout.log').open('w') as out,(dest/'oracle.stderr.log').open('w') as err:
    subprocess.run([str(bench.ORACLE),case['path'],str(artifact),str(dest/'anki.json')],stdout=out,stderr=err,timeout=120,check=True)
   assert json.loads((dest/'anki.json').read_text())['status']=='passed'
   known[key]=str(dest.relative_to(W));count+=1
  bindings[f'{run_name}/{name}/{variant}']=known[key]
 print('verified',run_name,flush=True)
for group,prefix in run_prefixes.items():
 for metric in ['timing','rss']:
  name=f'{prefix}-{metric}';run=W/name;plan=json.loads((run/'plan.json').read_text())
  rows=[json.loads(line) for line in (run/'attempts.jsonl').read_text().splitlines()]
  expected=Counter((c['name'],v,i) for c in plan['cases'] for v in plan['args']['variants'] for i in range(-plan['args']['warmups'],plan['args']['repeats']))
  assert Counter((r['case'],r['variant'],r['sample']) for r in rows)==expected
  assert len(rows)==len((run/'launches.jsonl').read_text().splitlines())
  assert (run/'summary.json').exists()
  for row in rows:
   assert row['measurement']['reaped'] and not any(row['measurement'][k] for k in ['exit_code','signal','spawn_error','leftover_descendants','interrupted_signal'])
   assert all('AC Power' in row[k].splitlines()[0] for k in ['power_before','power_after'])
   assert (cases[row['case']]['input_sha256'],row['artifact_sha256']) in known
   if group=='compare':assert 'comparison=Complete' in (run/f"{row['case']}-{row['variant']}-{row['sample']}/stdout.log").read_text()
  # Equality is per mode before/after; compare metadata is intentionally not
  # conflated with the baseline-free container.
  for case in plan['cases']:
   assert len({r['artifact_sha256'] for r in rows if r['case']==case['name']})==1
  for baseline in plan['baseline_identities'].values():assert bench.sha256(Path(baseline['path']))==baseline['sha256']
  for variant,expected_sha in plan['binaries'].items():assert bench.sha256(W/'binaries'/variant)==expected_sha
  bindings[name]={'verified_exports':len(rows),'exact_before_after_bytes':True}
final=json.loads((W/'build-final.json').read_text())
for name,digest in final['source_files'].items():assert bench.sha256(R/name)==digest,name
for name,digest in final['executables'].items():assert bench.sha256(W/'binaries'/name)==digest,name
for name,digest in final['api_source_files'].items():assert bench.sha256(W/'api-source'/name)==digest,name
for name,digest in final['standard_adapter_source_files'].items():assert bench.sha256(R/name)==digest,name
assert bench.sha256(R/'benchmarks/adapters/rust/target/release/anki-forge-benchmark')==final['executables']['after-standard']
assert final['executables']['after-standard']!=final['executables']['after-api']
for name,path in [('collector',R/'benchmarks/.tools/measure'),('inspector',bench.INSPECTOR),('oracle',bench.ORACLE)]:assert bench.sha256(Path(path))==final[f'{name}_sha256']
html=[json.loads(line) for line in (W/'html-attempts.jsonl').read_text().splitlines()]
expected_html={(v,op,k) for v in ['before','after'] for op in ['strip','public_export'] for k in [4,8,16,32]}-{('before','public_export',32)}
assert Counter((r['variant'],r['operation'],r['kib']) for r in html)==Counter(expected_html)
for cell in html:
 assert cell['returncode']==0 and 'AC Power' in cell['power'].splitlines()[0]
 messages=[json.loads(line) for line in cell['stdout'].splitlines()]
 samples=[m for m in messages if m['kind']=='sample']
 assert sorted(m['index'] for m in samples)==list(range(-1,5))
 assert all(m['correct'] for m in samples)
 assert len([m for m in messages if m['kind']=='summary'])==1
assert '435928' in (W/'html-differential-final.log').read_text()
summary={'status':'passed','distinct_raw_and_anki_artifacts':count,'bindings':bindings,'collector_exports':sum(v['verified_exports'] for v in bindings.values() if isinstance(v,dict)),'production_sources_match_frozen_build':True}
summary.update(html_complete_cells=len(html),html_calls=6*len(html),html_public_exports=6*sum(r['operation']=='public_export' for r in html),html_differential_cases=435928)
(V/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='bindings'}),flush=True)
