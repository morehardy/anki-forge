# 优化后复测与瓶颈诊断

结论见 [复测报告](../../../docs/superpowers/specs/2026-09-08-post-optimization-bottleneck-audit.md)。本轮生产代码未修改；冻结状态是 main c665271 加上一轮四项优化，完整源码补丁在 `production-state.patch`。

- `summary.json`：普通 29 格、write_to/compare_to/持久化入口、独立阶段计时和内存边界数据。`units` 明确各层单位，不能将累计并发时间当作串行占比，也不能把累计 Rust 峰值当成某阶段独占峰值。
- `session-power.json`：以实际基准子进程读数选择的供电模式。早期 AC 启动保护停止两次，均没有计时样本；此后按完整会话的固定供电条件测量，不能和上轮 AC 绝对耗时相减。
- `runs/`：每组预声明计划、全部启动/完成记录和每次导出的原生供电、时间、RSS、产物哈希。普通与目标入口的计时/RSS是分别采样的；`probe-*` 和 `memory-*` 仅用于诊断。
- `verification/`：独立原始 SQLite/媒体检查、固定 Anki 导入/渲染、旧新完整检查报告一致性，以及所有导出的 SHA-256 关联。
- `source-snapshot.json`、`build-final.json`、`profile-source.json`：当前生产源码、标准/API/诊断二进制和诊断源码身份；正式标准适配器没有被私有构建覆盖。
- `profile-source.patch`、`diag.rs`、`profile-adapter/`：本轮私有探针。基于当前生产快照的独立副本重放；不要把探针补丁应用到生产工作区。`api-source/` 记录普通 API 对照与 HTML 探针原始源码。
- `logs.tar.gz`：完整工具测试、构建、启动失败、烟雾验证和逐次采样日志。首个内存烟雾运行被沙箱禁止读取自身 RSS，提升读取权限后的整组烟雾验证通过，失败日志保留。
- `scripts/`：本轮实际使用的准备、采样、核验和报告脚本。路径按原 `.work/post-optimization-audit-20260908` 布局记录；重放时需要冻结输入、媒体和比较基线，使用新的输出目录。

不归档 APKG 和可执行文件。Rust 计数器覆盖经全局 System 分配器的请求，不包含 SQLite/zstd 原生分配、分配器保留或进程全部驻留内存；ps 的 RSS 是阶段边界快照。内存探针的时间不参与性能结论。单次本机会话、合成 Basic 卡片与 File sink，未控制冷缓存、温度和 CPU 频率；没有测实际 Node/Python 绑定、热 CAS、Linux 或真实用户负载。
