//! Private diagnostic scopes; never distributed in the product.
use std::{collections::{BTreeMap, HashSet}, sync::{Mutex, OnceLock}, thread::ThreadId, time::Instant};
static OBSERVER: OnceLock<fn(&str, bool)> = OnceLock::new();
static EPOCH: OnceLock<Instant> = OnceLock::new();
pub fn install_observer(observer: fn(&str, bool)) { let _ = OBSERVER.set(observer); }
pub struct Scope(&'static str, Instant);
impl Scope {
    pub fn new(label: &'static str) -> Self {
        EPOCH.get_or_init(Instant::now);
        if let Some(observer) = OBSERVER.get() { observer(label, true); }
        Self(label, Instant::now())
    }
}
impl Drop for Scope {
    fn drop(&mut self) {
        let elapsed = self.1.elapsed().as_nanos();
        if let Some(observer) = OBSERVER.get() { observer(self.0, false); }
        eprintln!("[DEBUG-scale-opt] {} {}", self.0, elapsed);
    }
}
#[derive(Default)]
struct Counter { intervals: Vec<(u128,u128)>, threads: HashSet<ThreadId> }
static COUNTERS: OnceLock<Mutex<BTreeMap<&'static str, Counter>>> = OnceLock::new();
pub struct Accum(&'static str, Option<u128>);
impl Accum {
    pub fn new(label: &'static str) -> Self {
        // Per-row timing records would perturb the allocation-only probe.
        let start = if OBSERVER.get().is_some() { None } else { Some(EPOCH.get_or_init(Instant::now).elapsed().as_nanos()) };
        Self(label, start)
    }
}
impl Drop for Accum {
    fn drop(&mut self) {
        if let Some(start) = self.1 {
            let end = EPOCH.get().unwrap().elapsed().as_nanos();
            let mut all = COUNTERS.get_or_init(Default::default).lock().unwrap();
            let counter = all.entry(self.0).or_default();
            counter.intervals.push((start,end));
            counter.threads.insert(std::thread::current().id());
        }
    }
}
pub struct Report;
impl Drop for Report {
    fn drop(&mut self) {
        if let Some(all) = COUNTERS.get() {
            for (label, mut c) in std::mem::take(&mut *all.lock().unwrap()) {
                c.intervals.sort_unstable();
                let sum: u128 = c.intervals.iter().map(|(a,b)| b-a).sum();
                let mut union = 0; let mut last = 0;
                let mut edges = Vec::new();
                for &(a,b) in &c.intervals {
                    union += b.saturating_sub(a.max(last)); last = last.max(b);
                    if b>a { edges.push((a,1_i32)); edges.push((b,-1_i32)); }
                }
                edges.sort_unstable();
                let mut active = 0; let mut peak = 0;
                for (_,change) in edges { active += change; peak = peak.max(active); }
                eprintln!("[DEBUG-scale-opt] {} {}",label,sum);
                eprintln!("[DEBUG-post-audit-count] {} {}",label,c.intervals.len());
                eprintln!("[DEBUG-rebench-counter] {}",serde_json::json!({"label":label,"sum_ns":sum,"union_ns":union,"count":c.intervals.len(),"max_concurrent":peak,"thread_count":c.threads.len()}));
            }
        }
    }
}
