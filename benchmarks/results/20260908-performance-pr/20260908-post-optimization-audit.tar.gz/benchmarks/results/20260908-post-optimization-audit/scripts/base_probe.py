"""Create a private coarse probe for current main; do not build or measure.

Run this file once from its location in benchmarks/.work/main-audit-20260908.
It refuses to overwrite profile-source and never edits production sources or
the official adapter binary. Build the returned manifest in a private target
directory after generation. The diagnostic executable is not a timing baseline.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess


WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
SRC = WORK / "profile-source"
SOURCE_DIRS = ("anki_forge", "benchmarks/adapters/rust")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes(root):
    return {
        str(path.relative_to(root)): sha(path)
        for directory in SOURCE_DIRS
        for path in sorted((root / directory).rglob("*"))
        if path.is_file() and "target" not in path.relative_to(root / directory).parts
    }


def edit(file, old, new):
    path = SRC / file
    source = path.read_text()
    assert source.count(old) == 1, (file, old, source.count(old))
    path.write_text(source.replace(old, new))


def scope(file, function, label):
    path = SRC / "anki_forge/src" / file
    source = path.read_text()
    matches = list(re.finditer(r"\bfn " + re.escape(function) + r"\s*(?:<[^\n]*>)?\s*\(", source))
    assert len(matches) == 1, (file, function, len(matches))
    offset = source.index("{", matches[0].end()) + 1
    variable = "_audit_" + label.replace(".", "_")
    path.write_text(source[:offset] + f'\n    let {variable} = crate::diag::Scope::new("{label}");' + source[offset:])


# Each measured scope is inclusive elapsed wall time. Parent/child scopes
# overlap and are never additive. Media worker CPU time is not measured here.
SCOPES = [
    ("product/project/deck_import.rs", "from_deck", "deck.to_project", "adapter.export"),
    ("product/project/pipeline.rs", "execute", "pipeline.total", "adapter.export"),
    ("product/project/pipeline.rs", "prepare", "pipeline.prepare", "pipeline.total"),
    ("product/project/pipeline/reconcile.rs", "reconcile", "pipeline.reconcile", "pipeline.total"),
    ("product/project/pipeline.rs", "generate", "pipeline.generate", "pipeline.total"),
    ("product/project/pipeline.rs", "inspect", "pipeline.inspect", "pipeline.total"),
    ("product/project/pipeline.rs", "publish", "pipeline.publish", "pipeline.total"),
    ("product/project/pipeline.rs", "finish", "pipeline.finish", "pipeline.total"),
    ("product/project/input.rs", "validate", "project.validate", "pipeline.prepare"),
    ("runtime/defaults.rs", "load_embedded_writer_defaults", "runtime.defaults", "pipeline.prepare"),
    ("product/project/input.rs", "normalize_for_build", "normalize.with_identity", "pipeline.prepare"),
    ("product/project.rs", "into_build_lowering", "normalize.lowering", "normalize.with_identity"),
    ("product/project/input.rs", "lower_with_project_error", "normalize.borrowed_lowering", "normalize.with_identity"),
    ("authoring_core/normalize.rs", "normalize_with_prepared_media", "normalize.core", "normalize.with_identity"),
    ("authoring_core/normalize.rs", "resolve_media_references", "normalize.media_refs", "normalize.core"),
    ("prepared_media.rs", "prepare_all", "media.prepare", "normalize.core"),
    ("writer_core/staging.rs", "validate_normalized_ir", "writer.validate", "pipeline.generate"),
    ("writer_core/staging.rs", "materialize_with_prepared_media", "writer.staging", "pipeline.generate"),
    ("writer_core/apkg.rs", "emit_apkg_with_plans", "apkg.total", "pipeline.generate"),
    ("writer_core/apkg.rs", "create_latest_collection_file", "sqlite.total", "apkg.total"),
    ("writer_core/apkg.rs", "populate_latest_collection", "sqlite.populate", "sqlite.total"),
    ("writer_core/apkg.rs", "write_zstd_collection_entry", "apkg.collection_zstd_retained", "apkg.total"),
    ("writer_core/inspect.rs", "read_apkg_facts", "inspect.facts", "pipeline.inspect"),
    ("writer_core/inspect.rs", "read_collection_data", "inspect.sqlite", "inspect.facts"),
    ("writer_core/inspect.rs", "read_media_entries", "inspect.media", "inspect.facts"),
]


def main():
    assert not SRC.exists(), f"Refusing to overwrite {SRC}"
    before = source_hashes(ROOT)
    SRC.mkdir()
    for name in ("Cargo.lock", "rust-toolchain.toml"):
        shutil.copy2(ROOT / name, SRC / name)
    (SRC / "Cargo.toml").write_text(
        '[workspace]\nmembers = ["anki_forge"]\nresolver = "2"\n'
        '[workspace.package]\nedition = "2021"\nrust-version = "1.92"\n'
        '[workspace.lints.rust]\nunsafe_code = "forbid"\n'
    )
    for name in SOURCE_DIRS:
        shutil.copytree(ROOT / name, SRC / name, ignore=shutil.ignore_patterns("target"))
    assert before == source_hashes(SRC), "Source changed while copying"
    (SRC / "anki_forge/src/diag.rs").write_text('''//! Private inclusive elapsed-time scopes, excluded from production.
use std::time::Instant;
pub struct Scope(&'static str, Instant);
impl Scope {
    pub fn new(label: &'static str) -> Self { Self(label, Instant::now()) }
}
impl Drop for Scope {
    fn drop(&mut self) {
        let elapsed = self.1.elapsed().as_nanos();
        eprintln!("[DEBUG-scale-opt] {} {}", self.0, elapsed);
    }
}
''')
    library = SRC / "anki_forge/src/lib.rs"
    library.write_text(library.read_text() + '\n#[allow(missing_docs)]\npub mod diag;\n')
    for file, function, label, _parent in SCOPES:
        scope(file, function, label)

    apkg = "anki_forge/src/writer_core/apkg.rs"
    edit(apkg,
         "        let transaction = conn.unchecked_transaction()?;",
         '        let _audit_schema = crate::diag::Scope::new("sqlite.schema");\n'
         "        let transaction = conn.unchecked_transaction()?;")
    edit(apkg,
         "    let compacted =\n",
         '    let audit_compact = crate::diag::Scope::new("sqlite.compact");\n'
         "    let compacted =\n")
    edit(apkg,
         "    let _ = fs::remove_file(&path);\n    Ok(compacted)",
         "    let _ = fs::remove_file(&path);\n    drop(audit_compact);\n    Ok(compacted)")
    # The lexical block includes encoder creation, encoding, flush and writer
    # destruction. Its guard drops at block end; it excludes subsequent ZIP
    # entry writing. The retained-artifact branch has its own distinct label.
    edit(apkg,
         "    let (size, crc) = {\n",
         "    let (size, crc) = {\n"
         '        let _audit_zstd = crate::diag::Scope::new("apkg.collection_zstd");\n')

    adapter = "benchmarks/adapters/rust/src/main.rs"
    edit(adapter,
         "    let workload: Workload =",
         '    let _audit_total = anki_forge::diag::Scope::new("adapter.total");\n'
         '    let audit_parse = anki_forge::diag::Scope::new("adapter.parse");\n'
         "    let workload: Workload =")
    edit(adapter,
         "    let mut deck = Deck::new(workload.deck_name);",
         "    drop(audit_parse);\n"
         '    let audit_registration = anki_forge::diag::Scope::new("adapter.registration");\n'
         "    let mut deck = Deck::new(workload.deck_name);")
    edit(adapter,
         "    for note in workload.notes {",
         "    drop(audit_registration);\n"
         '    let audit_notes = anki_forge::diag::Scope::new("adapter.notes");\n'
         "    for note in workload.notes {")
    edit(adapter,
         "    deck.write_apkg(output)?.ensure_success()?;",
         "    drop(audit_notes);\n"
         "    {\n"
         '        let _audit_export = anki_forge::diag::Scope::new("adapter.export");\n'
         "        deck.write_apkg(output)?.ensure_success()?;\n"
         "    }")

    # copy2 retains timestamps. Refresh this private tree to prevent Cargo's
    # timestamp-based freshness logic from reusing an earlier source variant.
    for directory in SOURCE_DIRS:
        for path in (SRC / directory).rglob("*"):
            if path.is_file():
                os.utime(path, None)
    assert before == source_hashes(ROOT), "Production source changed during setup"
    root_configs = {name: sha(ROOT / name) for name in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml")}
    metadata = {
        "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "source_files": before,
        "root_configuration": root_configs,
        "probe_source_files": source_hashes(SRC),
        "probe_workspace": {name: sha(SRC / name) for name in root_configs},
        "setup_script_sha256": sha(Path(__file__)),
        "manifest": str(SRC / "benchmarks/adapters/rust/Cargo.toml"),
        "measurement_semantics": {
            "unit": "nanoseconds",
            "scope": "inclusive elapsed wall time",
            "overlap": "Never add a parent to its children or add medians to derive exclusive costs.",
            "media_prepare": "Includes bounded worker scheduling, compression, ordered consumption and ZIP media writing; nested inside normalize.core.",
            "normalize_lowering": "Owned path includes identity extraction and source-path work. Compare with normalize.with_identity for historical versions.",
            "export": "Deck-to-Project plus build pipeline, report checks and cleanup; raw process time additionally includes launch and runtime shutdown.",
            "registered_media": "Includes Deck construction and input-parent setup, synchronous media.add and adapter map insertion.",
            "sqlite_compact": "Includes temporary target setup, VACUUM INTO, source connection close and source-file removal.",
            "hierarchy": [dict(label=label, parent=parent, file=file, function=function) for file, function, label, parent in SCOPES],
            "additional_scopes": {
                "adapter.total": "main after argument/metadata handling through final local destruction",
                "adapter.parse": "input read, JSON deserialization and schema/count validation",
                "adapter.registration": "after parse until all media registered",
                "adapter.notes": "render_field and public note builder calls",
                "adapter.export": "write_apkg and ensure_success only",
                "sqlite.schema": "schema transaction including commit",
                "sqlite.compact": "compaction after populate through source removal",
                "apkg.collection_zstd": "temporary-mode collection encoder block, excluding ZIP entry writing",
            },
            "probe_overhead": "Nested scopes include child stderr logging. Compare against same-session uninstrumented binary; do not score probe timings.",
        },
    }
    (WORK / "probe-source.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(SRC)
    print("Source prepared only; no executable built or benchmark run.")


if __name__ == "__main__":
    main()
