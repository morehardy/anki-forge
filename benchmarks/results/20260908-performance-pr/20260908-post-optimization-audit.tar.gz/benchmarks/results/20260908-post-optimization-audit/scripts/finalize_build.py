from pathlib import Path
import hashlib,json,subprocess
W=Path(__file__).resolve().parent
R=W.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
case=next(c for c in json.loads((W/'cases.json').read_text()) if c['name']=='text-100')
smoke=W/'probe-smoke-approved';smoke.mkdir(exist_ok=False)
hashes={}
for variant in ['after-api','profile-timing','profile-memory']:
 folder=smoke/variant;folder.mkdir();artifact=folder/'output.apkg'
 with (folder/'stdout.log').open('w') as out,(folder/'stderr.log').open('w') as err:
  result=subprocess.run([str(W/'binaries'/variant),case['path'],str(artifact)],stdout=out,stderr=err,timeout=120)
 assert result.returncode==0,(variant,(folder/'stderr.log').read_text()[-2500:])
 hashes[variant]=sha(artifact)
assert len(set(hashes.values()))==1,hashes
assert '[DEBUG-rebench-counter]' in (smoke/'profile-timing/stderr.log').read_text()
assert '[DEBUG-post-audit-memory]' in (smoke/'profile-memory/stderr.log').read_text()
(smoke/'result.json').write_text(json.dumps({'status':'passed','artifact_hashes':hashes,'initial_memory_smoke':'sandbox blocked ps; original failure log retained in probe-smoke/profile-memory/stderr.log'},indent=2)+'\n')
source=json.loads((W/'source-snapshot.json').read_text())['source_build_record']
source['executables']={p.name:sha(p) for p in (W/'binaries').iterdir()}
source['profile_source_record_sha256']=sha(W/'profile-source.json')
for name,h in source['source_files'].items():assert sha(R/name)==h,name
(W/'build-final.json').write_text(json.dumps(source,indent=2)+'\n')
print('Both diagnostic builds preserve exact APKG bytes; process memory and all-thread timing traces present.')
