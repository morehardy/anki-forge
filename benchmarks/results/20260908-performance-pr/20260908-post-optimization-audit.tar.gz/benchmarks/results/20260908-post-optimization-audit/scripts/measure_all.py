from pathlib import Path
import subprocess,json,sys,os
W=Path(__file__).resolve().parent
R=W.parents[2]
P=R/'benchmarks/.venv/bin/python'
REQUIRED_POWER=os.environ.get('ANKI_AUDIT_POWER_SOURCE','AC Power')
assert REQUIRED_POWER in ('AC Power','Battery Power')

def run(name,args):
    with (W/f'{name}.log').open('w') as log:
        subprocess.run([str(P),str(W/'run.py'),name,*args],stdout=log,stderr=subprocess.STDOUT,check=True)
    print(name,'complete',flush=True)

def pairs(name,variants,cases=None,overrides=None,warm=2,time_n=7,rss_n=5):
    args=list(variants)
    if cases:args+=['--cases',*cases]
    for variant,env in (overrides or {}).items():
        for key,value in env.items():args+=['--env',f'{variant}:{key}={value}']
    run(name+'-timing',args+['--warmups',str(warm),'--repeats',str(time_n)])
    run(name+'-rss',args+['--warmups',str(warm),'--repeats',str(rss_n)])

# Correctness work finishes before timing, not concurrently with it.
with (W/'html-differential-final.log').open('w') as log:
    subprocess.run([str(W/'binaries/html-differential-final')],stdout=log,stderr=subprocess.STDOUT,check=True)
html=[]
for variant,binary in [('before','before-html'),('after','after-html-final')]:
    for operation in ['strip','public_export']:
        for kib in [4,8,16,32]:
            if variant=='before' and operation=='public_export' and kib==32:continue
            command=[str(W/'binaries'/binary),operation,'unclosed_lt',str(kib)]
            power=subprocess.check_output(['pmset','-g','batt'],text=True)
            with (W/'html-power-checks.jsonl').open('a') as output:output.write(json.dumps({'variant':variant,'operation':operation,'kib':kib,'before':power})+'\n')
            assert REQUIRED_POWER in power.splitlines()[0]
            result=subprocess.run(command,capture_output=True,text=True,timeout=90)
            power_after=subprocess.check_output(['pmset','-g','batt'],text=True)
            record={'variant':variant,'operation':operation,'kib':kib,'returncode':result.returncode,'power':power,'power_after':power_after,'stdout':result.stdout,'stderr':result.stderr}
            with (W/'html-attempts.jsonl').open('a') as output:output.write(json.dumps(record)+'\n')
            assert result.returncode==0,record
            assert REQUIRED_POWER in power_after.splitlines()[0],record
print('HTML direct/public measurements complete',flush=True)
pairs('default',['before-current','after-standard'])
cases=['text-1000','text-10000','long-back-quadruple-1000','image-1000','image-64x1m']
pairs('copy',['before-api','after-api'],cases,{v:{'ANKI_AUDIT_MODE':'write-to'} for v in ['before-api','after-api']})
pairs('compare',['before-api','after-api'],cases,{v:{'ANKI_AUDIT_MODE':'compare','ANKI_AUDIT_STABLE_ID':'main-performance-audit'} for v in ['before-api','after-api']})
pairs('persistent',['before-api','after-api'],['text-1000','image-1000','image-64x1m'],{v:{'ANKI_AUDIT_MODE':'persistent'} for v in ['before-api','after-api']},warm=1,time_n=5,rss_n=3)
print('ALL MEASUREMENTS COMPLETED',flush=True)

# Profiling is a separate phase. These times are never used as benchmark scores.
profile_cases=['text-100','text-1000','text-10000','long-back-quadruple-1000','image-1000','image-64x1m']
def probe(name,variants,cases,mode,warm=1,n=3):
    args=[*variants,'--cases',*cases,'--warmups',str(warm),'--repeats',str(n)]
    for variant in variants:
        args+=['--env',f'{variant}:ANKI_AUDIT_MODE={mode}']
        if mode=='compare':args+=['--env',f'{variant}:ANKI_AUDIT_STABLE_ID=main-performance-audit']
    run(name,args)
probe('probe-default',['after-api','profile-timing'],profile_cases,'deck')
probe('probe-compare',['after-api','profile-timing'],cases,'compare')
probe('probe-persistent',['after-api','profile-timing'],['text-1000','image-1000','image-64x1m'],'persistent')
memory_cases=['text-10000','long-back-quadruple-1000','image-1000']
probe('memory-default',['profile-memory'],memory_cases,'deck',warm=0)
probe('memory-compare',['profile-memory'],memory_cases,'compare',warm=0)
probe('memory-copy',['profile-memory'],['image-1000','image-64x1m'],'write-to',warm=0)
print('ALL DIAGNOSTICS COMPLETED',flush=True)
