"""Select the actual child-process power profile before any timed samples."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess
W=Path(__file__).resolve().parent
R=W.parents[2]
assert not (W/'html-attempts.jsonl').exists()
assert not list(W.glob('*/attempts.jsonl'))
assert not (W/'session-power.json').exists()
power=subprocess.check_output(['/usr/bin/pmset','-g','batt'],text=True)
required=next(p for p in ['AC Power','Battery Power'] if p in power.splitlines()[0])
plan={'utc':datetime.now(timezone.utc).isoformat(),'required_power_source':required,'native_preflight':power,'profile_rule':'Every invocation must keep this exact power source. Earlier AC startup failures produced zero timed samples and are excluded. This run is compared only within the same session, not against earlier AC absolute timings.','orchestration_sha256':hashlib.sha256((W/'measure_all.py').read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256((W/'run.py').read_bytes()).hexdigest()}
(W/'session-power.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(plan),flush=True)
env=dict(os.environ,ANKI_AUDIT_POWER_SOURCE=required)
with (W/'measure-all.log').open('w') as log:
 subprocess.run([str(R/'benchmarks/.venv/bin/python'),str(W/'measure_all.py')],stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
print('Formal benchmarks and all diagnostics completed',flush=True)
