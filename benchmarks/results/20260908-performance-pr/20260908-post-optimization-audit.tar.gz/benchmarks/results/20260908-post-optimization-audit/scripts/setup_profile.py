"""Current-source diagnosis only; never edits the production crate."""
from pathlib import Path
import hashlib,json,os,re,shutil
import base_probe as base

W=Path(__file__).resolve().parent
R=W.parents[2]
S=W/'profile-source'
base.main()
shutil.copytree(R/'contracts',S/'contracts')
edit=base.edit

(S/'anki_forge/src/diag.rs').write_text(r'''//! Private diagnostic scopes; never distributed in the product.
use std::{collections::{BTreeMap, HashSet}, sync::{Mutex, OnceLock}, thread::ThreadId, time::Instant};
static OBSERVER: OnceLock<fn(&str, bool)> = OnceLock::new();
static EPOCH: OnceLock<Instant> = OnceLock::new();
pub fn install_observer(observer: fn(&str, bool)) { let _ = OBSERVER.set(observer); }
pub struct Scope(&'static str, Instant);
impl Scope {
    pub fn new(label: &'static str) -> Self {
        EPOCH.get_or_init(Instant::now);
        if let Some(observer) = OBSERVER.get() { observer(label, true); }
        Self(label, Instant::now())
    }
}
impl Drop for Scope {
    fn drop(&mut self) {
        let elapsed = self.1.elapsed().as_nanos();
        if let Some(observer) = OBSERVER.get() { observer(self.0, false); }
        eprintln!("[DEBUG-scale-opt] {} {}", self.0, elapsed);
    }
}
#[derive(Default)]
struct Counter { intervals: Vec<(u128,u128)>, threads: HashSet<ThreadId> }
static COUNTERS: OnceLock<Mutex<BTreeMap<&'static str, Counter>>> = OnceLock::new();
pub struct Accum(&'static str, Option<u128>);
impl Accum {
    pub fn new(label: &'static str) -> Self {
        // Per-row timing records would perturb the allocation-only probe.
        let start = if OBSERVER.get().is_some() { None } else { Some(EPOCH.get_or_init(Instant::now).elapsed().as_nanos()) };
        Self(label, start)
    }
}
impl Drop for Accum {
    fn drop(&mut self) {
        if let Some(start) = self.1 {
            let end = EPOCH.get().unwrap().elapsed().as_nanos();
            let mut all = COUNTERS.get_or_init(Default::default).lock().unwrap();
            let counter = all.entry(self.0).or_default();
            counter.intervals.push((start,end));
            counter.threads.insert(std::thread::current().id());
        }
    }
}
pub struct Report;
impl Drop for Report {
    fn drop(&mut self) {
        if let Some(all) = COUNTERS.get() {
            for (label, mut c) in std::mem::take(&mut *all.lock().unwrap()) {
                c.intervals.sort_unstable();
                let sum: u128 = c.intervals.iter().map(|(a,b)| b-a).sum();
                let mut union = 0; let mut last = 0;
                let mut edges = Vec::new();
                for &(a,b) in &c.intervals {
                    union += b.saturating_sub(a.max(last)); last = last.max(b);
                    if b>a { edges.push((a,1_i32)); edges.push((b,-1_i32)); }
                }
                edges.sort_unstable();
                let mut active = 0; let mut peak = 0;
                for (_,change) in edges { active += change; peak = peak.max(active); }
                eprintln!("[DEBUG-scale-opt] {} {}",label,sum);
                eprintln!("[DEBUG-post-audit-count] {} {}",label,c.intervals.len());
                eprintln!("[DEBUG-rebench-counter] {}",serde_json::json!({"label":label,"sum_ns":sum,"union_ns":union,"count":c.intervals.len(),"max_concurrent":peak,"thread_count":c.threads.len()}));
            }
        }
    }
}
''')

def accum(file,function,label):
    p=S/'anki_forge/src'/file;s=p.read_text()
    matches=list(re.finditer(r'\bfn '+re.escape(function)+r'\s*(?:<[^\n]*>)?\s*\(',s))
    assert len(matches)==1,(file,function)
    at=s.index('{',matches[0].end())+1
    p.write_text(s[:at]+f'\n    let _audit_fine = crate::diag::Accum::new("{label}");'+s[at:])

extra_scopes=[
 ('authoring_core/media.rs','ingest_authoring_media_with_prepared','media.ingest'),
 ('product/comparison.rs','capture_with_limits','compare.baseline_snapshot'),
 ('product/comparison.rs','assemble_comparison_with_limits','compare.assemble'),
 ('writer_core/inspect.rs','inspect_apkg_inner','inspect.full'),
 ('writer_core/inspect.rs','fingerprint_report','inspect.fingerprint'),
 ('writer_core/diff.rs','diff_reports','compare.diff'),
 ('writer_core/apkg.rs','write_media_payloads_and_map','apkg.retained_media'),
 ('deck/export.rs','copy_bounded','export.copy_bounded'),
]
for f,fn,label in extra_scopes:base.scope(f,fn,label)
for f,fn,label in [
 ('writer_core/apkg.rs','note_storage_values','sqlite.note_storage'),
 ('authoring_core/media_io.rs','ingest_media_read_source_to_cas','persistent.cas_total'),
 ('writer_core/media.rs','prepare_verified_cas_copy','persistent.staging_total'),
 ('deck/media.rs','observe_file','registration.observe_file'),
 ('writer_core/diff.rs','entry_payload','compare.entry_payload'),
]:accum(f,fn,label)

edit('anki_forge/src/authoring_core/media_io.rs',
 '    temp.as_file()\n        .sync_all()\n        .map_err(|err| MediaIoError::CasWrite {',
 '    let audit_result = {\n        let _audit_sync = crate::diag::Accum::new("persistent.cas_sync");\n        temp.as_file().sync_all()\n    };\n    audit_result.map_err(|err| MediaIoError::CasWrite {')
edit('anki_forge/src/writer_core/media.rs',
 '    if let Err(err) = output.sync_all() {',
 '    let audit_result = {\n        let _audit_sync = crate::diag::Accum::new("persistent.staging_sync");\n        output.sync_all()\n    };\n    if let Err(err) = audit_result {')

apkg='anki_forge/src/writer_core/apkg.rs'
edit(apkg,'    transaction.commit()?;\n    Ok(())',
 '    { let _audit_commit = crate::diag::Scope::new("sqlite.commit");\n      transaction.commit()?; }\n    Ok(())')
edit(apkg,'        insert_note.execute(rusqlite::params![',
 '''        let audit_values = {
            let _audit_params = crate::diag::Accum::new("sqlite.note_params");
            (note.tags.join(" "), super::note_data::fresh_identity_note_data(
                guid_assignments.get(note.id.as_str()).copied(), note))
        };
        let audit_note_sql = crate::diag::Accum::new("sqlite.note_bind_step");
        insert_note.execute(rusqlite::params![''')
edit(apkg,'            note.tags.join(" "),\n            storage.flds,',
 '            audit_values.0,\n            storage.flds,')
edit(apkg,'''            super::note_data::fresh_identity_note_data(
                guid_assignments.get(note.id.as_str()).copied(),
                note,
            ),
        ])?;
        for tag in &note.tags {''',
 '''            audit_values.1,
        ])?;
        drop(audit_note_sql);
        drop(audit_values);
        for tag in &note.tags {''')
edit(apkg,'            insert_card.execute(rusqlite::params![',
 '            let audit_card_sql = crate::diag::Accum::new("sqlite.card_bind_step");\n            insert_card.execute(rusqlite::params![')
edit(apkg,'            card_row_id += 1;',
 '            drop(audit_card_sql);\n            card_row_id += 1;')

adapter='benchmarks/adapters/rust/src/main.rs'
edit(adapter,'    let _audit_total = anki_forge::diag::Scope::new("adapter.total");',
 '''    #[cfg(feature = "audit-alloc")]
    anki_forge::diag::install_observer(memory::observe);
    let _audit_report = anki_forge::diag::Report;
    let _audit_total = anki_forge::diag::Scope::new("adapter.total");''')
edit(adapter,'    let mut deck = Deck::new(workload.deck_name);',
 '''    let mut deck = if let Ok(id) = std::env::var("ANKI_AUDIT_STABLE_ID") {
        Deck::builder(workload.deck_name).stable_id(id).build()
    } else { Deck::new(workload.deck_name) };''')
edit(adapter,'        deck.write_apkg(output)?.ensure_success()?;',
 '''        match std::env::var("ANKI_AUDIT_MODE").unwrap_or_else(|_| "deck".into()).as_str() {
            "deck" => { deck.write_apkg(output)?.ensure_success()?; },
            "persistent" => { deck.build(BuildOptions::new().output(output)
                .artifacts_dir(Path::new(output).parent().unwrap().join("retained")))?.ensure_success()?; },
            "write-to" => { deck.write_to(std::fs::File::create(output)?)?; },
            "compare" => {
                let baseline = std::env::var("ANKI_AUDIT_BASELINE")?;
                let report = deck.build(BuildOptions::new().output(output).compare_to(baseline))?;
                report.ensure_success()?;
                ensure!(format!("{:?}",report.comparison)=="Complete","comparison was not complete");
                println!("comparison=Complete");
            },
            other => bail!("unknown diagnostic mode: {other}"),
        }''')
# Reuse the reviewed allocation-only accounting implementation. It delegates to
# System and samples current process RSS with ps; its elapsed times are excluded.
old=(R/'benchmarks/results/20260907-post-streaming-audit/scripts/memory_probe.py').read_text()
memory=old.split("(adapter / 'memory.rs').write_text('''",1)[1].split("''')",1)[0]
(S/'benchmarks/adapters/rust/src/memory.rs').write_text(memory)
p=S/adapter;p.write_text('#[cfg(feature = "audit-alloc")]\nmod memory;\n'+p.read_text())
p=S/'benchmarks/adapters/rust/Cargo.toml';p.write_text(p.read_text().replace('default = []','default = []\naudit-alloc = []'))
for p in S.rglob('*'):
 if p.is_file():os.utime(p,None)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(W/'profile-source.json').write_text(json.dumps({
 'source_files':{str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},
 'extra_scopes':extra_scopes,
 'diagnostic_semantics':'Scopes are inclusive wall time; counters include all threads. union_ns is the union of each counter label intervals, sum_ns includes overlap and must not be divided by parent elapsed as a percentage. Memory-only build reports live and cumulative-peak Rust allocation bytes plus current process RSS; excludes per-row counters and never contributes timing/RSS scores.',
 'sqlite_detail':'note_storage includes fields/checksum/sfld; note_params includes tags and identity data; bind_step includes rusqlite binding plus SQLite execution/reset, not isolated sqlite3_step CPU; commit and VACUUM scopes are separate.',
 'no_production_source_edits':True,
},indent=2)+'\n')
print('Private timing and allocation probe sources prepared')
