from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[2]
sys.path.insert(0,str(R/'benchmarks'))
import bench,verify
sha=bench.sha256
cases={c['name']:c for c in json.loads((W/'cases.json').read_text())}
formal=[f'{group}-{metric}' for group in ['default','copy','compare','persistent'] for metric in ['timing','rss']]
diagnostic=['probe-default','probe-compare','probe-persistent','memory-default','memory-compare','memory-copy']
V=W/'verification';V.mkdir(exist_ok=True)
known={};bindings={};counts={}
for run_name in formal+diagnostic:
 run=W/run_name;plan=json.loads((run/'plan.json').read_text())
 rows=[json.loads(line) for line in (run/'attempts.jsonl').read_text().splitlines()]
 expected=Counter((c['name'],v,i) for c in plan['cases'] for v in plan['args']['variants'] for i in range(-plan['args']['warmups'],plan['args']['repeats']))
 assert Counter((r['case'],r['variant'],r['sample']) for r in rows)==expected
 assert len(rows)==len((run/'launches.jsonl').read_text().splitlines())
 assert (run/'summary.json').is_file()
 for row in rows:
  assert row['measurement']['reaped'] and not any(row['measurement'][k] for k in ['exit_code','signal','spawn_error','leftover_descendants','interrupted_signal'])
  assert all(plan['required_power_source'] in row[k].splitlines()[0] for k in ['power_before','power_after'])
  case=cases[row['case']];key=(case['input_sha256'],row['artifact_sha256'])
  folder=run/f"{row['case']}-{row['variant']}-{row['sample']}"
  if row['sample']==0:
   artifact=folder/'output.apkg';assert sha(artifact)==row['artifact_sha256']
   if key not in known:
    dest=V/f"{run_name}-{row['case']}-{row['variant']}";dest.mkdir(exist_ok=True)
    raw=verify.verify_artifact(artifact,json.loads(Path(case['path']).read_text()),bench.INSPECTOR)
    (dest/'raw.json').write_text(json.dumps(raw,indent=2)+'\n');assert raw['status']=='passed'
    previous=subprocess.run([str(W/'binaries/before-inspector'),'inspect','--apkg',str(artifact),'--output','contract-json'],capture_output=True,timeout=120,check=True)
    digest=hashlib.sha256(previous.stdout).hexdigest();assert digest==raw['semantic']['inspection_sha256']
    (dest/'report-equivalence.json').write_text(json.dumps({'status':'passed','full_inspection_sha256':digest},indent=2)+'\n')
    with (dest/'oracle.stdout.log').open('w') as out,(dest/'oracle.stderr.log').open('w') as err:
     subprocess.run([str(bench.ORACLE),case['path'],str(artifact),str(dest/'anki.json')],stdout=out,stderr=err,timeout=120,check=True)
    assert json.loads((dest/'anki.json').read_text())['status']=='passed'
    known[key]=str(dest.relative_to(W))
   bindings[f"{run_name}/{row['case']}/{row['variant']}"]=known[key]
  if row['environment_overrides'].get('ANKI_AUDIT_MODE')=='compare':
   assert 'comparison=Complete' in (folder/'stdout.log').read_text()
  if row['variant']=='profile-timing':
   counters=[json.loads(line.split('] ',1)[1]) for line in (folder/'stderr.log').read_text().splitlines() if line.startswith('[DEBUG-rebench-counter]')]
   counter={c['label']:c for c in counters}
   assert counter['sqlite.note_bind_step']['count']==json.loads(Path(case['path']).read_text())['note_count']
   if run_name=='probe-persistent' and row['case'].startswith('image-'):
    expected_media=1000 if row['case']=='image-1000' else 64
    for label in ['persistent.cas_sync','persistent.staging_sync']:
     assert counter[label]['count']==expected_media
     assert 1<=counter[label]['max_concurrent']<=4
  if row['variant']=='profile-memory':assert '[DEBUG-post-audit-memory]' in (folder/'stderr.log').read_text()
 for case in plan['cases']:
  assert len({r['artifact_sha256'] for r in rows if r['case']==case['name']})==1
 for row in rows:assert (cases[row['case']]['input_sha256'],row['artifact_sha256']) in known
 for baseline in plan['baseline_identities'].values():assert sha(Path(baseline['path']))==baseline['sha256']
 for variant,h in plan['binaries'].items():assert sha(W/'binaries'/variant)==h
 counts[run_name]=len(rows)
 print('verified',run_name,flush=True)
final=json.loads((W/'build-final.json').read_text())
for name,h in final['source_files'].items():assert sha(R/name)==h,name
for name,h in final['standard_adapter_source_files'].items():assert sha(R/name)==h,name
for name,h in final['executables'].items():assert sha(W/'binaries'/name)==h,name
assert sha(R/'benchmarks/adapters/rust/target/release/anki-forge-benchmark')==final['executables']['after-standard']
for name,path in [('collector',R/'benchmarks/.tools/measure'),('inspector',bench.INSPECTOR),('oracle',bench.ORACLE)]:assert sha(Path(path))==final[f'{name}_sha256']
for name,h in json.loads((W/'profile-source.json').read_text())['source_files'].items():assert sha(W/'profile-source'/name)==h,name
html=[json.loads(line) for line in (W/'html-attempts.jsonl').read_text().splitlines()]
expected={(v,op,k) for v in ['before','after'] for op in ['strip','public_export'] for k in [4,8,16,32]}-{('before','public_export',32)}
assert Counter((h['variant'],h['operation'],h['kib']) for h in html)==Counter(expected)
required=json.loads((W/'session-power.json').read_text())['required_power_source']
for cell in html:
 assert cell['returncode']==0 and all(required in cell[k].splitlines()[0] for k in ['power','power_after'])
 samples=[m for m in map(json.loads,cell['stdout'].splitlines()) if m['kind']=='sample']
 assert sorted(m['index'] for m in samples)==list(range(-1,5)) and all(m['correct'] for m in samples)
assert '435928' in (W/'html-differential-final.log').read_text()
summary={'status':'passed','formal_exports':sum(counts[n] for n in formal),'diagnostic_exports':sum(counts[n] for n in diagnostic),'distinct_raw_and_anki_artifacts':len(known),'run_counts':counts,'bindings':bindings,'html_calls':90,'html_public_exports':42,'html_differential_cases':435928,'production_unchanged':True,'probe_sources_match_build':True,'required_power_source':required}
(V/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['bindings','run_counts']}),flush=True)
