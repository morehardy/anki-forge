from pathlib import Path
import json
W=Path(__file__).resolve().parent;R=W.parents[2]
s=json.loads((W/'summary.json').read_text())
assert s['verification']['status']=='passed'
def cell(layer,group,name):return next(c for c in s[layer][group] if c['case']==name)
def stage(group,case,label):return cell('stages',group,case)['stages'].get(label,{}).get('time_ms',{}).get('median',0)
def fmt(v):return f'{v:,.2f}'
def formal_table(group):
 lines=['| 场景 | 前 ms | 后 ms | 耗时变化 | 前 RSS MiB | 后 RSS MiB |','| --- | ---: | ---: | ---: | ---: | ---: |']
 for c in s['formal'][group]:
  b=next(v for k,v in c['variants'].items() if k.startswith('before'));a=next(v for k,v in c['variants'].items() if k.startswith('after'))
  lines.append(f"| {c['case']} | {fmt(b['time_ms']['median'])} | {fmt(a['time_ms']['median'])} | {c['time_change_percent']:+.1f}% | {fmt(b['rss_mib']['median'])} | {fmt(a['rss_mib']['median'])} |")
 return '\n'.join(lines)
power=s['power_profile']['required_power_source']
p=['# 优化后复测与当前瓶颈\n',
   f'日期：2026-09-08。本轮基于 main `c665271` 加[已完成的四项优化](2026-09-08-performance-optimization-implementation.md)，生产源码未改。实际基准子进程全程按 **{power}** 供电模式测量；这是新的独立会话，只比较本轮相同条件下的前后版本。\n',
   '## 当前瓶颈\n',
   '''四项优化的目标收益在本轮复现，但热点随入口而变。千张图片 write_to 的 RSS 为 99.84 → 39.19 MiB，耗时基本持平；万条文字 compare_to 为 1,589.20 → 1,069.84 ms、556.30 → 335.53 MiB；首次持久化千张图片为 12.38 → 9.08 s。普通 29 格的耗时变化是 −5.2%～+7.2%，不能概括为全部提速。

| 场景 | 当前主要成本 | 本轮诊断证据 |
| --- | --- | --- |
| 持久化千张图片 | 同步落盘调用 | CAS 与 staging 各 1,000 次 sync_all，最多四个操作并行；两阶段同步区间的并集合计覆盖约 80.4% 的 adapter 时间 |
| 默认万条文字 / 四倍长字段 | SQLite 行写入和压实 | SQLite 占比分别约 38% / 50%；万条的 notes/cards 绑定执行约 101 ms、压实约 98 ms，tags/identity 参数生成约 10 ms |
| 万条文字完整比较 | 两次完整检查与 diff；两份观察模型和临时事实重叠 | 基线捕获及当前检查+diff 约占 45%；每份观察模型构造新增约 64 MiB Rust 存活内存，第二份模型构造时达到约 247 MiB Rust 峰值 |
| 默认千张图片 | 同步注册观察和媒体准备 | 注册约 77 ms，占约 28%；其中文件观察约 72 ms。媒体准备约 61 ms，占约 22%，包含验证、编码、调度和顺序写入 |

对于 64 个大文件，持久化同步区间占比降为约 39%，媒体写包另约 213 ms；这类负载的收益为约 8%，小于千个小文件的约 27%。文件数与总字节量需要分别观察。

比较的内存高水位已定位到当前观察模型构造：进入第二次完整检查时 Rust 存活约 139.72 MiB，读取实际事实后约 181.70 MiB，构造观察模型后约 245.56 MiB；完整检查返回、临时事实释放后回到约 203.59 MiB。指纹计算和 diff 没有继续抬高该次 Rust 累计峰值。默认长字段的约 62 MiB Rust 峰值则主要来自构建前已持有的文本及归一化数据；千图有界拷贝阶段未增加 Rust 峰值或边界 RSS。

下一轮若优先改善默认导出，应先针对 SQLite 绑定/执行与压实做独立 A/B，保持原始行、schema、ID 和确定性；本轮证据不支持优先投入参数字符串微优化。比较流程适合先验证消费式事实投影，减少观察模型构造时约 42 MiB 的原始事实重叠，并继续校验全部观察域、证据和指纹。持久化用户的重点则是重新审视必须持久保存的副本、同步调度及文件数成本，保留当前持久化和发布语义。普通媒体注册还需进一步拆 open/read/SHA-1/图像头解析，当前数据只能定位到整个文件观察调用。

这些是本轮测量支持的下一步方向，尚未实现。阶段诊断期间的大文本绝对耗时高于正式计时阶段，同期未插桩对照也更慢，因此不将跨阶段差额当作探针开销或预计节省量。下文完整保留各负载的正向和负向结果。
''',
   '## 测量方法与有效性\n',
   'macOS ARM64、Rust 1.92.0 release、默认 public features、System 分配器。普通路径 29 格，另有 write_to 和 compare_to 各 5 格、首次 CAS/持久化 3 格；普通及两个 API 每版本每格 2 次预热 + 7 次计时，另 2 次预热 + 5 次 RSS。持久化为 1 次预热 + 5 次计时，另 1 次预热 + 3 次 RSS。每次导出独立进程，包含输入解析、注册、构建、检查、输出和清理；案例按固定种子轮换，前后版本交替执行。\n',
   '正式性能二进制与上一轮冻结身份一致，标准适配器在独立目录构建后的正确版本被保留；本轮私有探针没有覆盖它。编译、工具测试、Anki 导入都与计时分开。未控制冷缓存、温度、CPU 频率或其他系统活动；少量样本只作描述性统计，不给出显著性结论或跨机器承诺。表中的 RSS 是独立采样的进程峰值中位数。\n',
   '供电检查曾在首个样本前停止两次：快速检查显示 AC，实际基准子进程显示 Battery。本轮采用实际子进程读数，重新声明固定供电条件；之前没有完成任何计时格，不混入结果。每次正式调用前后均检查供电来源，没有以静态推断替代这些记录。首个内存烟雾检查被沙箱禁止读取自身 RSS；授予该读取能力后的整组烟雾检查通过，原失败日志保留。\n',
   '## 正式性能复测\n']
html={(h['variant'],h['operation'],h['bytes']//1024):h['median_ns']/1e6 for h in s['html']}
p.extend(['### 畸形 HTML\n','| Front 大小 | 清洗前 ms | 清洗后 ms | 单卡构建前 ms | 单卡构建后 ms |','| --- | ---: | ---: | ---: | ---: |'])
for k in [4,8,16,32]:
 b=html.get(('before','public_export',k))
 p.append(f"| {k} KiB | {html['before','strip',k]:.3f} | {html['after','strip',k]:.6f} | {f'{b:.3f}' if b is not None else '预先排除'} | {html['after','public_export',k]:.3f} |")
p.append('\nHTML 为单进程内函数调用计时，每格 1 次预热 + 5 次样本，逐格检查供电。公开构建只包围 Deck::build，不含加卡、输入准备和销毁。旧版 32 KiB 公开构建在先前审计达到预算，本轮继续预先排除该格；不发布它的速度比。15 个完整格之外，固定差分 oracle 再次完成 435,928 组检查。\n')
for group,title in [('copy','write_to'),('compare','完整比较'),('persistent','首次持久化'),('default','普通导出 29 格')]:
 p.extend([f'### {title}\n',formal_table(group),''])
p.extend(['## 阶段计时：热点在哪个环节\n',
          '以下来自独立私有探针，各格 1 次预热 + 3 次采样，同时交替运行同一当前 API 入口的未插桩对照。阶段时间是包含子阶段的墙钟时间，不能把父子项相加。探针与未插桩对照的差异包含计时、统计和日志开销；这些数值用于定位，不能充当正式成绩。\n',
          '| 入口与场景 | 探针 ms | 未插桩 ms | 差异 |','| --- | ---: | ---: | ---: |'])
for group,cells in s['stages'].items():
 for c in cells:p.append(f"| {group}/{c['case']} | {fmt(c['probe_ms']['median'])} | {fmt(c['control_ms']['median'])} | {c['probe_time_change_percent']:+.1f}% |")
p.extend(['\n### 普通路径阶段\n','| 场景 | 注册 | 加卡 | 归一化及身份 | SQLite 总计 | 成品检查 | adapter 总计 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |'])
for c in s['stages']['default']:
 p.append('| '+c['case']+' | '+' | '.join(fmt(stage('default',c['case'],k)) for k in ['adapter.registration','adapter.notes','normalize.with_identity','sqlite.total','pipeline.inspect','adapter.total'])+' |')
p.extend(['\n单位均为 ms。媒体准备还在归一化内部，包含源验证、压缩、调度与顺序写入媒体条目。\n',
          '### SQLite 细分\n','| 场景 | 总计 | 字段/sfld/checksum | tags/identity 参数 | notes 绑定执行 | cards 绑定执行 | 提交 | 压实 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |'])
for name in ['text-1000','text-10000','long-back-quadruple-1000','image-1000']:
 p.append('| '+name+' | '+' | '.join(fmt(stage('default',name,k)) for k in ['sqlite.total','sqlite.note_storage','sqlite.note_params','sqlite.note_bind_step','sqlite.card_bind_step','sqlite.commit','sqlite.compact'])+' |')
p.append('\n绑定执行包括 rusqlite 参数绑定、SQLite 执行与 reset，尚未把 sqlite3_step CPU 单独隔离。字段准备和 identity 参数生成分别计时；压实包括 VACUUM INTO 与相关临时目标处理。当前已有单事务、预备语句复用和 VACUUM INTO。\n')
p.extend(['### 完整比较细分\n','| 场景 | 捕获基线 | 当前检查+diff | 两次事实读取 | 两次指纹 | 观察构造等差额 | diff 总计 | payload 序列化 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |'])
for c in s['stages']['compare']:
 values=[stage('compare',c['case'],k) for k in ['compare.baseline_snapshot','compare.assemble','inspect.facts','inspect.fingerprint']]
 values+=[c['full_inspect_remaining_ms']['median'],stage('compare',c['case'],'compare.diff'),stage('compare',c['case'],'compare.entry_payload')]
 p.append('| '+c['case']+' | '+' | '.join(map(fmt,values))+' |')
p.append('\n这里完整检查共两次，基线快照在 reconcile 与 diff 间复用。观察构造等差额逐样本计算为 full inspection − raw facts − fingerprint，包含观察模型构造、报告封装、临时事实释放和嵌套探针开销；它不是仅 build_observations 的精确计时。payload 序列化是 diff 的子项。\n')
p.extend(['### 并行持久化 I/O\n','| 场景 | CAS 同步调用数 | staging 同步调用数 | CAS 累计/区间并集 ms | staging 累计/区间并集 ms | 两段同步并集占总时间 |','| --- | ---: | ---: | ---: | ---: | ---: |'])
for c in s['stages']['persistent']:
 if not c['case'].startswith('image-'):continue
 a=c['counters']['persistent.cas_sync'];b=c['counters']['persistent.staging_sync']
 p.append(f"| {c['case']} | {a['count']['median']:.0f} | {b['count']['median']:.0f} | {a['sum_ms']['median']:.2f} / {a['union_ms']['median']:.2f} | {b['sum_ms']['median']:.2f} / {b['union_ms']['median']:.2f} | {c['sync_union_percent_of_adapter']['median']:.1f}% |")
p.append('\n计数器记录所有工作线程。累计时间包含并行重叠；区间并集表示至少一个该类同步调用在运行的墙钟跨度。CAS 与 staging 属于先后两段，因此可逐样本合并它们的并集占比；不能用累计时间除总时间解释为 CPU 占比。这里只是 sync_all 调用的墙钟区间，未采集内核 CPU 或块设备延迟。\n')
p.extend(['## 内存：高水位出现在哪里\n',
          '独立内存探针每格 3 次新进程。全局分配器仍委托 System，记录 Rust 申请的存活字节与累计最高值，另用 ps 读取阶段边界的当前 RSS。它的时间不参与性能结论，Rust 字节计数不包括 SQLite/zstd 原生分配和分配器保留。边界 RSS 也不是阶段内的峰值。\n',
          '| 入口/场景 | Rust 累计最高 MiB | 退出 adapter 时 Rust 存活 MiB |','| --- | ---: | ---: |'])
for group,cells in s['memory'].items():
 for c in cells:
  e=c['boundaries']['adapter.total#0']['end']
  p.append(f"| {group}/{c['case']} | {e['peak_rust_mib']['median']:.2f} | {e['live_rust_mib']['median']:.2f} |")
p.extend(['\n### 比较流程的观察模型构造区间\n','| 场景 | 基线构造区间新增 Rust 存活 MiB | 当前构造区间新增 Rust 存活 MiB | 当前指纹开始时 Rust 存活 / RSS MiB |','| --- | ---: | ---: | ---: |'])
for c in s['memory']['compare']:
 windows=c['observation_construction_windows'];current=c['boundaries']['inspect.fingerprint#1']['begin']
 p.append(f"| {c['case']} | {windows['0']['live_rust_mib']['median']:.2f} | {windows['1']['live_rust_mib']['median']:.2f} | {current['live_rust_mib']['median']:.2f} / {current['current_rss_mib']['median']:.2f} |")
p.append('\n该区间从 read_apkg_facts 返回到 fingerprint_report 开始；根据当前调用链，中间主要构造观察模型。这里报告可复核的边界变化，没有把 RSS 与 Rust 计数的差额直接归因给 SQLite 或认定为泄漏。完整嵌套边界见 summary.json。\n')
v=s['verification']
p.extend(['## 证据与验收\n',
          f"正式 collector **{v['formal_exports']:,} 次导出**、独立诊断 **{v['diagnostic_exports']} 次导出**均完成预声明样本集合，正常退出、没有遗留子进程；同一模式和输入的前后/探针 APKG 字节相同。全部导出关联到 **{v['distinct_raw_and_anki_artifacts']} 份**独立验证的输入/产物组合，通过原始 SQLite/媒体、固定 Anki 导入/渲染及旧新完整 inspection JSON 等价核验。\n",
          '基准工具 43 项测试本轮通过。生产源码逐文件哈希与上一轮已通过完整 CI 的版本一致，本轮没有重复声称重新运行生产完整 CI。HTML 90 次函数调用含 42 次公开构建，差分 oracle 435,928 组通过。\n',
          '原始样本、IQR、供电记录、探针开销、全部内存边界、源码/二进制身份、启动失败及独立核验见[证据目录](../../../benchmarks/results/20260908-post-optimization-audit/README.md)。源码入口：[SQLite 构建](../../../anki_forge/src/writer_core/apkg.rs#L433)、[完整检查](../../../anki_forge/src/writer_core/inspect.rs#L241)、[比较快照](../../../anki_forge/src/product/comparison.rs#L44)、[媒体注册](../../../anki_forge/src/deck/media.rs#L405)、[CAS 同步](../../../anki_forge/src/authoring_core/media_io.rs#L223)、[staging 同步](../../../anki_forge/src/writer_core/media.rs#L211)。\n',
          '本轮覆盖合成 Basic 卡片与 Rust 入口；没有测实际 Node/Python 性能、热 CAS、Cloze/多模板、长期并发、其他系统/存储介质或真实冷缓存。未提交或推送任何改动。\n'])
path=R/'docs/superpowers/specs/2026-09-08-post-optimization-bottleneck-audit.md'
path.write_text('\n'.join(p));print(path)
