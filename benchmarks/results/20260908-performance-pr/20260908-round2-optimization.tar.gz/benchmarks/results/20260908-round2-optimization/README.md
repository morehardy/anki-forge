# 第二轮性能优化证据

最终报告：[优化结果与 genanki 对比](../../../docs/superpowers/specs/2026-09-08-round2-optimization-genanki.md)。

- `summary.json`：全部 A/B、genanki、阶段计时和分配探针数据；包括独立采样、范围和 IQR。
- `genanki/`：20 格正式矩阵、来源清单、840 次调用及逐次校验索引。每格 10 次时间、5 次独立 RSS；另有各 3 次预热。
- `attempts-and-validation.tar.gz` / `genanki-attempts.tar.gz`：完整调用日志、计划、电源、原始表/媒体/检查报告等价验证、Anki 导入证据。保留无效预热与第一次契约门禁失败。
- `final-build.json`、`builds/`：最终源码、依赖/工具、二进制和编译环境哈希；仅正式 public-default/System 二进制用于性能结论。私有分配探针不用于时间/RSS成绩。
- `production-state.patch`：从记录的 main HEAD 重建全部工作区实现（含前一轮）。`round2-text.patch` 只展示本轮文本变化。二进制契约资源在完整补丁内。
- `profile-source.patch` 与 `profile-adapter/`：最终私有探针。`before-round2-production.patch`、`before-memory-profile.patch`、`before-memory-adapter/` 重建比较用的旧分配探针。
- `scripts/`、`candidate-sources/`：筛选、收集、验证、汇总、归档脚本与未采用候选；不进入产品。
- `frozen-inputs.tar.gz` / `fixtures/` / `cases.json`：冻结文本输入、媒体生成配方和输入哈希。大媒体二进制及 APKG/CAS/staging 可重建，不重复提交。复跑脚本中的绝对目录需映射到新 checkout，保留输入/依赖哈希及独立目标目录。

耗时包含新进程启动至退出；原生电源为 Battery Power，按调用前后核对。同一格前后交错比较，冷缓存/温度/后台负载未隔离。小幅变化不应当作跨机器保证。

页面调整只改变 collection 的物理布局和 APKG 字节，版本内确定性、全表数据、检查指纹、身份、媒体、预算和发布要求保持验证。契约 0.6.3 仅更新三个受影响夹具的物理包指纹。

所有数据以最终验证结果为准。完整 CI、发布包清单与资源重建校验通过。未提交、推送或发布变更。
