// Diagnostic-only replay of the retained writer's media encoding helper.
// Source verification and sync are intentionally outside this isolated slice.
use std::{fs::File, path::Path};
use zip::{ZipWriter, write::FileOptions, CompressionMethod};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    let mode = &args[1];
    assert!(mode == "fresh" || mode == "reuse");
    let input = Path::new(&args[2]);
    let document: serde_json::Value = serde_json::from_reader(File::open(input)?)?;
    let mut zip = ZipWriter::new(File::create(&args[3])?);
    let mut context = zstd::zstd_safe::CCtx::create();
    for (index, media) in document["media"].as_array().unwrap().iter().enumerate() {
        let source = input.parent().unwrap().join(media["path"].as_str().unwrap());
        zip.start_file(index.to_string(), FileOptions::<'static, ()>::default()
            .compression_method(CompressionMethod::Stored))?;
        let mut input = File::open(source)?;
        if mode == "fresh" {
            let mut encoder = zstd::stream::Encoder::new(&mut zip, 0)?;
            std::io::copy(&mut input, &mut encoder)?;
            encoder.finish()?;
        } else {
            let mut encoder = zstd::stream::Encoder::with_context(&mut zip, &mut context);
            std::io::copy(&mut input, &mut encoder)?;
            encoder.finish()?;
        }
    }
    zip.finish()?;
    Ok(())
}
