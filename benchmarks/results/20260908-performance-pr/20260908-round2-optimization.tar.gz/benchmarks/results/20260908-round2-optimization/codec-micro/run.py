from pathlib import Path
import hashlib,json,os,statistics,subprocess,sys
W=Path(__file__).resolve().parents[1];R=W.parents[2];D=W/'codec-micro'
power=subprocess.check_output(['/usr/bin/pmset','-g','batt'],text=True).splitlines()[0]
plan={'power':power,'warmups':2,'repeats':7,'cases':['image-1000','image-64x1m'],'scope':'Only media file read, encode and ZIP write; no CAS/staging/verification/sync. Diagnostic slice, not public export throughput.'}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
records=[];hashes={};cases={c['name']:c for c in json.loads((W/'cases.json').read_text())}
for sample in range(-2,7):
 for name in plan['cases']:
  for mode in (['fresh','reuse'] if sample%2 else ['reuse','fresh']):
   folder=D/f'{name}-{mode}-{sample}';folder.mkdir(exist_ok=False);output=folder/'output.zip'
   before=subprocess.check_output(['/usr/bin/pmset','-g','batt'],text=True).splitlines()[0]
   command=[str(R/'benchmarks/.tools/measure'),'60',str(folder/'stdout.log'),str(folder/'stderr.log'),str(D/'probe'),mode,cases[name]['path'],str(output)]
   p=subprocess.run(command,capture_output=True,text=True,check=True,timeout=75);m=json.loads(p.stdout);(folder/'collector.json').write_text(p.stdout)
   after=subprocess.check_output(['/usr/bin/pmset','-g','batt'],text=True).splitlines()[0]
   h=hashlib.sha256(output.read_bytes()).hexdigest();row={'case':name,'mode':mode,'sample':sample,'measurement':m,'artifact_sha256':h,'power_before':before,'power_after':after}
   with (D/'attempts.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   assert m['reaped'] and not any(m[k] for k in ['exit_code','signal','spawn_error','leftover_descendants','interrupted_signal'])
   assert before==after==power;assert hashes.setdefault(name,h)==h
   output.unlink();records.append(row)
summary=[]
for name in plan['cases']:
 entry={'case':name}
 for mode in ['fresh','reuse']:
  x=[r['measurement']['elapsed_ns']/1e6 for r in records if r['case']==name and r['mode']==mode and r['sample']>=0]
  entry[mode]={'n':len(x),'median_ms':statistics.median(x),'min_ms':min(x),'max_ms':max(x),'samples_ms':x}
 entry['change_percent']=(entry['reuse']['median_ms']/entry['fresh']['median_ms']-1)*100;summary.append(entry)
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
