# Media export benchmark

Timing: 10 independent processes per cell; RSS: 5 separate processes.

| Profile | Notes | Rust ms | genanki ms | Time reduction | Rust RSS MiB | genanki RSS MiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| basic-audio-unique-v2 | 100 | 49.615 | 133.661 | 62.9% | 19.16 | 28.33 |
| basic-audio-unique-v2 | 200 | 70.351 | 151.240 | 53.5% | 21.52 | 28.92 |
| basic-audio-unique-v2 | 500 | 123.222 | 218.087 | 43.5% | 27.66 | 31.88 |
| basic-audio-unique-v2 | 1000 | 228.586 | 317.968 | 28.1% | 38.73 | 36.20 |
| basic-image-unique-v2 | 100 | 56.048 | 144.680 | 61.3% | 20.39 | 28.39 |
| basic-image-unique-v2 | 200 | 78.121 | 169.172 | 53.8% | 22.48 | 29.42 |
| basic-image-unique-v2 | 500 | 151.111 | 270.070 | 44.0% | 28.53 | 31.83 |
| basic-image-unique-v2 | 1000 | 264.632 | 439.080 | 39.7% | 38.98 | 35.95 |
| basic-mixed-shared-v2 | 100 | 43.441 | 128.194 | 66.1% | 19.81 | 28.14 |
| basic-mixed-shared-v2 | 200 | 49.721 | 130.368 | 61.9% | 21.06 | 28.59 |
| basic-mixed-shared-v2 | 500 | 69.477 | 140.688 | 50.6% | 25.81 | 30.27 |
| basic-mixed-shared-v2 | 1000 | 96.255 | 148.498 | 35.2% | 34.17 | 33.06 |
| basic-mixed-text-v1 | 100 | 35.767 | 115.698 | 69.1% | 14.47 | 27.97 |
| basic-mixed-text-v1 | 200 | 41.343 | 118.407 | 65.1% | 16.11 | 28.27 |
| basic-mixed-text-v1 | 500 | 55.681 | 126.203 | 55.9% | 21.02 | 30.09 |
| basic-mixed-text-v1 | 1000 | 84.747 | 137.569 | 38.4% | 29.56 | 32.25 |
| basic-mixed-unique-v2 | 100 | 49.534 | 133.466 | 62.9% | 19.81 | 28.05 |
| basic-mixed-unique-v2 | 200 | 64.188 | 149.654 | 57.1% | 21.89 | 28.92 |
| basic-mixed-unique-v2 | 500 | 111.043 | 208.319 | 46.7% | 27.98 | 30.89 |
| basic-mixed-unique-v2 | 1000 | 199.429 | 311.220 | 35.9% | 37.50 | 35.14 |

Cells meeting the proposed 30% reduction: 19/20.

All successful samples passed original SQLite row/template and exact media payload checks. Anki evidence, when enabled, covers one package per cell/adapter. No GUI or audible playback is checked.
