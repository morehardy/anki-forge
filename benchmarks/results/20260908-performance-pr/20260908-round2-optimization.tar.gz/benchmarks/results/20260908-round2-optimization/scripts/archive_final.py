from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,tarfile
W=Path(__file__).resolve().parent;R=W.parents[2];D=R/'benchmarks/results/20260908-round2-optimization'
assert json.loads((W/'verification/summary.json').read_text())['status']=='passed'
D.mkdir(exist_ok=False)
for name in ['summary.json','cases.json','before-snapshot.json','final-build.json','final-session.json','profile-source.json','ci-summary.json','native-sessions.jsonl','candidate-artifact-cleanup.json']:
 shutil.copy2(W/name,D/name)
(D/'scripts').mkdir();(D/'candidate-sources').mkdir();(D/'builds').mkdir()
for p in W.glob('*.py'):shutil.copy2(p,D/'scripts'/p.name)
for p in W.glob('*candidate.rs'):shutil.copy2(p,D/'candidate-sources'/p.name)
for p in W.glob('*before-*.rs'):shutil.copy2(p,D/'candidate-sources'/p.name)
for p in W.glob('build-final-*.json'):shutil.copy2(p,D/'builds'/p.name)
for name in ['api-source']:
 shutil.copytree(W/name,D/name,ignore=shutil.ignore_patterns('target'))
shutil.copytree(W/'profile-source/benchmarks/adapters/rust',D/'profile-adapter',ignore=shutil.ignore_patterns('target'))
shutil.copytree(R/'benchmarks/adapters/rust',D/'standard-adapter',ignore=shutil.ignore_patterns('target'))
# Recreate published source changes exactly, including newly added files/assets.
paths=['anki_forge','contracts','contract_tools/tests','scripts/check_rust_crate_payload.sh']
patch=subprocess.check_output(['git','diff','--binary','HEAD','--',*paths],cwd=R)
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--',*paths],cwd=R,text=True).splitlines()
for name in new:
 p=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=R,stdout=subprocess.PIPE)
 assert p.returncode==1;patch+=p.stdout
(D/'production-state.patch').write_bytes(patch)
# A readable patch for only this round; binary assets are in the full patch.
changed=subprocess.check_output(['git','diff','--name-only','HEAD','--',*paths],cwd=R,text=True).splitlines()+new
round_patch=[]
for name in sorted(set(changed)):
 old=W/'before-source'/name;current=R/name
 if old.is_file():before=old.read_bytes()
 elif name.startswith(('anki_forge/','contracts/')):before=b''
 else:
  x=subprocess.run(['git','show','HEAD:'+name],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL);before=x.stdout if x.returncode==0 else b''
 after=current.read_bytes() if current.is_file() else b''
 if before==after:continue
 try:a=before.decode();b=after.decode()
 except UnicodeDecodeError:continue
 round_patch.extend(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+name if before else '/dev/null',tofile='b/'+name if after else '/dev/null'))
(D/'round2-text.patch').write_text(''.join(round_patch))
probe=[]
for p in sorted((W/'profile-source/anki_forge').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(W/'profile-source');original=R/rel
 before=original.read_bytes() if original.is_file() else b'';after=p.read_bytes()
 if before==after:continue
 a=before.decode();b=after.decode()
 probe.extend(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+str(rel) if before else '/dev/null',tofile='b/'+str(rel)))
(D/'profile-source.patch').write_text(''.join(probe))
old=R/'benchmarks/results/20260908-post-optimization-audit'
shutil.copy2(old/'profile-source.patch',D/'before-memory-profile.patch')
shutil.copy2(old/'production-state.patch',D/'before-round2-production.patch')
shutil.copy2(old/'profile-source.json',D/'before-memory-source.json')
shutil.copytree(old/'profile-adapter',D/'before-memory-adapter')
(D/'fixtures').mkdir()
for p in [R/'benchmarks/media_workload.py',R/'benchmarks/workload.py',R/'benchmarks/results/20260907-remaining-opportunities/scripts/cases.py']:
 shutil.copy2(p,D/'fixtures'/p.name)
# Frozen text inputs are small when compressed; media payloads remain reproducible from recipes/hashes.
with tarfile.open(D/'frozen-inputs.tar.gz','w:gz') as tar:
 for c in json.loads((W/'cases.json').read_text()):tar.add(c['path'],arcname=c['name']+'/input.json')
# Full logs and identities; generated APKG/CAS/staging payloads and binaries are not duplicated.
run_names=['owned-screen','owned-screen-v2','batch-screen','page8k-screen','page16k-screen','codec-screen']+[f'{g}-{m}' for g in ['default','compare','persistent'] for m in ['timing','rss']]+['probe-default','probe-compare','probe-persistent','memory-compare','probe-audio']
with tarfile.open(D/'attempts-and-validation.tar.gz','w:gz') as tar:
 for p in W.iterdir():
  if p.is_file() and p.suffix=='.log':tar.add(p,arcname='logs/'+p.name)
 for name in run_names+['candidate-verification','verification','final-smoke','golden-refresh']:
  for p in sorted((W/name).rglob('*')):
   if p.is_file() and p.suffix in ['.json','.jsonl','.log']:tar.add(p,arcname=str(p.relative_to(W)))
shutil.copytree(W/'codec-micro',D/'codec-micro',ignore=shutil.ignore_patterns('probe'))
# Keep the official matrix directly browsable at the summary level, and archive every attempt.
M=R/'benchmarks/.work/runs/20260908-round2-genanki';(D/'genanki').mkdir()
for name in ['summary.json','manifest.json','report.md','verified.jsonl','attempts.jsonl','power.jsonl']:
 shutil.copy2(M/name,D/'genanki'/name)
with tarfile.open(D/'genanki-attempts.tar.gz','w:gz') as tar:
 for p in sorted(M.rglob('*')):
  if p.is_file() and p.parent!=M and p.suffix in ['.json','.log']:tar.add(p,arcname=str(p.relative_to(M)))
report=R/'docs/superpowers/specs/2026-09-08-round2-optimization-genanki.md'
(D/'README.md').write_text('''# 第二轮性能优化证据

最终报告：[优化结果与 genanki 对比](../../../docs/superpowers/specs/2026-09-08-round2-optimization-genanki.md)。

- `summary.json`：全部 A/B、genanki、阶段计时和分配探针数据；包括独立采样、范围和 IQR。
- `genanki/`：20 格正式矩阵、来源清单、840 次调用及逐次校验索引。每格 10 次时间、5 次独立 RSS；另有各 3 次预热。
- `attempts-and-validation.tar.gz` / `genanki-attempts.tar.gz`：完整调用日志、计划、电源、原始表/媒体/检查报告等价验证、Anki 导入证据。保留无效预热与第一次契约门禁失败。
- `final-build.json`、`builds/`：最终源码、依赖/工具、二进制和编译环境哈希；仅正式 public-default/System 二进制用于性能结论。私有分配探针不用于时间/RSS成绩。
- `production-state.patch`：从记录的 main HEAD 重建全部工作区实现（含前一轮）。`round2-text.patch` 只展示本轮文本变化。二进制契约资源在完整补丁内。
- `profile-source.patch` 与 `profile-adapter/`：最终私有探针。`before-round2-production.patch`、`before-memory-profile.patch`、`before-memory-adapter/` 重建比较用的旧分配探针。
- `scripts/`、`candidate-sources/`：筛选、收集、验证、汇总、归档脚本与未采用候选；不进入产品。
- `frozen-inputs.tar.gz` / `fixtures/` / `cases.json`：冻结文本输入、媒体生成配方和输入哈希。大媒体二进制及 APKG/CAS/staging 可重建，不重复提交。复跑脚本中的绝对目录需映射到新 checkout，保留输入/依赖哈希及独立目标目录。

耗时包含新进程启动至退出；原生电源为 Battery Power，按调用前后核对。同一格前后交错比较，冷缓存/温度/后台负载未隔离。小幅变化不应当作跨机器保证。

页面调整只改变 collection 的物理布局和 APKG 字节，版本内确定性、全表数据、检查指纹、身份、媒体、预算和发布要求保持验证。契约 0.6.3 仅更新三个受影响夹具的物理包指纹。

所有数据以最终验证结果为准。完整 CI、发布包清单与资源重建校验通过。未提交、推送或发布变更。
''')
subprocess.run(['git','apply','--reverse','--check',str(D/'production-state.patch')],cwd=R,check=True)
meta={'status':'passed','report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'production_patch_reverse_check':True,'verification_summary_sha256':hashlib.sha256((W/'verification/summary.json').read_bytes()).hexdigest()}
(D/'final-review.json').write_text(json.dumps(meta,indent=2)+'\n')
files=sorted(p for p in D.rglob('*') if p.is_file())
(D/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(D))+'\n' for p in files))
print(D,'files',len(files),'bytes',sum(p.stat().st_size for p in files),flush=True)
