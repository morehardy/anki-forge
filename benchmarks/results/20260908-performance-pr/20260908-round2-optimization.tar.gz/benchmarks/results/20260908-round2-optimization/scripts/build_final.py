from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[2];sys.path.insert(0,str(R/'benchmarks'));import bench
assert 'verify-ci passed' in (W/'verify-ci-v2.log').read_text()
with (W/'ownership-preserve-order.log').open('w') as log:
 subprocess.run(['cargo','test','--locked','-p','anki_forge','--lib','--features','serde_json/preserve_order','writer_core::inspect'],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
for name in ['check_embedded_contract_bundle','check_rust_crate_payload']:
 with (W/(name+'.log')).open('w') as log:
  subprocess.run(['bash',str(R/'scripts'/f'{name}.sh')],cwd=R,env=dict(os.environ,ANKI_FORGE_ALLOW_DIRTY_PACKAGE='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
# Regenerate private diagnostics from the final source and embedded bundle.
S=W/'profile-source'
if S.exists():
 assert S.parent==W and not S.is_symlink();shutil.rmtree(S)
subprocess.run([sys.executable,str(W/'setup_profile.py')],check=True)
def build(label,args,output,destination):
 with (W/f'build-final-{label}.log').open('w') as log:
  env=os.environ.copy();started=bench.utc();subprocess.run(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  record={'command':args,'cwd':str(R),'started_utc':started,'finished_utc':bench.utc(),'environment':bench.build_environment(env),'launcher':shutil.which(args[0]),'executable_sha256':bench.sha256(output)}
  records=json.loads(bench.BUILD_RECORDS.read_text());records[str(output.resolve())]=record;bench.save(bench.BUILD_RECORDS,records)
 if destination:shutil.copy2(output,destination)
 (W/f'build-final-{label}.json').write_text(json.dumps(record,indent=2)+'\n')
 print('built',label,flush=True)
api=W/'api-target/release/anki-forge-benchmark'
build('api',['cargo','build','--release','--locked','--offline','--manifest-path',str(W/'api-source/Cargo.toml'),'--bin','anki-forge-benchmark','--target-dir',str(W/'api-target')],api,W/'binaries/after-api')
standard=R/'benchmarks/adapters/rust/target/release/anki-forge-benchmark'
build('standard',['cargo','build','--release','--locked','--offline','--manifest-path',str(R/'benchmarks/adapters/rust/Cargo.toml'),'--no-default-features'],standard,W/'binaries/after-standard')
assert b'ANKI_AUDIT_MODE' not in standard.read_bytes(),'Standard adapter accidentally contains API probe modes'
build('inspector',['cargo','build','--release','--locked','--offline','-p','contract_tools'],bench.INSPECTOR,None)
manifest=S/'benchmarks/adapters/rust/Cargo.toml';binary=W/'probe-target/release/anki-forge-benchmark'
base=['cargo','build','--release','--locked','--offline','--manifest-path',str(manifest),'--target-dir',str(W/'probe-target'),'--no-default-features']
build('profile-timing',base,binary,W/'binaries/profile-timing')
build('profile-memory',base+['--features','audit-alloc'],binary,W/'binaries/profile-memory')
smoke=W/'final-smoke';smoke.mkdir(exist_ok=False);case=next(c for c in json.loads((W/'cases.json').read_text()) if c['name']=='text-100');hashes={}
for v in ['after-standard','after-api','profile-timing','profile-memory']:
 folder=smoke/v;folder.mkdir();p=folder/'output.apkg'
 with (folder/'stdout.log').open('w') as o,(folder/'stderr.log').open('w') as e:subprocess.run([str(W/'binaries'/v),case['path'],str(p)],stdout=o,stderr=e,check=True,timeout=120)
 hashes[v]=bench.sha256(p)
assert len(set(hashes.values()))==1,hashes
assert '[DEBUG-post-audit-memory]' in (smoke/'profile-memory/stderr.log').read_text()
(smoke/'results.json').write_text(json.dumps({'status':'passed','artifact_sha256':hashes},indent=2)+'\n')
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':{str(p.relative_to(R)):bench.sha256(p) for p in bench.source_paths() if p.is_file()},'binaries':{p.name:bench.sha256(p) for p in (W/'binaries').iterdir()},'inspector_sha256':bench.sha256(bench.INSPECTOR),'oracle_sha256':bench.sha256(bench.ORACLE),'collector_sha256':bench.sha256(bench.COLLECTOR),'profile_source_sha256':bench.sha256(W/'profile-source.json'),'standard_metadata':json.loads(subprocess.check_output([str(standard),'--metadata'],text=True)),'api_source_files':{str(p.relative_to(W/'api-source')):bench.sha256(p) for p in (W/'api-source').rglob('*') if p.is_file()}}
(W/'final-build.json').write_text(json.dumps(record,indent=2)+'\n')
print('Final sources, binaries and diagnostics frozen; smoke artifacts identical',flush=True)
