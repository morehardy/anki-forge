from pathlib import Path
import hashlib,json,shutil,subprocess,sys
w=Path(__file__).resolve().parent
for name,before,after in [('owned-screen-v2','before-api','owned-api'),('batch-screen','owned-api','batch-api'),('codec-screen','page8k-api','codec-api')]:
 with (w/f'verify-{name}.log').open('w') as log:subprocess.run([sys.executable,str(w/'verify_pair.py'),name,before,after],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Verified',name,flush=True)
removed=[]
for name in ['owned-screen','owned-screen-v2','batch-screen','page8k-screen','page16k-screen','codec-screen']:
 run=w/name
 for p in run.glob('*/output.apkg'):
  removed.append({'path':str(p.relative_to(w)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size});p.unlink()
 for p in run.glob('*/retained'):
  assert p.resolve().is_relative_to(run.resolve()) and not p.is_symlink()
  shutil.rmtree(p)
(w/'candidate-artifact-cleanup.json').write_text(json.dumps({'reason':'Candidate results, raw table evidence, source snapshots and hashes retained; excluded 16 KiB candidate not fully validated. Regenerable APKG/CAS/staging payloads removed to reserve disk space for formal measurements.','outputs':removed},indent=2)+'\n')
print('Candidate artifacts validated and regenerable payloads released',flush=True)
