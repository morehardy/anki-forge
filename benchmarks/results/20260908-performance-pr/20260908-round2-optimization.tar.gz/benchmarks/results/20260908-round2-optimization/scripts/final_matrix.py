from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
from datetime import datetime,timezone
W=Path(__file__).resolve().parent;R=W.parents[2];P=R/'benchmarks/.venv/bin/python'
sys.path.insert(0,str(R/'benchmarks'))
import bench,media_bench
RUN_NAME='20260908-round2-genanki'

def run(name,args):
 with (W/f'{name}.log').open('w') as log:
  subprocess.run([str(P),str(W/'run.py'),name,*args],stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)

def pairs(group,variants,cases=None,mode=None,warm=2,n=7,rss=5):
 args=[*variants,'--distinct-containers']
 if cases:args+=['--cases',*cases]
 for v in variants:
  if mode:args+=['--env',f'{v}:ANKI_AUDIT_MODE={mode}']
  if mode=='compare':args+=['--env',f'{v}:ANKI_AUDIT_STABLE_ID=main-performance-audit']
 for metric,reps in [('timing',n),('rss',rss)]:run(f'{group}-{metric}',args+['--warmups',str(warm),'--repeats',str(reps)])
 # RSS sample-zero payloads duplicate already retained timing artifacts.
 records=[json.loads(l) for l in (W/f'{group}-timing'/'attempts.jsonl').read_text().splitlines()]
 expected={(r['case'],r['variant']):r['artifact_sha256'] for r in records}
 records=[json.loads(l) for l in (W/f'{group}-rss'/'attempts.jsonl').read_text().splitlines()]
 removed=[]
 for r in records:
  if r['sample']!=0:continue
  folder=W/f'{group}-rss'/f"{r['case']}-{r['variant']}-0";p=folder/'output.apkg'
  assert bench.sha256(p)==expected[(r['case'],r['variant'])]==r['artifact_sha256']
  removed.append({'case':r['case'],'variant':r['variant'],'sha256':r['artifact_sha256']});p.unlink()
  if (folder/'retained').is_dir():shutil.rmtree(folder/'retained')
 (W/f'{group}-rss'/'duplicate-payload-cleanup.json').write_text(json.dumps(removed,indent=2)+'\n')

power=subprocess.check_output(['/usr/bin/pmset','-g','batt'],text=True)
required=next(p for p in ['AC Power','Battery Power'] if p in power.splitlines()[0])
os.environ['ANKI_AUDIT_POWER_SOURCE']=required
(W/'final-session.json').write_text(json.dumps({'utc':bench.utc(),'initial_power':power,'required_power_source':required,'matrix_name':RUN_NAME,'runner_sha256':bench.sha256(W/'run.py'),'orchestrator_sha256':bench.sha256(Path(__file__))},indent=2)+'\n')
pairs('default',['before-standard','after-standard'])
pairs('compare',['before-api','after-api'],['text-1000','text-10000','long-back-quadruple-1000','image-1000','image-64x1m'],'compare')
pairs('persistent',['before-api','after-api'],['text-1000','image-1000','image-64x1m'],'persistent',warm=1,n=5,rss=3)
# Independent genanki comparison: 20 cells, 3+10 timing and 3+5 RSS launches.
original=media_bench.collect_attempt
expected=power.splitlines()[0]
def guarded(case,row,command,env):
 before=subprocess.check_output(['/usr/bin/pmset','-g','batt'],text=True)
 if before.splitlines()[0]!=expected:raise RuntimeError('power changed before matrix invocation')
 try:return original(case,row,command,env)
 finally:
  after=subprocess.check_output(['/usr/bin/pmset','-g','batt'],text=True)
  bench.append(case.parent/'power.jsonl',{'id':row['id'],'before':before,'after':after})
  if after.splitlines()[0]!=expected:raise RuntimeError('power changed during matrix invocation')
media_bench.collect_attempt=guarded
from argparse import Namespace
media_bench.run(Namespace(name=RUN_NAME,inputs=R/'benchmarks/.work/readme-comparison/fixtures',repeats=10,rss_repeats=5,skip_oracle=False))
print('ALL FORMAL MEASUREMENTS COMPLETE',flush=True)
# Instrumented sources run only after official timings finish.
for group,mode,cases in [('default','deck',['text-1000','text-10000','long-back-quadruple-1000','image-1000','image-64x1m']),('compare','compare',['text-10000','long-back-quadruple-1000']),('persistent','persistent',['image-1000','image-64x1m'])]:
 args=['after-api','profile-timing','--cases',*cases,'--warmups','1','--repeats','3']
 for v in ['after-api','profile-timing']:
  args+=['--env',f'{v}:ANKI_AUDIT_MODE={mode}']
  if mode=='compare':args+=['--env',f'{v}:ANKI_AUDIT_STABLE_ID=main-performance-audit']
 run('probe-'+group,args)
args=['before-memory','profile-memory','--distinct-containers','--cases','text-10000','long-back-quadruple-1000','--warmups','0','--repeats','3']
for v in ['before-memory','profile-memory']:args+=['--env',f'{v}:ANKI_AUDIT_MODE=compare','--env',f'{v}:ANKI_AUDIT_STABLE_ID=main-performance-audit']
run('memory-compare',args)
print('ALL DIAGNOSTICS COMPLETE',flush=True)
