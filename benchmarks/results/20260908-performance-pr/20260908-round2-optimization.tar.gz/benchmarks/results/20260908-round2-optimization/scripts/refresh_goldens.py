from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
W=Path(__file__).resolve().parent;R=W.parents[2];sys.path.insert(0,str(W));import verify_pair
import zstandard
out=W/'golden-refresh';out.mkdir(exist_ok=False);records=[]
for case in ['basic','cloze','image-occlusion']:
 expected=R/f'contracts/fixtures/phase3/expected/{case}.build.json';original=json.loads(expected.read_text());pair={}
 for variant,tool,manifest in [('before',W/'binaries/before-inspector',W/'before-source/contracts/manifest.yaml'),('after',R/'target/debug/contract_tools',R/'contracts/manifest.yaml')]:
  folder=out/f'{case}-{variant}';folder.mkdir()
  result=json.loads(subprocess.check_output([str(tool),'build','--manifest',str(manifest),'--input',str(R/f'contracts/fixtures/phase3/inputs/{case}-normalized-ir.json'),'--artifacts-dir',str(folder)],text=True))
  p=folder/'package.apkg'
  with zipfile.ZipFile(p) as z:
   with zstandard.ZstdDecompressor().stream_reader(z.open('collection.anki21b')) as reader:raw=reader.read()
   other={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n!='collection.anki21b'}
  report=json.loads(subprocess.check_output([str(W/'binaries/before-inspector'),'inspect','--apkg',str(p),'--output','contract-json'],text=True));report.pop('source_ref')
  pair[variant]={'build':result,'database':verify_pair.database_identity(raw),'other_entries':other,'inspect':report}
 assert pair['before']['build']==original,case
 for key in ['schema','tables']:assert pair['before']['database'][key]==pair['after']['database'][key],(case,key)
 for key in ['other_entries','inspect']:assert pair['before'][key]==pair['after'][key],(case,key)
 new=pair['after']['build'];assert {k:v for k,v in new.items() if k!='package_fingerprint'}=={k:v for k,v in original.items() if k!='package_fingerprint'},case
 expected.write_text(expected.read_text().replace(original['package_fingerprint'],new['package_fingerprint']))
 records.append({'case':case,'status':'passed','before':pair['before'],'after':pair['after']})
 print(case,original['package_fingerprint'],'->',new['package_fingerprint'],flush=True)
(out/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
