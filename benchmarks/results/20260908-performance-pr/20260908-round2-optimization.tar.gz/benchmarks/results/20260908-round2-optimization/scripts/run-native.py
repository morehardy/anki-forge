from pathlib import Path
import json,os,subprocess,sys
from datetime import datetime,timezone
w=Path(__file__).resolve().parent
p=subprocess.check_output(['/usr/bin/pmset','-g','batt'],text=True)
power=next(v for v in ['AC Power','Battery Power'] if v in p.splitlines()[0])
with (w/'native-sessions.jsonl').open('a') as f: f.write(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'power':p,'args':sys.argv[1:]})+'\n')
subprocess.run([sys.executable,str(w/'run.py'),*sys.argv[1:]],env=dict(os.environ,ANKI_AUDIT_POWER_SOURCE=power),check=True)
