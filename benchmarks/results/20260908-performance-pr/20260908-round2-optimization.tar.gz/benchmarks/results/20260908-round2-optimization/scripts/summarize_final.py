from pathlib import Path
from collections import defaultdict
import json,statistics
W=Path(__file__).resolve().parent
def stats(v):
 assert v
 q=statistics.quantiles(v,n=4,method='inclusive') if len(v)>1 else [v[0]]*3
 return {'n':len(v),'median':statistics.median(v),'min':min(v),'max':max(v),'iqr':q[2]-q[0],'samples':v}
def rows(name):return [json.loads(l) for l in (W/name/'attempts.jsonl').read_text().splitlines()]
summary={'power_profile':json.loads((W/'final-session.json').read_text()),'formal':{},'stages':{},'memory':{}}
for group in ['default','compare','persistent']:
 timed=rows(group+'-timing');rss=rows(group+'-rss');cells=[]
 for case in sorted({r['case'] for r in timed}):
  cell={'case':case,'variants':{}}
  for variant in sorted({r['variant'] for r in timed}):
   ts=[r for r in timed if r['case']==case and r['variant']==variant and r['sample']>=0]
   ms=[r for r in rss if r['case']==case and r['variant']==variant and r['sample']>=0]
   cell['variants'][variant]={'time_ms':stats([r['measurement']['elapsed_ns']/1e6 for r in ts]),'rss_mib':stats([r['measurement']['peak_rss_bytes']/2**20 for r in ms]),'artifact_sha256':ts[0]['artifact_sha256']}
  before=next(v for k,v in cell['variants'].items() if k.startswith('before'))
  after=next(v for k,v in cell['variants'].items() if k.startswith('after'))
  cell['time_change_percent']=(after['time_ms']['median']/before['time_ms']['median']-1)*100
  cell['rss_change_percent']=(after['rss_mib']['median']/before['rss_mib']['median']-1)*100
  cells.append(cell)
 summary['formal'][group]=cells
for group in ['default','compare','persistent','audio']:
 name='probe-'+group;data=rows(name);cells=[]
 for case in sorted({r['case'] for r in data}):
  samples=[r for r in data if r['case']==case and r['variant']=='profile-timing' and r['sample']>=0]
  controls=[r for r in data if r['case']==case and r['variant']=='after-api' and r['sample']>=0]
  assert all(set(r['stages_ns'])==set(samples[0]['stages_ns']) for r in samples)
  cell={'case':case,'stages':{},'counters':{}}
  for label in samples[0]['stages_ns']:
   cell['stages'][label]={'time_ms':stats([r['stages_ns'][label]/1e6 for r in samples]),'percent_of_adapter_total':stats([r['stages_ns'][label]/r['stages_ns']['adapter.total']*100 for r in samples]),'calls':[sum(k==label for k,_ in r['stage_events']) for r in samples]}
  counter_samples=[]
  for row in samples:
   text=(W/name/f"{case}-profile-timing-{row['sample']}"/'stderr.log').read_text()
   counter_samples.append({v['label']:v for v in [json.loads(l.split('] ',1)[1]) for l in text.splitlines() if l.startswith('[DEBUG-rebench-counter]')]})
  for label in counter_samples[0]:
   cell['counters'][label]={(k.replace('_ns','_ms') if k.endswith('_ns') else k):stats([c[label][k]/(1e6 if k.endswith('_ns') else 1) for c in counter_samples]) for k in ['sum_ns','union_ns','count','max_concurrent','thread_count']}
  if group=='persistent' and case.startswith('image-'):
   cell['sync_union_percent_of_adapter']=stats([(c['persistent.cas_sync']['union_ns']+c['persistent.staging_sync']['union_ns'])/row['stages_ns']['adapter.total']*100 for c,row in zip(counter_samples,samples)])
  if group=='compare':
   cell['full_inspect_remaining_ms']=stats([(r['stages_ns']['inspect.full']-r['stages_ns']['inspect.facts']-r['stages_ns']['inspect.fingerprint'])/1e6 for r in samples])
   cell['full_inspect_remaining_scope']='Derived per sample: full inspection minus raw facts and fingerprint; includes observation construction, report assembly, temporary fact destruction and nested probe logging.'
  cell['probe_ms']=stats([r['measurement']['elapsed_ns']/1e6 for r in samples])
  cell['control_ms']=stats([r['measurement']['elapsed_ns']/1e6 for r in controls])
  cell['probe_time_change_percent']=(cell['probe_ms']['median']/cell['control_ms']['median']-1)*100
  cells.append(cell)
 summary['stages'][group]=cells
summary['stages']['default']+=summary['stages'].pop('audio')
name='memory-compare';data=rows(name);cells=[]
for case in sorted({r['case'] for r in data}):
 cell={'case':case,'variants':{}}
 for variant in ['before-memory','profile-memory']:
  samples=[r for r in data if r['case']==case and r['variant']==variant and r['sample']>=0]
  observations=defaultdict(list)
  for row in samples:
   text=(W/name/f"{case}-{variant}-{row['sample']}"/'stderr.log').read_text()
   events=[json.loads(l.split('] ',1)[1]) for l in text.splitlines() if l.startswith('[DEBUG-post-audit-memory]')]
   stacks=defaultdict(list);counts=defaultdict(int)
   for event in events:
    label=event['label']
    if event['begin']:
     occurrence=counts[label];counts[label]+=1;stacks[label].append((occurrence,event))
    else:
     occurrence,start=stacks[label].pop();observations[f'{label}#{occurrence}'].append((start,event))
   assert not any(stacks.values())
  bounds={}
  for label,pairs in observations.items():
   assert len(pairs)==len(samples)
   bounds[label]={side:{k.replace('_bytes','_mib'):stats([p[i][k]/(2**20 if k.endswith('_bytes') else 1) for p in pairs]) for k in ['live_rust_bytes','peak_rust_bytes','cumulative_rust_bytes','allocation_calls','current_rss_bytes']} for side,i in [('begin',0),('end',1)]}
  cell['variants'][variant]={'boundaries':bounds}
 cells.append(cell)
summary['memory']['compare']=cells
R=W.parents[2]
summary['genanki']=json.loads((R/'benchmarks/.work/runs/20260908-round2-genanki/summary.json').read_text())
summary['screening']={n:json.loads((W/n/'summary.json').read_text()) for n in ['owned-screen-v2','batch-screen','page8k-screen','page16k-screen','codec-screen']}
summary['codec_slice']=json.loads((W/'codec-micro/summary.json').read_text())
summary['verification']=json.loads((W/'verification/summary.json').read_text()) if (W/'verification/summary.json').exists() else 'pending'
summary['units']={'formal':'milliseconds and MiB','stages':'milliseconds and per-sample percentage of inclusive adapter.total','counters':'sum_ms and union_ms are milliseconds; remaining fields are counts','memory':'all *_mib fields are MiB; peak_rust_mib is cumulative global peak, current_rss_mib is a boundary snapshot, neither is a phase-local peak'}
(W/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for group,cells in summary['formal'].items():
 print(group)
 for c in cells:print(c['case'],round(c['time_change_percent'],1),{k:(round(v['time_ms']['median'],2),round(v['rss_mib']['median'],2)) for k,v in c['variants'].items()})
for group,cells in summary['stages'].items():
 print('STAGES',group)
 for c in cells:
  print(c['case'],'probe/control',round(c['probe_time_change_percent'],1),'sync union %',c.get('sync_union_percent_of_adapter',{}).get('median'))
  print({k:round(v['time_ms']['median'],2) for k,v in c['stages'].items()})
