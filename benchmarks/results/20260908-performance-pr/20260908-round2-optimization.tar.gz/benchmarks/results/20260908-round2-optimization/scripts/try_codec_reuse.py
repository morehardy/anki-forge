from pathlib import Path
w=Path(__file__).resolve().parent;r=w.parents[2];p=r/'anki_forge/src/writer_core/apkg.rs';s=p.read_text();(w/'apkg-before-codec.rs').write_text(s)
a='''    let mut entries = Vec::new();
    let objects_by_id = normalized_ir'''
assert s.count(a)==1;s=s.replace(a,'''    let mut entries = Vec::new();
    let mut context = zstd::zstd_safe::CCtx::create();
    let objects_by_id = normalized_ir''')
s=s.replace('''write_zstd_file_entry(zip, &index.to_string(), &source)?;''','''write_zstd_file_entry(zip, &index.to_string(), &source, &mut context)?;''')
s=s.replace('''fn write_zstd_file_entry(zip: &mut ZipWriter<File>, name: &str, path: &Path) -> Result<()> {''','''fn write_zstd_file_entry(
    zip: &mut ZipWriter<File>,
    name: &str,
    path: &Path,
    context: &mut zstd::zstd_safe::CCtx<'static>,
) -> Result<()> {''')
s=s.replace('''    let mut encoder =
        zstd::stream::Encoder::new(zip, 0).context("create zstd encoder for media payload")?;''','''    // Each successful finish closes an independent frame; only workspace is
    // reused, with the same default parameters and unknown source size.
    let mut encoder = zstd::stream::Encoder::with_context(zip, context);''')
a='''    #[test]
    fn embedded_upgrade_notice_matches_schema_generated_database()'''
test='''    #[test]
    fn retained_media_reuses_context_without_changing_independent_frames() {
        let root = tempfile::tempdir().unwrap();
        let mut context = zstd::zstd_safe::CCtx::create();
        let mut reused = ZipWriter::new(File::create(root.path().join("reused.zip")).unwrap());
        let mut fresh = ZipWriter::new(File::create(root.path().join("fresh.zip")).unwrap());
        for (index, size) in [0, 1, 8191, 8192, 8193, 65536, 131073, 524289, 0, 65536]
            .into_iter().enumerate()
        {
            let bytes: Vec<u8> = (0..size).map(|n| {
                if index % 2 == 0 { b'x' } else { ((n * 37 + n / 257) % 256) as u8 }
            }).collect();
            let path = root.path().join("source");
            fs::write(&path, &bytes).unwrap();
            let name = index.to_string();
            fresh.start_file(&name,
                FileOptions::<'static, ()>::default().compression_method(CompressionMethod::Stored)
            ).unwrap();
            let mut encoder = zstd::stream::Encoder::new(&mut fresh, 0).unwrap();
            std::io::copy(&mut File::open(&path).unwrap(), &mut encoder).unwrap();
            encoder.finish().unwrap();
            write_zstd_file_entry(&mut reused, &name, &path, &mut context).unwrap();
        }
        fresh.finish().unwrap();
        reused.finish().unwrap();
        assert_eq!(fs::read(root.path().join("reused.zip")).unwrap(),
            fs::read(root.path().join("fresh.zip")).unwrap());
    }

'''
assert a in s;s=s.replace(a,test+a);p.write_text(s)
