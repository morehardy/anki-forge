from pathlib import Path
w=Path(__file__).resolve().parent;r=w.parents[2]
p=r/'anki_forge/src/writer_core/apkg.rs';s=p.read_text();(w/'apkg-before-batch.rs').write_text(s)
a=s.index('    let mut insert_note = conn.prepare(',s.index('fn populate_latest_collection_rows('));b=s.index('    let mut insert_card = conn.prepare(',a)
s=s[:a]+s[b:]
a=s.index('    for note in &normalized_ir.notes {',s.index('fn populate_latest_collection_rows('))
s=s[:a]+s[a:].replace('    for note in &normalized_ir.notes {','''    let mut remaining = normalized_ir.notes.as_slice();
    while !remaining.is_empty() {
        let mut count = 0;
        let mut bytes = 0usize;
        for note in remaining.iter().take(32) {
            let size = note.fields.values().map(String::len).sum::<usize>().saturating_mul(2);
            if count > 0 && bytes.saturating_add(size) > 256 * 1024 { break; }
            count += 1;
            bytes = bytes.saturating_add(size);
        }
        let (batch, rest) = remaining.split_at(count);
        remaining = rest;
        let sql = format!(
            "insert into notes (id, guid, mid, mod, usn, tags, flds, sfld, csum, flags, data) values {}",
            vec!["(?, ?, ?, ?, 0, ?, ?, ?, ?, 0, ?)"; count].join(",")
        );
        let mut insert_note = conn.prepare_cached(&sql)?;
        for (batch_index, note) in batch.iter().enumerate() {''',1)
a=s.index('        insert_note.execute(rusqlite::params![',a);b=s.index('        for tag in &note.tags {',a)
expr=s[a:b].replace('        insert_note.execute(rusqlite::params![','        let parameters = rusqlite::params![').replace('        ])?;','        ];\n        for (offset, value) in parameters.iter().enumerate() {\n            insert_note.raw_bind_parameter(batch_index * 9 + offset + 1, *value)?;\n        }')
# Joined tags and identity JSON need to live through binding; name them.
expr=expr.replace('        let parameters = rusqlite::params![','''        let tags = note.tags.join(" ");
        let data = super::note_data::fresh_identity_note_data(
            guid_assignments.get(note.id.as_str()).copied(), note,
        );
        let parameters = rusqlite::params![''').replace('            note.tags.join(" "),','            tags,').replace('''            super::note_data::fresh_identity_note_data(
                guid_assignments.get(note.id.as_str()).copied(),
                note,
            ),''','            data,')
s=s[:a]+expr+s[b:]
a=s.index('        for planned_card in plan_cards(note, notetype) {',a);b=s.index('        note_row_id += 1;',a)
cards=s[a:b];s=s[:a]+s[b:]
a=s.index('    for tag in normalized_tags {',a)
s=s[:a]+'''        insert_note.raw_execute()?;
        insert_note.clear_bindings();
        for (index, note) in batch.iter().enumerate() {
            let note_row = note_row_id - count as i64 + index as i64;
            let notetype = prepared_notetypes[note.notetype_id.as_str()].notetype;
'''+cards+'''        }
    }

'''+s[a:]
s=s.replace('        let notetype = prepared.notetype;\n','',1)
p.write_text(s)
