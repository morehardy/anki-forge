from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,sys
W=Path(__file__).resolve().parent;R=W.parents[2];sys.path.insert(0,str(R/'benchmarks'))
import bench,verify
V=W/'verification';V.mkdir(exist_ok=True)
selected={};bindings={};counts={}
# Every final measured artifact must map to a verified input/output identity.
for group,variants in [('default',['before-standard','after-standard']),('compare',['before-api','after-api']),('persistent',['before-api','after-api'])]:
 name=group+'-timing'
 with (W/f'verify-{group}.log').open('w') as log:
  subprocess.run([sys.executable,str(W/'verify_pair.py'),name,*variants,'--oracle'],stdout=log,stderr=subprocess.STDOUT,check=True)
 evidence=json.loads((W/'candidate-verification'/name/'results.json').read_text())
 for case in evidence:
  normalized_reports={}
  for variant in variants:
   path=W/name/f"{case['case']}-{variant}-0/output.apkg"
   reports=[]
   for inspector in [W/'binaries/before-inspector',bench.INSPECTOR]:
    out=subprocess.check_output([str(inspector),'inspect','--apkg',str(path),'--output','contract-json'],timeout=120)
    reports.append(out)
   assert reports[0]==reports[1],(group,case['case'],'inspection changed')
   report=json.loads(reports[0]);report.pop('source_ref')
   digest=hashlib.sha256(json.dumps(report,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
   normalized_reports[variant]=digest
   selected[(group,case['case'],variant)]={'artifact_sha256':bench.sha256(path),'report_sha256':hashlib.sha256(reports[0]).hexdigest(),'semantic_report_sha256':digest}
  assert len(set(normalized_reports.values()))==1,(group,case['case'],'report differs across versions')
 print('validated raw tables, full report equivalence and Anki:',group,flush=True)
for name in [f'{g}-{m}' for g in ['default','compare','persistent'] for m in ['timing','rss']]+['probe-default','probe-compare','probe-persistent','memory-compare','probe-audio']:
 run=W/name;plan=json.loads((run/'plan.json').read_text());rows=[json.loads(s) for s in (run/'attempts.jsonl').read_text().splitlines()]
 expected=Counter((c['name'],v,n) for c in plan['cases'] for v in plan['args']['variants'] for n in range(-plan['args']['warmups'],plan['args']['repeats']))
 assert Counter((r['case'],r['variant'],r['sample']) for r in rows)==expected
 assert len(rows)==len((run/'launches.jsonl').read_text().splitlines())
 for r in rows:
  m=r['measurement'];assert m['reaped'] and not any(m[k] for k in ['exit_code','signal','spawn_error','leftover_descendants','interrupted_signal'])
  assert all(plan['required_power_source'] in r[k].splitlines()[0] for k in ['power_before','power_after'])
  group=name.removeprefix('probe-').removeprefix('memory-').removesuffix('-timing').removesuffix('-rss')
  if name=='probe-audio':group='default'
  old=r['variant'].startswith('before')
  variant=('before-standard' if old else 'after-standard') if group=='default' else ('before-api' if old else 'after-api')
  ref=selected[(group,r['case'],variant)];assert r['artifact_sha256']==ref['artifact_sha256'],(name,r['case'],r['variant'])
  if group=='compare':assert 'comparison=Complete' in (run/f"{r['case']}-{r['variant']}-{r['sample']}/stdout.log").read_text()
 for c in plan['cases']:assert bench.sha256(Path(c['path']))==c['input_sha256']
 for v,h in plan['binaries'].items():assert bench.sha256(W/'binaries'/v)==h
 counts[name]=len(rows)
 print('bound every invocation:',name,flush=True)
M=R/'benchmarks/.work/runs/20260908-round2-genanki'
m=json.loads((M/'manifest.json').read_text());assert m['status']=='completed' and m['identity_unchanged'] and m['oracle_required']
rows=[json.loads(s) for s in (M/'verified.jsonl').read_text().splitlines()];attempts=[json.loads(s) for s in (M/'attempts.jsonl').read_text().splitlines()]
assert len(rows)==len(attempts)==840 and len({r['id'] for r in rows})==840
assert all(r['status']=='success' for r in attempts)
assert Counter(r['role'] for r in rows)=={'timing_warmup':120,'timing':400,'rss_warmup':120,'rss':200}
for row in rows:
 case=M/row['id'];v=json.loads((case/'verification.json').read_text());assert v['status']=='passed' and v['artifact_sha256']==row['artifact_sha256']
 if row['role']=='timing' and row['repeat']==0:
  assert json.loads((case/'anki.json').read_text())['status']=='passed'
  assert bench.sha256(case/'anki.json')==row['oracle_sha256']
power=[json.loads(s) for s in (M/'power.jsonl').read_text().splitlines()];assert len(power)==840
required=json.loads((W/'final-session.json').read_text())['required_power_source']
assert all(required in r[k].splitlines()[0] for r in power for k in ['before','after'])
source=json.loads((W/'final-build.json').read_text())
for name,h in source['source_files'].items():assert bench.sha256(R/name)==h,name
for name,h in source['binaries'].items():assert bench.sha256(W/'binaries'/name)==h,name
assert bench.sha256(Path(bench.registry()[0]['command'][0]))==source['binaries']['after-standard']
assert bench.sha256(bench.INSPECTOR)==source['inspector_sha256']
assert bench.sha256(bench.ORACLE)==source['oracle_sha256']
assert bench.sha256(bench.COLLECTOR)==source['collector_sha256']
(V/'summary.json').write_text(json.dumps({'status':'passed','counts':counts,'genanki_matrix_invocations':len(rows),'genanki_anki_imports':40,'pairwise_verified_cases':len(selected)//2,'required_power_source':required,'artifact_bindings':{ '/'.join(k):v for k,v in selected.items()}},indent=2)+'\n')
print('All final performance, compatibility and provenance checks passed',flush=True)
