from pathlib import Path
import argparse,hashlib,json,sqlite3,subprocess,sys,tempfile,zipfile,itertools
W=Path(__file__).resolve().parent;R=W.parents[2];sys.path.insert(0,str(R/'benchmarks'))
import bench,verify

def database_identity(raw):
 with tempfile.TemporaryDirectory() as d:
  p=Path(d)/'collection.sqlite';p.write_bytes(raw)
  db=sqlite3.connect(p.as_uri()+'?mode=ro&immutable=1',uri=True)
  assert db.execute('pragma integrity_check').fetchall()==[('ok',)]
  schema=db.execute("select type,name,tbl_name,sql from sqlite_master where name not like 'sqlite_autoindex%' order by type,name").fetchall()
  tables={}
  for (name,) in db.execute("select name from sqlite_master where type='table' order by name"):
   q='"'+name.replace('"','""')+'"'
   info=db.execute('pragma table_info('+q+')').fetchall()
   pk=[row[1] for row in sorted(info,key=lambda r:r[5]) if row[5]] or [row[1] for row in info]
   order=','.join('"'+k.replace('"','""')+'"' for k in pk)
   h=hashlib.sha256();count=0
   for row in db.execute('select * from '+q+' order by '+order):
    h.update(repr(row).encode());h.update(b'\n');count+=1
   tables[name]={'rows':count,'sha256':h.hexdigest()}
  out={'schema':schema,'tables':tables,'physical':{k:db.execute('pragma '+k).fetchone()[0] for k in ['page_size','page_count','freelist_count']},'raw_bytes':len(raw)}
  db.close();return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('run');ap.add_argument('before');ap.add_argument('after');ap.add_argument('--oracle',action='store_true');a=ap.parse_args()
 run=W/a.run;plan=json.loads((run/'plan.json').read_text());out=W/'candidate-verification'/a.run;out.mkdir(parents=True,exist_ok=True)
 results=[]
 for case in plan['cases']:
  doc=json.loads(Path(case['path']).read_text());pair={}
  for v in [a.before,a.after]:
   path=run/f"{case['name']}-{v}-0/output.apkg"
   raw,package=verify.read_package(path,doc);entry=database_identity(raw)
   entry['artifact_bytes']=path.stat().st_size;entry['sha256']=bench.sha256(path)
   with zipfile.ZipFile(path) as z:
    entry['other_entries']={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n!='collection.anki21b'}
   # Use the frozen pre-change inspector so correctness never relies on the candidate's own reader.
   checked=verify.verify_artifact(path,doc,W/'binaries/before-inspector');assert checked['status']=='passed',checked
   entry['raw_verification']=checked
   if a.oracle and v==a.after:
    dest=out/f"{case['name']}-{v}.anki.json"
    with dest.with_suffix('.stdout.log').open('w') as o,dest.with_suffix('.stderr.log').open('w') as e:
     subprocess.run([str(bench.ORACLE),case['path'],str(path),str(dest)],stdout=o,stderr=e,check=True,timeout=120)
    assert json.loads(dest.read_text())['status']=='passed'
    entry['oracle_sha256']=bench.sha256(dest)
   pair[v]=entry
  b=pair[a.before];c=pair[a.after]
  for key in ['schema','tables','other_entries']:assert b[key]==c[key],(case['name'],key)
  result={'case':case['name'],'status':'passed','variants':pair};results.append(result)
  print(case['name'],{v:(e['physical'],e['artifact_bytes']) for v,e in pair.items()},flush=True)
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
if __name__=='__main__':main()
