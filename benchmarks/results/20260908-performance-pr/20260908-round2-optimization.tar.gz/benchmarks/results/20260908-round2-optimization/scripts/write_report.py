from pathlib import Path
import json,math
W=Path(__file__).resolve().parent;R=W.parents[2]
s=json.loads((W/'summary.json').read_text());v=json.loads((W/'verification/summary.json').read_text());ci=json.loads((W/'ci-summary.json').read_text())
report=R/'docs/superpowers/specs/2026-09-08-round2-optimization-genanki.md'
archive='../../../benchmarks/results/20260908-round2-optimization'
def med(d):return d['median']
def variants(c):
 return next(v for k,v in c['variants'].items() if k.startswith('before')),next(v for k,v in c['variants'].items() if k.startswith('after'))
def formal_table(cells):
 lines=['| 场景 | 优化前 ms | 优化后 ms | 耗时变化 | RSS 前 MiB | RSS 后 MiB | RSS 变化 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
 for c in cells:
  b,a=variants(c);lines.append(f"| {c['case']} | {med(b['time_ms']):.2f} | {med(a['time_ms']):.2f} | {c['time_change_percent']:+.1f}% | {med(b['rss_mib']):.2f} | {med(a['rss_mib']):.2f} | {c['rss_change_percent']:+.1f}% |")
 return lines
G=s['genanki'];speedups=[c['genanki']['median_ms']/c['rust']['median_ms'] for c in G];geomean=math.exp(sum(map(math.log,speedups))/len(speedups));passed=sum(c['target_passed'] for c in G)
lines=['# 第二轮性能优化与 genanki 基准对比','',
'本轮在上一轮已优化源码上继续改进，采用三项变化：检查结果消费临时事实并移动字段/标签/身份元数据，现代 SQLite 数据库使用 8 KiB 页面，持久化媒体导出复用 zstd 上下文。批量 INSERT 和 16 KiB 页面候选均未采用。', '',
f"最终与 genanki 0.13.1 的 20 组对比中，Rust 耗时减少 **{min(c['reduction'] for c in G)*100:.1f}%–{max(c['reduction'] for c in G)*100:.1f}%**，速度比几何平均 **{geomean:.2f}×**；{passed}/20 组达到预先定义的至少减少 30% 耗时目标。几何平均按每个格子等权计算。",'',
'## 版本、方法与证据','',
'- 优化前为本任务上一轮最终实现，基于 main `c665271b0af9ec7badd2be57b516bf58afac15cd`，包含当时未提交的优化。优化后为当前工作区。公开 Rust crate 均为 0.1.0；契约包从 0.6.2 到 0.6.3，仅刷新三个物理 APKG 指纹夹具。',
'- Rust 1.92 release / System allocator / 默认公开 features。对照为原生 CPython 3.11 / genanki 0.13.1。输入沿用冻结的 PNG/WAV v2 合成媒体及文本，随机种子 20260907。',
f"- 最终会话从 `{s['power_profile']['utc']}` 开始，原生子进程实际电源为 **{s['power_profile']['required_power_source']}**。每次导出前后核对同一电源来源。编译、测试、Anki 验证和诊断探针不进入正式导出计时。", 
'- A/B 默认导出 29 组、比较构建 5 组：每格每版本 2 次预热 + 7 次耗时；独立 2 次预热 + 5 次 RSS。持久化 3 组：1 + 5 次耗时，独立 1 + 3 次 RSS。',
'- genanki 对比为 5 类场景 × 100/200/500/1000 条：每格每实现 3 次预热 + 10 次耗时，独立 3 次预热 + 5 次 RSS，共 840 次进程调用。每对导出完成后验证，Anki 导入/渲染覆盖每格每实现一个样本。',
'- 每次由原生 collector 测量进程创建至退出的 elapsed time 与操作系统峰值 RSS；对照交错，场景随机排序。冷缓存、后台负载和温度未隔离，因此小幅变化不视为普遍保证。RSS 是独立采样轮次的中位数。',
f'- 完整样本、最小/最大值、IQR、产物/源码哈希、失败记录及验证见[证据目录]({archive}/README.md)和[汇总数据]({archive}/summary.json)。表中耗时/RSS 变化为 `(后/前−1)×100%`，负数代表下降。','',
'## 本轮 A/B 结果','',
'### 默认导出（全部 29 组）','']+formal_table(s['formal']['default'])+['',
'8 KiB 页面改变数据库物理布局，因此前后 APKG 字节不同。各版本自身保持确定性；全部 schema、表值（含 sqlite_stat1）、非 collection ZIP 成员和完整检查报告均进行跨版本核对。', '',
'### 带基线比较的构建','']+formal_table(s['formal']['compare'])+['',
'### 持久化 CAS/staging 构建','']+formal_table(s['formal']['persistent'])+['',
'持久化样本每次使用新的保留目录，包含 CAS、staging、编码与输出落盘。上下文复用只作用于媒体编码；逐文件完整性检查、sync_all、按序发布及失败清理保持原有要求。','',
'## 最终版本与 genanki','',
'这是公开导出接口的端到端对比：Rust 输出现代 zstd APKG 并执行构建检查，genanki 输出其原生传统格式。两者遵守相同的输入、内容、媒体及导入验收，不代表单独压缩器或语言的速度比。', '',
'| 场景 | 条数 | Rust ms | genanki ms | 耗时减少 | Rust RSS MiB | genanki RSS MiB | Rust APKG KiB | genanki APKG KiB |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
labels={'basic-mixed-text-v1':'纯文本','basic-image-unique-v2':'独立图片','basic-audio-unique-v2':'独立音频','basic-mixed-unique-v2':'混合媒体','basic-mixed-shared-v2':'共享媒体'}
for c in G:
 a=c['rust'];b=c['genanki'];lines.append(f"| {labels.get(c['profile'],c['profile'])} | {c['size']} | {a['median_ms']:.2f} | {b['median_ms']:.2f} | {c['reduction']*100:.1f}% | {a['rss_mib']:.2f} | {b['rss_mib']:.2f} | {a['artifact_bytes']/1024:.1f} | {b['artifact_bytes']/1024:.1f} |")
image=next(c for c in G if c['profile']=='basic-image-unique-v2' and c['size']==1000)
misses=[c for c in G if not c['target_passed']]
for c in misses:
 lines+=['',f"未达到 30% 提速目标：{labels.get(c['profile'],c['profile'])} {c['size']} 条，耗时减少 {c['reduction']*100:.1f}%。音频补充探针表明，注册约占 21%、媒体准备约占 25%、最终事实检查约占 14%，SQLite 约占 9%；后续应优先测量媒体读取/编码和检查成本，而非继续围绕批量 SQL 绑定调整。"]
lines+=['',f"图片 1000 条的 Rust RSS 中位数 {image['rust']['rss_mib']:.2f} MiB，最大样本 {image['rust']['rss_max_mib']:.2f} MiB；预定义目标为不超过 64 MiB。内存、时间和压缩包体积是不同指标，不能用其中一项推断其他项。",'',
'## 优化后的瓶颈','',
'阶段数据来自独立私有探针，每格 1 次预热 + 3 次采样，并在同一阶段交错运行未插桩控制程序。表中比例先在每个样本内计算，再取中位数；嵌套阶段不可相加。这些耗时不替代上面的正式成绩。','',
'| 默认导出 | adapter 总 ms | SQLite ms / 占比 | VACUUM ms | 归一化 ms | 注册媒体 ms | 准备媒体 ms | 检查 ms | 探针/控制耗时差 |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for c in s['stages']['default']:
 def stage(label):return med(c['stages'][label]['time_ms']) if label in c['stages'] else 0
 pct=med(c['stages']['sqlite.total']['percent_of_adapter_total'])
 lines.append(f"| {c['case']} | {stage('adapter.total'):.2f} | {stage('sqlite.total'):.2f} / {pct:.1f}% | {stage('sqlite.compact'):.2f} | {stage('normalize.with_identity'):.2f} | {stage('adapter.registration'):.2f} | {stage('media.prepare'):.2f} | {stage('pipeline.inspect'):.2f} | {c['probe_time_change_percent']:+.1f}% |")
lines+=['','比较构建仍需同时保留基线和当前检查结果；完整事实读取、构造观察结果和逐项 canonical diff 仍有成本。字段与身份元数据已通过所有权转移减少重叠，未省略任何比对域。','',
'| 比较构建 | adapter 总 ms | 读取两份事实 ms | 两次完整检查 ms | 指纹 ms | diff ms | 检查其余部分 ms | 探针/控制耗时差 |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for c in s['stages']['compare']:
 d=c['stages'];g=lambda k:med(d[k]['time_ms'])
 lines.append(f"| {c['case']} | {g('adapter.total'):.2f} | {g('inspect.facts'):.2f} | {g('inspect.full'):.2f} | {g('inspect.fingerprint'):.2f} | {g('compare.diff'):.2f} | {med(c['full_inspect_remaining_ms']):.2f} | {c['probe_time_change_percent']:+.1f}% |")
lines+=['','“检查其余部分”逐样本按 full−facts−fingerprint 计算，包含观察构造、报告装配、临时数据销毁与探针开销，不能当作某一个函数的纯 CPU 时间。','',
'| 比较构建分配探针 | 优化前 Rust 活跃分配峰值 MiB | 优化后 MiB |',
'| --- | ---: | ---: |']
for c in s['memory']['compare']:
 a=c['variants']['profile-memory']['boundaries']['adapter.total#0']['end']['peak_rust_mib'];b=c['variants']['before-memory']['boundaries']['adapter.total#0']['end']['peak_rust_mib']
 lines.append(f"| {c['case']} | {med(b):.2f} | {med(a):.2f} |")
lines+=['','分配探针统计 Rust 请求的字节数，全局峰值包含本次进程此前所有阶段；SQLite/zstd 的 C 分配和 allocator 保留空间不在其中。阶段 RSS 是边界快照。不能用它替代正式操作系统峰值 RSS，也不能把进程末尾的 RSS 保留直接称为内存泄漏。','',
'| 持久化构建 | adapter 总 ms | CAS sync 并集 ms | staging sync 并集 ms | 两段 sync 并集占总耗时 | 媒体编码/写入 ms | 探针/控制耗时差 |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for c in s['stages']['persistent']:
 co=c['counters'];d=c['stages'];lines.append(f"| {c['case']} | {med(d['adapter.total']['time_ms']):.2f} | {med(co['persistent.cas_sync']['union_ms']):.2f} | {med(co['persistent.staging_sync']['union_ms']):.2f} | {med(c['sync_union_percent_of_adapter']):.1f}% | {med(d['apkg.retained_media']['time_ms']):.2f} | {c['probe_time_change_percent']:+.1f}% |")
lines+=['','为区分编码收益与落盘波动，额外对真实媒体文件执行“读取→编码→ZIP 写入”片段 A/B（2 次预热 + 7 次采样），每个输出 ZIP 的字节相同。此片段不包含 CAS、staging、完整性验证和 sync，不能作为端到端成绩。','',
'| 独立编码片段 | 每文件新建上下文 ms | 复用上下文 ms | 变化 |',
'| --- | ---: | ---: | ---: |']
for c in s['codec_slice']:
 lines.append(f"| {c['case']} | {c['fresh']['median_ms']:.2f} | {c['reuse']['median_ms']:.2f} | {c['change_percent']:+.1f}% |")
lines+=['','上下文新建从每文件一次移到循环外一次，但片段差异只有约 0.7%–1.5%，样本范围重叠；不将它称为已证明的显著提速。持久化图片 1000 条的正式中位数反而高约 1.5%，因此本轮主要可测收益来自 SQLite 页面调整和检查事实的所有权转移。']
lines+=['','sync 并集来自所有工作线程的区间并集，避免把重叠等待重复相加。CAS 与 staging 两个阶段顺序执行。各列独立取中位数，因此两列同步中位数相加再除以总中位数，不必等于逐样本占比的中位数；图片 1000 条的同步占比样本为 72.7%、77.2%、83.9%，也反映了 I/O 波动。后续优先研究能够保持持久化和独立副本语义的文件路径简化；当前证据不支持通过关闭 sync、放宽检查或增加无界并发获取速度。','',
'## 候选取舍与正确性','',
'- 所有权转移：回归测试先在旧实现上因长字段发生复制而失败，改动后验证字段、标签、身份元数据缓冲转移；既有实际卡片、缺失模板、重复 GUID、缺失模型、检查预算与失败优先级测试通过。',
'- SQLite：32 行以内且限制字段字节的批量 INSERT 在万条文本筛选中约慢 5%，未保留。8 KiB 页面使该筛选约快 13%，长字段约快 14%；16 KiB 相对 8 KiB 在多个常用负载变慢，未保留。精确样本见 screening 汇总，不能将不同筛选会话的绝对毫秒直接相减。',
'- 压缩上下文：零长度、边界长度、压缩性不同且大小交替的媒体，复用后的完整 ZIP 与每文件新建 encoder 的版本逐字节一致。持久化筛选的 APKG 字节也一致。',
'- 8 KiB 页面在候选筛选中曾出现 RSS 增长，因此最终单独复测操作系统峰值 RSS，并以正式表格为准。小幅内存变化不能仅由页面大小推断，也不声称所有场景均有收益。',
f"- 最终正确性：{v['pairwise_verified_cases']} 组前后逐表/完整检查报告等价验证；最终 Anki 对比矩阵 840 次调用逐次通过原始 SQLite 与精确媒体检查，并覆盖 40 个 Anki 导入/渲染样本。A/B 的新产物亦逐组经过 Anki 验证。所有正式及诊断调用都绑定到冻结输入和已验证的产物哈希。",
f"- 完整 CI：Rust 工作区 {ci['workspace_rust_passed']} 通过、{ci['workspace_rust_ignored']} 忽略；单独运行 23/23 用户能力场景，Node 各门禁通过，Python 107 项及 5 个 subtests 通过。额外 preserve_order 检查 20/20、嵌入包重建比对与 Rust 发布清单通过。",
'- 契约门禁首次发现旧 APKG 指纹不匹配。先对三个夹具用冻结旧 writer 和新 writer 验证全部数据库内容、其他 ZIP 成员及检查报告一致，再只更新 package_fingerprint，生成 BLAKE3 变更清单并重建 0.6.3 嵌入包。完整门禁随后通过。',
'- 初始所有权筛选因请求了不存在的比较夹具而在预热阶段失败，没有正式样本；原始失败保留，收集器增加未知场景和缺失基线的预检查后重新运行。未将失败或较慢样本静默删除。',
'- GUI 交互、真实音频播放、冷缓存、不同设备/文件系统/电源下的性能不在本次测量范围。','',
f'数据与可重跑脚本：[证据目录]({archive}/README.md)。本轮实现保留在工作区，未提交或推送。','']
report.write_text('\n'.join(lines));print(report)
