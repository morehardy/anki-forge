#![allow(dead_code)]
use std::{hint::black_box, time::Instant};
use serde_json::{json, Value};
mod writer_core { pub mod model; pub mod canonical_json; pub mod diff; pub mod candidate; }
use writer_core::{model::InspectReport, canonical_json::FilteredValue};
fn check_scalars() {
    let samples = ["null", "true", "false", "0", "1", "1.0", "0.0", "-0.0", "1e20", "-1", "18446744073709551615", "\"中文\\n\"", "[]", "{}", "{\"evidence_refs\":[\"x\"]}", "{\"object_id\":3}", "[1,2]", "[2,1]", "{\"nested\":{\"z\":1,\"a\":2}}", "{\"nested\":{\"a\":2,\"z\":1,\"selector\":0}}"];
    let mut values: Vec<Value> = samples.iter().map(|s| serde_json::from_str(s).unwrap()).collect();
    let original = values.clone();
    for value in original { values.push(json!({"outer": [value], "evidence_refs": ["ignore"]})); }
    let mut checked = 0;
    for domain in ["media", "references", "metadata"] {
        let excluded: &'static [&'static str] = if domain == "media" { &["selector", "evidence_refs", "binding_id", "object_id", "object_ref"] } else { &["selector", "evidence_refs"] };
        for a in &values { for b in &values {
            let expected = serde_json::to_string(&FilteredValue{value:a, excluded}).unwrap() == serde_json::to_string(&FilteredValue{value:b, excluded}).unwrap();
            assert_eq!(expected, writer_core::candidate::entry_payloads_equal(domain,a,b), "{domain}: {a} / {b}"); checked += 1;
        }}
    }
    eprintln!("canonical scalar/nested differential cases passed: {checked}");
}
fn main() -> anyhow::Result<()> {
    check_scalars();
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut records = vec![];
    for filename in args {
        let left: InspectReport = serde_json::from_slice(&std::fs::read(&filename)?)?;
        for percent in [0,1,100] {
            let mut right = left.clone();
            let mut count = 0;
            for value in &mut right.observations.references {
                if let Some(fields) = value.get_mut("fields").and_then(Value::as_object_mut) {
                    if count % 100 < percent { if let Some(text) = fields.get("Back").and_then(Value::as_str).map(str::to_owned) { fields.insert("Back".into(), Value::String(text + " changed")); } }
                    count += 1;
                }
            }
            let expected = serde_json::to_value(writer_core::diff::diff_reports(&left,&right)?)?;
            let actual = serde_json::to_value(writer_core::candidate::diff_reports(&left,&right)?)?;
            assert_eq!(actual, expected);
            for sample in -2i32..9 {
                for candidate in if sample % 2 == 0 { [true,false] } else { [false,true] } {
                    let started = Instant::now();
                    let result = if candidate { writer_core::candidate::diff_reports(black_box(&left),black_box(&right))? } else { writer_core::diff::diff_reports(black_box(&left),black_box(&right))? };
                    black_box(&result);
                    let elapsed = started.elapsed().as_nanos();
                    assert_eq!(serde_json::to_value(result)?, expected);
                    records.push(json!({"file":filename,"change_percent":percent,"sample":sample,"variant":if candidate {"structural"} else {"canonical_string"},"elapsed_ns":elapsed}));
                }
            }
        }
    }
    println!("{}", serde_json::to_string(&records)?);
    Ok(())
}
