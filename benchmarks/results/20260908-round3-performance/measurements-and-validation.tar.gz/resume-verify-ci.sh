#!/usr/bin/env bash
set -euo pipefail
repo_root="/Users/hp/Desktop/2026/anki-forge"
cd "$repo_root"
run() { "$@"; }
manifest_path="$repo_root/contracts/manifest.yaml"
dist_dir="$repo_root/dist"
python_path="$repo_root/bindings/python/src"
run npm --prefix bindings/node run test:installed
run npm --prefix bindings/node run example:minimal
run npm --prefix bindings/node run check:package
run cargo build -p contract_tools --release
run env "PYTHONPATH=$python_path" python3 -m pytest bindings/python/tests -q \
  --ignore=bindings/python/tests/test_import_isolation.py
run env "PYTHONPATH=$python_path" python3 bindings/python/examples/minimal_flow.py
run cargo run -p contract_tools -- verify --manifest "$manifest_path"
run cargo run -p contract_tools -- summary --manifest "$manifest_path"
run cargo run -p contract_tools -- package --manifest "$manifest_path" --out-dir "$dist_dir"

printf '\nverify-ci passed\n'
