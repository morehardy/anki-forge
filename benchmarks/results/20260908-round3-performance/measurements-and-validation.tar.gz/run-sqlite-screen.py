from pathlib import Path
import json,hashlib,subprocess,os,statistics,random
from datetime import datetime,timezone
W=Path(__file__).resolve().parent; R=W.parents[2]
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
cases=[c for c in json.loads((R/'benchmarks/.work/round2-optimization-20260908/cases.json').read_text()) if c['name'] in ('text-1000','text-10000','long-back-quadruple-1000','image-1000','audio-1000')]
run=W/'sqlite-screen';run.mkdir(exist_ok=False)
variants=['baseline','sqlite-memory','sqlite-temp32'];identities={v:sha(W/'binaries'/v) for v in variants}
power=lambda:subprocess.check_output(['pmset','-g','batt'],text=True)
initial=power();records=[]; artifacts={};rng=random.Random(20260908)
(run/'plan.json').write_text(json.dumps({'started':datetime.now(timezone.utc).isoformat(),'power':initial,'cases':cases,'binaries':identities,'timing':{'warmups':1,'samples':5},'rss':{'warmups':1,'samples':3},'scope':'Codex exec diagnostic, elapsed process launch to exit, cache not controlled, timing and RSS separate'},indent=2)+'\n')
for phase,warmups,samples in [('timing',1,5),('rss',1,3)]:
 for sample in range(-warmups,samples):
  ordered=cases.copy();rng.shuffle(ordered)
  for case in ordered:
   assert sha(case['path'])==case['input_sha256']
   for variant in variants if sample%2 else variants[::-1]:
    folder=run/f"{phase}-{case['name']}-{variant}-{sample}";folder.mkdir();(folder/'tmp').mkdir();out=folder/'output.apkg'
    env=dict(os.environ,TMPDIR=str(folder/'tmp'),TMP=str(folder/'tmp'),TEMP=str(folder/'tmp'),ANKI_AUDIT_MODE='deck')
    before=power();cmd=[str(R/'benchmarks/.tools/measure'),'120',str(folder/'stdout.log'),str(folder/'stderr.log'),str(W/'binaries'/variant),case['path'],str(out)]
    p=subprocess.run(cmd,env=env,text=True,capture_output=True)
    row={'phase':phase,'sample':sample,'case':case['name'],'variant':variant,'power_before':before,'power_after':power(),'collector_code':p.returncode,'collector_stderr':p.stderr}
    try:
     row['measurement']=json.loads(p.stdout)
     if out.is_file():row['output_sha256']=sha(out);row['output_bytes']=out.stat().st_size
    finally:
     with (run/'attempts.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    assert p.returncode==0,row
    m=row['measurement'];assert m['exit_code']==0 and m['reaped'] and not any(m[k] for k in ('spawn_error','leftover_descendants','interrupted_signal')),row
    assert row['power_before'].splitlines()[0]==row['power_after'].splitlines()[0]==initial.splitlines()[0]
    expected=artifacts.setdefault(case['name'],row['output_sha256']);assert row['output_sha256']==expected,(case['name'],'different APKG bytes')
    records.append(row)
    if phase!='timing' or sample!=0:out.unlink()
  print(phase,sample,flush=True)
summary=[]
for case in cases:
 row={'case':case['name'],'variants':{}}
 for variant in variants:
  times=[r['measurement']['elapsed_ns']/1e6 for r in records if r['phase']=='timing' and r['sample']>=0 and r['case']==case['name'] and r['variant']==variant]
  rss=[r['measurement']['peak_rss_bytes']/2**20 for r in records if r['phase']=='rss' and r['sample']>=0 and r['case']==case['name'] and r['variant']==variant]
  row['variants'][variant]={'median_ms':statistics.median(times),'times_ms':times,'rss_mib':rss,'median_rss_mib':statistics.median(rss)}
 row['change_percent']=(row['variants']['sqlite-memory']['median_ms']/row['variants']['baseline']['median_ms']-1)*100;summary.append(row)
(run/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert identities=={v:sha(W/'binaries'/v) for v in variants}
print(json.dumps(summary,indent=2))
