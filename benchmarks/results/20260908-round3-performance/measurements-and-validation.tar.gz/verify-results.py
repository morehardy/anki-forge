from pathlib import Path
from collections import Counter
import filecmp
import hashlib
import json
import sqlite3
import subprocess
import sys
import tempfile
import zipfile

W = Path(__file__).resolve().parent
R = W.parents[2]
sys.path.insert(0, str(R / 'benchmarks'))
import verify


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


OUT = W / 'verification'
OUT.mkdir(exist_ok=False)
old_inspector = R / 'benchmarks/.work/round2-optimization-20260908/binaries/before-inspector'
new_inspector = R / 'target/release/contract_tools'
oracle = R / 'scripts/roundtrip_oracle/target/debug/benchmark_oracle'
result = {
    'status': 'running',
    'inspectors': {str(p): sha(p) for p in [old_inspector, new_inspector]},
    'oracle_sha256': sha(oracle),
    'groups': {},
}
for group in ['stress-screen-v2', 'default-matrix', 'compare-matrix', 'persistent-matrix']:
    run = W / group
    plan = json.loads((run / 'plan.json').read_text())
    rows = [json.loads(line) for line in (run / 'attempts.jsonl').read_text().splitlines()]
    expected = Counter(
        (phase, sample, case['name'], variant)
        for phase in ['timing', 'rss']
        for sample in range(-plan[phase]['warmups'], plan[phase]['samples'])
        for case in plan['cases']
        for variant in plan['binaries']
    )
    assert Counter((r['phase'], r['sample'], r['case'], r['variant']) for r in rows) == expected
    for name, digest in plan['binaries'].items():
        assert sha(W / 'binaries' / name) == digest
    checked = []
    for case in plan['cases']:
        input_path = Path(case['path'])
        assert sha(input_path) == case['input_sha256']
        doc = json.loads(input_path.read_bytes())
        before = run / f"timing-{case['name']}-baseline-0/output.apkg"
        after = run / f"timing-{case['name']}-optimized-0/output.apkg"
        assert filecmp.cmp(before, after, shallow=False)
        digest = sha(after)
        for row in rows:
            if row['case'] != case['name']:
                continue
            assert row['output_sha256'] == digest
            assert row['power_before'].splitlines()[0] == row['power_after'].splitlines()[0] == plan['power'].splitlines()[0]
            m = row['measurement']
            assert row['collector_code'] == 0 and m['reaped']
            assert not any(m[k] for k in ['exit_code', 'signal', 'spawn_error', 'leftover_descendants', 'interrupted_signal'])
            if group == 'compare-matrix':
                log = run / f"{row['phase']}-{case['name']}-{row['variant']}-{row['sample']}/stdout.log"
                assert 'comparison=Complete' in log.read_text()
        folder = OUT / group / case['name']
        folder.mkdir(parents=True)
        raw_check = verify.verify_artifact(after, doc, old_inspector)
        assert raw_check['status'] == 'passed', raw_check
        (folder / 'raw-and-media.json').write_text(json.dumps(raw_check, indent=2) + '\n')
        raw, _ = verify.read_package(after, doc)
        with tempfile.TemporaryDirectory() as temp:
            database = Path(temp) / 'collection.sqlite'
            database.write_bytes(raw)
            db = sqlite3.connect(database.as_uri() + '?mode=ro&immutable=1', uri=True)
            assert db.execute('pragma integrity_check').fetchall() == [('ok',)]
            physical = {name: db.execute('pragma ' + name).fetchone()[0] for name in ['page_size', 'page_count', 'freelist_count']}
            db.close()
        raw_digest = hashlib.sha256(raw).hexdigest()
        del raw
        reports = []
        for index, inspector in enumerate([old_inspector, new_inspector]):
            path = folder / f'inspect-{index}.json'
            with path.open('wb') as out, (folder / f'inspect-{index}.stderr.log').open('wb') as err:
                subprocess.run([str(inspector), 'inspect', '--apkg', str(after), '--output', 'contract-json'], stdout=out, stderr=err, check=True, timeout=120)
            reports.append(path)
        assert filecmp.cmp(*reports, shallow=False), (group, case['name'], 'inspection changed')
        report_digest = sha(reports[0])
        for path in reports:
            path.unlink()
        anki_path = folder / 'anki.json'
        with (folder / 'anki.stdout.log').open('wb') as out, (folder / 'anki.stderr.log').open('wb') as err:
            subprocess.run([str(oracle), str(input_path), str(after), str(anki_path)], stdout=out, stderr=err, check=True, timeout=120)
        assert json.loads(anki_path.read_text())['status'] == 'passed'
        with zipfile.ZipFile(after) as archive:
            members = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist()}
        checked.append({'case': case['name'], 'artifact_sha256': digest, 'input_sha256': case['input_sha256'], 'raw_database_sha256': raw_digest, 'physical': physical, 'identical_full_report_sha256': report_digest, 'anki_sha256': sha(anki_path), 'zip_members': members})
        print(group, case['name'], 'passed', flush=True)
    result['groups'][group] = {'calls': len(rows), 'cases': checked}
    (OUT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
for path, identity in json.loads((W / 'media-source-identities.json').read_text()).items():
    assert sha(path) == identity['sha256']
for name, digest in json.loads((W / 'build-identities.json').read_text())['source_files'].items():
    assert sha(R / name) == digest, name
result['status'] = 'passed'
(OUT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
print('all source, sample, byte, raw content, report and Anki checks passed', flush=True)
