# 第三轮优化机会：源码分析与隔离筛选

结论见[补充分析](../../../docs/superpowers/specs/2026-09-08-round3-performance-opportunities.md)。本次没有改动生产源码，也没有提交或推送。

基线是[第二轮最终封存版本](../20260908-round2-optimization/final-build.json)，不是当前 main。通过该轮 `production-state.patch` 重建并逐一核对 198 个 crate 文件。当前 main 的 11 个源码差异见 `workspace-source-differences.json`。`source/` 保存本文引用的部分原版源码，便于在 main 尚未包含这些变化时准确定位。

- `summary.json`：两组端到端实验、独立 RSS 样本、diff 片段及媒体帧比率。
- `raw-screening.tar.gz`：全部端到端调用的计划、原始测量、标准输出/错误、编译记录与准备失败。包含 104 次 SQLite 筛选和 78 次 diff 筛选；各格每版本先 2 次预热、再 7 次耗时，另 1 次预热、3 次 RSS。还包含比较基线的构建日志，基线生成在计时外。
- `diff-samples.json` / `diff-summary.json`：3 份真实 APKG 检查报告，各对 Back 观测字段做 0%/1%/100% 合成修改，比较原版/候选；每组 2 次预热、9 次计时，总共 198 次片段调用。计时只包围 `diff_reports`，不包含报告读取、克隆、合成修改、结果序列化核对及结果销毁。
- `diff-checks.log` / `diff-preserve-check.log`：默认和 `preserve_order` 各 4,800 组原比较语义与结构比较的差分验证。包括整数/浮点、正负零、嵌套对象/数组、过滤键与 Unicode；不是所有可能 JSON 的形式化证明。
- `report-inputs.json`：片段输入的 APKG/报告路径与 SHA-256；报告由第二轮冻结的旧 inspector 生成。
- `frozen-artifact-checks.json`：4 个默认导出场景的输出与第二轮正式产物哈希一致。两个端到端实验的每次成功导出均核对同场景 A/B 完整 APKG 字节哈希相同。
- `probes/`：单变量候选补丁、原版和候选比较器、小型测试驱动与复跑脚本。仅作为研究原型；未完成用于合并的完整跨平台/错误行为门禁。

本轮使用 Rust 1.92.0 release、公开默认 features、System allocator、macOS ARM64、AC Power。通过 Codex exec 启动本地 collector；它测量进程创建至退出。与第二轮 Battery Power 的原生会话不同，不能跨轮相减毫秒或把本轮筛选替代正式 genanki 成绩。逐调用记录电源；文件缓存、温度及系统其他负载未隔离。编译、片段计时和端到端计时依次执行。RSS 的 3 次独立样本仅适合初筛。

保留两项准备失败：diff 驱动初次编译遇到借用类型错误，修正后才开始采样；SQLite 初次预热因复制二进制没有执行位，collector 报 `spawn_error=13`，没有启动导出子进程。修正权限后重新建立实验目录。失败均未计入有效样本。

复跑时把 `probes/` 的内容复制到新的 `benchmarks/.work/<name>/`，运行 `restore_source.py`。冻结的用例路径需要先按第二轮证据恢复，或在 runner 中映射到具有相同内容哈希的用例。runner 目前从第二轮 `.work` 中读取 `cases.json`。驱动的 crate 路径为 `../source/anki_forge`。

1. 用 `cargo build --release --locked --offline --manifest-path driver/Cargo.toml --bin anki-forge-benchmark --target-dir target` 构建原版，按可执行文件方式复制到 `binaries/baseline`。
2. 仅在隔离 `source` 中应用 `sqlite-memory.patch`，同命令构建并复制为 `binaries/sqlite-memory`；恢复原版后仅应用 `structural-diff.patch`，构建并复制为 `binaries/diff-structural`。在仓库内部子目录应用补丁时设置 `GIT_CEILING_DIRECTORIES` 为 WORK，避免 Git 根据外层仓库前缀跳过路径。
3. 等所有编译结束，依次运行 `run-screen.py`、`run-diff-e2e.py`。后者自动生成有稳定身份的比较基线。输出目录必须不存在。
4. diff 片段单独构建 `diff-probe/Cargo.toml`，参数是完整 `InspectReport` JSON 路径；报告可用冻结 inspector 的 `inspect --apkg <path> --output contract-json` 获取。`--features preserve-order` 构建后无参数运行，执行对应标量/嵌套差分检查。

大文件、可执行文件与 APKG 留在忽略的 `.work` 中。归档哈希见 `SHA256SUMS`。
