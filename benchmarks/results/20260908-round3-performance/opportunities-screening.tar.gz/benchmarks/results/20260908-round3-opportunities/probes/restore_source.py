"""Run after copying probes/* to benchmarks/.work/<new-name>/.

Restores the exact round2 crate without changing the working tree. Requires
its recorded base commit, archived patch and cached Rust dependencies.
"""
from pathlib import Path
import hashlib, io, json, os, shutil, subprocess, tarfile

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2]
SOURCE = WORK / 'source'
EVIDENCE = ROOT / 'benchmarks/results/20260908-round2-optimization'
record = json.loads((EVIDENCE / 'final-build.json').read_text())
SOURCE.mkdir(exist_ok=False)
raw = subprocess.check_output(['git', 'archive', record['head'], 'anki_forge',
                               'Cargo.lock', 'Cargo.toml', 'rust-toolchain.toml'], cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
    archive.extractall(SOURCE, filter='data')
subprocess.run(['git', 'apply', '--include=anki_forge/*',
                str(EVIDENCE / 'production-state.patch')], cwd=SOURCE,
               env=dict(os.environ, GIT_CEILING_DIRECTORIES=str(WORK)), check=True)
checks = []
for name, digest in record['source_files'].items():
    if name.startswith('anki_forge/'):
        actual = hashlib.sha256((SOURCE / name).read_bytes()).hexdigest()
        checks.append({'file': name, 'expected': digest, 'actual': actual})
        assert actual == digest, name
(SOURCE / 'Cargo.toml').write_text('''[workspace]
members = ["anki_forge"]
resolver = "2"
[workspace.package]
edition = "2021"
rust-version = "1.92"
[workspace.lints.rust]
unsafe_code = "forbid"
''')
shutil.copyfile(SOURCE / 'rust-toolchain.toml', WORK / 'rust-toolchain.toml')
(WORK / 'binaries').mkdir(exist_ok=True)
(WORK / 'source-check.json').write_text(json.dumps(checks, indent=2) + '\n')
print('Restored and verified', len(checks), 'crate files in', SOURCE)
