# Media export benchmark

Timing: 10 independent processes per cell; RSS: 5 separate processes.

| Profile | Notes | Rust ms | genanki ms | Time reduction | Rust RSS MiB | genanki RSS MiB |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| basic-audio-unique-v2 | 100 | 39.677 | 124.953 | 68.2% | 19.56 | 27.67 |
| basic-audio-unique-v2 | 200 | 56.629 | 147.640 | 61.6% | 21.67 | 28.69 |
| basic-audio-unique-v2 | 500 | 105.328 | 210.986 | 50.1% | 28.28 | 31.36 |
| basic-audio-unique-v2 | 1000 | 188.410 | 314.288 | 40.1% | 38.31 | 35.72 |
| basic-image-unique-v2 | 100 | 44.234 | 132.508 | 66.6% | 20.14 | 27.73 |
| basic-image-unique-v2 | 200 | 63.790 | 157.287 | 59.4% | 22.69 | 28.95 |
| basic-image-unique-v2 | 500 | 121.798 | 234.233 | 48.0% | 29.02 | 31.59 |
| basic-image-unique-v2 | 1000 | 224.036 | 357.522 | 37.3% | 39.14 | 35.44 |
| basic-mixed-shared-v2 | 100 | 34.666 | 116.863 | 70.3% | 19.77 | 27.88 |
| basic-mixed-shared-v2 | 200 | 38.127 | 119.343 | 68.1% | 21.31 | 28.23 |
| basic-mixed-shared-v2 | 500 | 51.552 | 126.070 | 59.1% | 26.16 | 30.05 |
| basic-mixed-shared-v2 | 1000 | 73.503 | 135.283 | 45.7% | 34.30 | 32.30 |
| basic-mixed-text-v1 | 100 | 25.749 | 106.165 | 75.7% | 14.58 | 27.55 |
| basic-mixed-text-v1 | 200 | 29.376 | 107.153 | 72.6% | 16.31 | 27.48 |
| basic-mixed-text-v1 | 500 | 40.847 | 114.870 | 64.4% | 21.28 | 29.89 |
| basic-mixed-text-v1 | 1000 | 59.365 | 124.668 | 52.4% | 29.31 | 31.70 |
| basic-mixed-unique-v2 | 100 | 38.108 | 124.141 | 69.3% | 19.91 | 27.89 |
| basic-mixed-unique-v2 | 200 | 52.439 | 140.402 | 62.7% | 21.95 | 28.22 |
| basic-mixed-unique-v2 | 500 | 92.868 | 189.786 | 51.1% | 28.09 | 30.73 |
| basic-mixed-unique-v2 | 1000 | 164.736 | 277.327 | 40.6% | 37.73 | 35.00 |

Cells meeting the proposed 30% reduction: 20/20.

All successful samples passed original SQLite row/template and exact media payload checks. Anki evidence, when enabled, covers one package per cell/adapter. No GUI or audible playback is checked.
