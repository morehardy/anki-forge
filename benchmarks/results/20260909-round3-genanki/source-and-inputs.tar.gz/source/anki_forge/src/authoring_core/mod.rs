pub mod canonical_json;
pub mod html_text;
pub mod identity;
pub mod media;
pub mod media_io;
pub mod media_refs;
pub mod mime;
pub mod model;
pub mod normalize;
pub mod risk;
pub mod selector;
pub mod stock;
pub mod template_parser;
pub mod template_semantics;

pub use canonical_json::to_canonical_json;
pub use html_text::strip_html_preserving_media_filenames;
pub use identity::{resolve_identity, DefaultNonceSource, NonceSource};
pub use media::{
    ingest_authoring_media, media_object_id, media_object_ref, sort_media_bindings,
    sort_media_objects, sort_media_references, validate_authoring_media_filename,
    AuthoringMediaSource, DiagnosticBehavior, MediaBinding, MediaFilenameError,
    MediaIngestDiagnostic, MediaIngestError, MediaIngestResult, MediaObject, MediaPolicy,
    MediaReference, MediaReferenceResolution, NormalizeOptions,
};
pub use media_io::{
    decode_inline_bytes, ingest_media_read_source_to_cas, object_store_path,
    CasExistingIntegrityReason, IngestedMediaBytes, MediaIoError, MediaReadSource,
    MediaSniffConfidence, SniffedMime,
};
pub use media_refs::{
    extract_media_reference_candidates, MediaReferenceCandidate, MediaReferenceCandidateKind,
};
pub use mime::{mime_from_filename, mime_from_filename_or_octet, APPLICATION_OCTET_STREAM};
pub use model::{
    AuthoringDocument, AuthoringField, AuthoringFieldMetadata, AuthoringGenerationRequirement,
    AuthoringMedia, AuthoringNote, AuthoringNotetype, AuthoringTemplate, ComparisonContext,
    MergeRiskReport, NormalizationRequest, NormalizedField, NormalizedFieldMetadata,
    NormalizedGenerationRequirement, NormalizedIr, NormalizedNote, NormalizedNotetype,
    NormalizedTemplate,
};
pub use normalize::{normalize, normalize_with_options, selector_resolve_error_code};
pub use risk::assess_risk;
pub use selector::{
    parse_selector, resolve_selector, Selector, SelectorError, SelectorResolveError, SelectorTarget,
};
pub use template_parser::{
    is_special_template_field, parse_template, ParsedTemplate, TemplateParseIssue,
    TemplateParseIssueKind, TemplateToken,
};
pub use template_semantics::{infer_generation_requirement, TemplateGenerationRequirement};

pub fn tool_contract_version() -> &'static str {
    "phase2-v1"
}
