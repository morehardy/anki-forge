use anyhow::Context;
use base64::Engine as _;
use sha1::{Digest, Sha1};
use std::collections::BTreeMap;
use std::io::{Read, Seek};
use std::path::Path;

use crate::deck::model::{
    Deck, MediaRef, RasterImageMetadata, RegisteredMedia, RegisteredMediaSource,
};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MediaError {
    InvalidSourceFilename {
        message: String,
    },
    SourceMissing {
        path: std::path::PathBuf,
        message: String,
    },
    SourceNotRegularFile {
        path: std::path::PathBuf,
    },
    SourceReadFailed {
        path: std::path::PathBuf,
        message: String,
    },
    SourceEmpty {
        label: String,
    },
    InvalidSourceLabel {
        label: String,
        message: String,
    },
    InlineTooLarge {
        label: String,
        size_bytes: usize,
        limit_bytes: usize,
    },
    UnsafeFilename {
        name: String,
        message: String,
    },
    ConflictingPayload {
        name: String,
    },
}

impl MediaError {
    pub fn code(&self) -> crate::diagnostics::ErrorCode {
        match self {
            Self::InvalidSourceFilename { .. } | Self::UnsafeFilename { .. } => {
                crate::diagnostics::ErrorCode::MediaUnsafeFilename
            }
            Self::SourceMissing { .. } => crate::diagnostics::ErrorCode::MediaSourceMissing,
            Self::SourceNotRegularFile { .. } => {
                crate::diagnostics::ErrorCode::MediaSourceNotRegularFile
            }
            Self::SourceReadFailed { .. } => crate::diagnostics::ErrorCode::MediaSourceReadFailed,
            Self::SourceEmpty { .. } => crate::diagnostics::ErrorCode::MediaEmptySource,
            Self::InvalidSourceLabel { .. } => {
                crate::diagnostics::ErrorCode::MediaInvalidSourceLabel
            }
            Self::InlineTooLarge { .. } => crate::diagnostics::ErrorCode::MediaInlineTooLarge,
            Self::ConflictingPayload { .. } => {
                crate::diagnostics::ErrorCode::MediaDuplicateFilenameConflict
            }
        }
    }
}

impl std::fmt::Display for MediaError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidSourceFilename { message } => write!(f, "{}: {message}", self.code()),
            Self::SourceMissing { path, message } => {
                write!(f, "{}: {}: {message}", self.code(), path.display())
            }
            Self::SourceNotRegularFile { path } => {
                write!(f, "{}: {}", self.code(), path.display())
            }
            Self::SourceReadFailed { path, message } => {
                write!(f, "{}: {}: {message}", self.code(), path.display())
            }
            Self::SourceEmpty { label } => write!(f, "{}: {label}", self.code()),
            Self::InvalidSourceLabel { label, message } => {
                write!(f, "{}: {label}: {message}", self.code())
            }
            Self::InlineTooLarge {
                label,
                size_bytes,
                limit_bytes,
            } => write!(
                f,
                "{}: {label} has {size_bytes} bytes, above inline limit {limit_bytes}",
                self.code()
            ),
            Self::UnsafeFilename { message, .. } => write!(f, "{}: {message}", self.code()),
            Self::ConflictingPayload { name } => {
                write!(f, "{}: {name}", self.code())
            }
        }
    }
}

impl std::error::Error for MediaError {}

impl crate::diagnostics::ErrorCodeExt for MediaError {
    fn code(&self) -> crate::diagnostics::ErrorCode {
        MediaError::code(self)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum MediaSource {
    File { path: std::path::PathBuf },
    Bytes { name: String, bytes: Vec<u8> },
}

pub struct MediaRegistry<'a> {
    deck: &'a mut Deck,
}

impl MediaSource {
    pub fn from_file(path: impl Into<std::path::PathBuf>) -> Self {
        Self::File { path: path.into() }
    }

    pub fn from_bytes(name: impl Into<String>, bytes: Vec<u8>) -> Self {
        Self::Bytes {
            name: name.into(),
            bytes,
        }
    }
}

impl MediaRef {
    pub(crate) fn new(name: String) -> Self {
        Self(name)
    }

    pub fn name(&self) -> &str {
        &self.0
    }
}

impl Deck {
    pub fn media(&mut self) -> MediaRegistry<'_> {
        MediaRegistry { deck: self }
    }
}

impl<'a> MediaRegistry<'a> {
    pub fn add(&mut self, source: MediaSource) -> anyhow::Result<MediaRef> {
        let registered = RegisteredMedia::from_source(source)?;

        if let Some(existing) = self.deck.media.get_mut(&registered.name) {
            if existing.sha1_hex == registered.sha1_hex {
                if existing.raster_image.is_none() {
                    existing.raster_image = registered.raster_image.clone();
                }
                return Ok(MediaRef::new(existing.name.clone()));
            }

            return Err(MediaError::ConflictingPayload {
                name: registered.name,
            }
            .into());
        }

        let reference = MediaRef::new(registered.name.clone());
        self.deck.media.insert(registered.name.clone(), registered);
        Ok(reference)
    }

    pub fn get(&self, name: &str) -> Option<MediaRef> {
        self.deck
            .media
            .get(name)
            .map(|registered| MediaRef::new(registered.name.clone()))
    }
}

pub(crate) fn backfill_missing_raster_image_metadata(
    media: &mut BTreeMap<String, RegisteredMedia>,
) {
    for registered in media.values_mut() {
        repair_missing_raster_image_metadata(registered);
    }
}

fn repair_missing_raster_image_metadata(registered: &mut RegisteredMedia) {
    if registered.raster_image.is_some() {
        return;
    }

    registered.raster_image = match &registered.source {
        RegisteredMediaSource::File { path } => {
            raster_image_metadata_from_path(&registered.name, path)
        }
        RegisteredMediaSource::InlineBytes { data_base64 } => {
            let Ok(bytes) = base64::engine::general_purpose::STANDARD.decode(data_base64) else {
                return;
            };
            raster_image_metadata_from_bytes(&registered.name, &bytes)
        }
    };
}

impl RegisteredMedia {
    pub fn from_source(source: MediaSource) -> anyhow::Result<Self> {
        let (name, registered_source, sha1_hex, raster_image) = match source {
            MediaSource::File { path } => {
                let name = path
                    .file_name()
                    .and_then(|item| item.to_str())
                    .ok_or_else(|| MediaError::InvalidSourceFilename {
                        message: "media path must end in a valid filename".into(),
                    })?
                    .to_string();
                validate_source_file(&path)?;
                let (sha1_hex, raster_image) = observe_file(&name, &path)?;
                (
                    name,
                    RegisteredMediaSource::File { path },
                    sha1_hex,
                    raster_image,
                )
            }
            MediaSource::Bytes { name, bytes } => {
                let sha1_hex = hex::encode(Sha1::digest(&bytes));
                let raster_image = raster_image_metadata_from_bytes(&name, &bytes);
                let encoded = base64::engine::general_purpose::STANDARD.encode(&bytes);
                (
                    name,
                    RegisteredMediaSource::InlineBytes {
                        data_base64: encoded,
                    },
                    sha1_hex,
                    raster_image,
                )
            }
        };
        validate_media_filename(&name)?;

        Ok(Self {
            name: name.clone(),
            source: registered_source,
            declared_mime: Some(mime_from_name(&name)),
            sha1_hex,
            raster_image,
        })
    }

    pub(crate) fn to_authoring_media(
        &self,
        media_source_dir: &Path,
    ) -> anyhow::Result<crate::authoring::AuthoringMedia> {
        let source = match &self.source {
            RegisteredMediaSource::File { path } => {
                ensure_safe_media_source_dir(media_source_dir)?;
                let target = media_source_dir.join(&self.name);
                ensure_not_symlink(&target)?;
                std::fs::copy(path, &target).with_context(|| {
                    format!(
                        "copy media source {} to {}",
                        path.display(),
                        target.display()
                    )
                })?;
                crate::authoring::AuthoringMediaSource::Path {
                    path: self.name.clone(),
                }
            }
            RegisteredMediaSource::InlineBytes { data_base64 } => {
                crate::authoring::AuthoringMediaSource::InlineBytes {
                    data_base64: data_base64.clone(),
                }
            }
        };

        Ok(crate::authoring::AuthoringMedia {
            id: format!("media:{}", self.name),
            desired_filename: self.name.clone(),
            source,
            declared_mime: self.declared_mime.clone(),
        })
    }

    pub(crate) fn to_self_contained_authoring_media(
        &self,
    ) -> anyhow::Result<crate::authoring::AuthoringMedia> {
        let source = match &self.source {
            RegisteredMediaSource::File { path } => {
                let bytes = std::fs::read(path)
                    .with_context(|| format!("read media source file: {}", path.display()))?;
                crate::authoring::AuthoringMediaSource::InlineBytes {
                    data_base64: base64::engine::general_purpose::STANDARD.encode(bytes),
                }
            }
            RegisteredMediaSource::InlineBytes { data_base64 } => {
                crate::authoring::AuthoringMediaSource::InlineBytes {
                    data_base64: data_base64.clone(),
                }
            }
        };

        Ok(crate::authoring::AuthoringMedia {
            id: format!("media:{}", self.name),
            desired_filename: self.name.clone(),
            source,
            declared_mime: self.declared_mime.clone(),
        })
    }
}

fn validate_source_file(path: &Path) -> anyhow::Result<()> {
    let metadata = std::fs::metadata(path).map_err(|err| match err.kind() {
        std::io::ErrorKind::NotFound => MediaError::SourceMissing {
            path: path.to_path_buf(),
            message: err.to_string(),
        },
        _ => MediaError::SourceReadFailed {
            path: path.to_path_buf(),
            message: err.to_string(),
        },
    })?;
    if !metadata.is_file() {
        return Err(MediaError::SourceNotRegularFile {
            path: path.to_path_buf(),
        }
        .into());
    }
    Ok(())
}

fn validate_media_source_dir_metadata(
    media_source_dir: &Path,
    metadata: &std::fs::Metadata,
) -> anyhow::Result<()> {
    anyhow::ensure!(
        !metadata.file_type().is_symlink(),
        "media source directory must not be a symlink: {}",
        media_source_dir.display()
    );
    anyhow::ensure!(
        metadata.is_dir(),
        "media source path must be a directory: {}",
        media_source_dir.display()
    );
    Ok(())
}

fn ensure_safe_media_source_dir(media_source_dir: &Path) -> anyhow::Result<()> {
    match std::fs::symlink_metadata(media_source_dir) {
        Ok(metadata) => {
            validate_media_source_dir_metadata(media_source_dir, &metadata)?;
        }
        Err(err) if err.kind() == std::io::ErrorKind::NotFound => {
            std::fs::create_dir_all(media_source_dir).with_context(|| {
                format!(
                    "create media source directory: {}",
                    media_source_dir.display()
                )
            })?;
            let metadata = std::fs::symlink_metadata(media_source_dir).with_context(|| {
                format!(
                    "stat media source directory: {}",
                    media_source_dir.display()
                )
            })?;
            validate_media_source_dir_metadata(media_source_dir, &metadata)?;
        }
        Err(err) => {
            return Err(err).with_context(|| {
                format!(
                    "stat media source directory: {}",
                    media_source_dir.display()
                )
            });
        }
    }

    Ok(())
}

fn ensure_not_symlink(path: &Path) -> anyhow::Result<()> {
    match std::fs::symlink_metadata(path) {
        Ok(metadata) => {
            anyhow::ensure!(
                !metadata.file_type().is_symlink(),
                "media input target must not be a symlink: {}",
                path.display()
            );
        }
        Err(err) if err.kind() == std::io::ErrorKind::NotFound => {}
        Err(err) => {
            return Err(err)
                .with_context(|| format!("stat media input target: {}", path.display()));
        }
    }
    Ok(())
}

fn observe_file(name: &str, path: &Path) -> anyhow::Result<(String, Option<RasterImageMetadata>)> {
    let mut file = std::fs::File::open(path).map_err(|err| match err.kind() {
        std::io::ErrorKind::NotFound => MediaError::SourceMissing {
            path: path.to_path_buf(),
            message: err.to_string(),
        },
        _ => MediaError::SourceReadFailed {
            path: path.to_path_buf(),
            message: err.to_string(),
        },
    })?;
    let mut hasher = Sha1::new();
    let mut buffer = [0_u8; 64 * 1024];
    let mut raster_image = None;
    let mut first_chunk = true;
    loop {
        let read = file
            .read(&mut buffer)
            .map_err(|err| MediaError::SourceReadFailed {
                path: path.to_path_buf(),
                message: err.to_string(),
            })?;
        if read == 0 {
            break;
        }
        if first_chunk {
            // Most image dimensions fit in the bytes already read for hashing.
            raster_image = raster_image_metadata_from_bytes(name, &buffer[..read]);
            first_chunk = false;
        }
        hasher.update(&buffer[..read]);
    }
    if raster_image.is_none()
        && matches!(
            crate::authoring_core::mime_from_filename(name),
            Some("image/png" | "image/jpeg" | "image/gif" | "image/webp")
        )
        && file.rewind().is_ok()
    {
        // JPEG metadata can place dimensions beyond the first block. Keep the
        // streaming parser fallback, using the same open source handle.
        raster_image = imagesize::reader_size(std::io::BufReader::new(file))
            .ok()
            .map(|size| RasterImageMetadata {
                width_px: size.width as u32,
                height_px: size.height as u32,
            });
    }
    Ok((hex::encode(hasher.finalize()), raster_image))
}

fn validate_media_filename(name: &str) -> anyhow::Result<()> {
    crate::authoring_core::validate_authoring_media_filename(name).map_err(anyhow::Error::new)
}

fn mime_from_name(name: &str) -> String {
    crate::authoring_core::mime_from_filename_or_octet(name)
}

fn raster_image_metadata_from_path(name: &str, path: &Path) -> Option<RasterImageMetadata> {
    match crate::authoring_core::mime_from_filename(name) {
        Some("image/png" | "image/jpeg" | "image/gif" | "image/webp") => {
            imagesize::size(path).ok().map(|size| RasterImageMetadata {
                width_px: size.width as u32,
                height_px: size.height as u32,
            })
        }
        _ => None,
    }
}

fn raster_image_metadata_from_bytes(name: &str, bytes: &[u8]) -> Option<RasterImageMetadata> {
    match crate::authoring_core::mime_from_filename(name) {
        Some("image/png" | "image/jpeg" | "image/gif" | "image/webp") => {
            imagesize::blob_size(bytes)
                .ok()
                .map(|size| RasterImageMetadata {
                    width_px: size.width as u32,
                    height_px: size.height as u32,
                })
        }
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::deck::model::IoMode;

    const HEART_PNG: &[u8] = include_bytes!(
        "../../../contracts/fixtures/phase3/manual-desktop-v1/S03_io_minimal/assets/occlusion-heart.png"
    );

    #[test]
    fn file_registration_matches_inline_fingerprints_and_dimensions() {
        let root = tempfile::tempdir().unwrap();
        let mut long_header_jpeg = vec![0xff, 0xd8];
        // Two APP1 segments put the SOF dimensions beyond the first 64 KiB.
        for _ in 0..2 {
            long_header_jpeg.extend_from_slice(&[0xff, 0xe1, 0xff, 0xff]);
            long_header_jpeg.extend(std::iter::repeat_n(0, 65533));
        }
        long_header_jpeg.extend_from_slice(&[
            0xff, 0xc0, 0x00, 0x11, 0x08, 0x00, 0x56, 0x00, 0xe4, 0x03, 0x01, 0x11, 0x00, 0x02,
            0x11, 0x00, 0x03, 0x11, 0x00, 0xff, 0xd9,
        ]);
        for (name, bytes, is_image) in [
            ("heart.png", HEART_PNG.to_vec(), true),
            ("long-header.jpg", long_header_jpeg, true),
            ("broken.png", b"not an image".to_vec(), false),
            ("large.bin", vec![42; 150_000], false),
        ] {
            let path = root.path().join(name);
            std::fs::write(&path, &bytes).unwrap();
            let file = RegisteredMedia::from_source(MediaSource::from_file(&path)).unwrap();
            let inline =
                RegisteredMedia::from_source(MediaSource::from_bytes(name, bytes)).unwrap();
            assert_eq!(file.sha1_hex, inline.sha1_hex, "{name}");
            assert_eq!(file.raster_image, inline.raster_image, "{name}");
            if is_image {
                assert_eq!(
                    file.raster_image,
                    Some(RasterImageMetadata {
                        width_px: 228,
                        height_px: 86,
                    }),
                    "{name}"
                );
            } else {
                assert!(file.raster_image.is_none(), "{name}");
            }
        }
    }

    #[test]
    fn same_sha_registration_repairs_missing_raster_metadata() {
        let mut deck = Deck::new("Anatomy");
        let mut legacy_media = RegisteredMedia::from_source(MediaSource::from_bytes(
            "occlusion-heart.png",
            HEART_PNG.to_vec(),
        ))
        .expect("legacy media");
        legacy_media.raster_image = None;
        deck.media
            .insert("occlusion-heart.png".to_string(), legacy_media);

        let image = deck
            .media()
            .add(MediaSource::from_bytes(
                "occlusion-heart.png",
                HEART_PNG.to_vec(),
            ))
            .expect("same media registration");

        let raster_image = deck
            .media
            .get("occlusion-heart.png")
            .and_then(|media| media.raster_image.as_ref())
            .expect("raster metadata repaired");
        assert_eq!(raster_image.width_px, 228);
        assert_eq!(raster_image.height_px, 86);

        deck.image_occlusion()
            .note(image)
            .mode(IoMode::HideAllGuessOne)
            .rect(10, 20, 30, 40)
            .add()
            .expect("io identity uses repaired dimensions");
    }

    #[test]
    fn media_source_dir_metadata_rejects_non_directory() {
        let root = tempfile::tempdir().expect("tempdir");
        let media_source_dir = root.path().join("media-input");
        std::fs::write(&media_source_dir, b"not a directory").expect("write file");
        let metadata = std::fs::symlink_metadata(&media_source_dir).expect("metadata");

        let err = validate_media_source_dir_metadata(&media_source_dir, &metadata)
            .expect_err("file metadata must be rejected");

        assert!(
            err.to_string().contains("must be a directory"),
            "unexpected error: {err}"
        );
    }
}
