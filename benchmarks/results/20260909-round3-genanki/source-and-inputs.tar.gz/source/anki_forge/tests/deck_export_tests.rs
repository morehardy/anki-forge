#![cfg(feature = "internal-tools")]

use anki_forge::build::{BuildOptions, BuildStatus};
use anki_forge::deck::{Deck, IoMode, MediaSource, Package};
use serde_json::json;

#[test]
fn deck_export_surfaces_use_runtime_defaults_and_real_artifact_paths() {
    let mut deck = Deck::builder("Spanish").stable_id("spanish-v1").build();
    deck.basic()
        .note("hola", "hello")
        .stable_id("es-hola")
        .add()
        .expect("add basic note");

    let artifacts_dir = unique_artifacts_dir("deck-export");
    let build = deck
        .build(BuildOptions::new().output(artifacts_dir.join("deck.apkg")))
        .expect("build facade");

    assert!(build.artifact.as_ref().expect("artifact").path().exists());
    assert_eq!(build.status, BuildStatus::Success);
    assert_eq!(build.counts.notes, 1);

    let bytes = deck.to_apkg_bytes().expect("apkg bytes");
    assert!(!bytes.is_empty());
}

#[test]
fn deck_build_uses_cas_media_without_normalized_base64_payload() {
    let root = unique_artifacts_dir("deck-cas-build");
    let mut deck = anki_forge::Deck::builder("Media Deck")
        .stable_id("media-deck")
        .build();
    let media = deck
        .media()
        .add(MediaSource::from_bytes("hello.txt", b"hello".to_vec()))
        .unwrap();
    deck.basic()
        .note("front", format!("<img src=\"{}\">", media.name()))
        .stable_id("n1")
        .add()
        .unwrap();

    let build = Package::single(deck.clone()).build(&root).unwrap();
    let manifest = std::fs::read_to_string(build.staging_manifest_path()).unwrap();

    assert!(manifest.contains("media_objects"));
    assert!(manifest.contains("media_bindings"));
    assert!(!manifest.contains("data_base64"));
}

#[test]
fn deck_build_keeps_file_media_path_backed_until_normalize() {
    let root = unique_artifacts_dir("deck-file-cas-build");
    let source_dir = root.join("source");
    std::fs::create_dir_all(&source_dir).unwrap();
    std::fs::write(source_dir.join("hello.txt"), b"hello").unwrap();
    let mut deck = anki_forge::Deck::builder("Media Deck")
        .stable_id("media-deck")
        .build();
    let media = deck
        .media()
        .add(MediaSource::from_file(source_dir.join("hello.txt")))
        .unwrap();
    deck.basic()
        .note("front", format!("<img src=\"{}\">", media.name()))
        .stable_id("n1")
        .add()
        .unwrap();

    let build = Package::single(deck.clone()).build(&root).unwrap();
    let manifest = std::fs::read_to_string(build.staging_manifest_path()).unwrap();

    assert!(!root.join(".anki-forge-media-input/hello.txt").exists());
    assert!(manifest.contains("media_objects"));
    assert!(!manifest.contains("data_base64"));
}

#[cfg(unix)]
#[test]
fn deck_build_rejects_preexisting_media_input_target_symlink() {
    let root = unique_artifacts_dir("deck-file-cas-symlink-target");
    let source_dir = root.join("source");
    std::fs::create_dir_all(&source_dir).unwrap();
    std::fs::write(source_dir.join("hello.txt"), b"hello").unwrap();
    let victim_path = root.join("victim.txt");
    std::fs::write(&victim_path, b"do not overwrite").unwrap();
    let media_input_dir = root.join(".anki-forge-media-input");
    std::fs::create_dir_all(&media_input_dir).unwrap();
    std::os::unix::fs::symlink(&victim_path, media_input_dir.join("hello.txt")).unwrap();

    let mut deck = anki_forge::Deck::builder("Media Deck")
        .stable_id("media-deck")
        .build();
    let media = deck
        .media()
        .add(MediaSource::from_file(source_dir.join("hello.txt")))
        .unwrap();
    deck.basic()
        .note("front", format!("<img src=\"{}\">", media.name()))
        .stable_id("n1")
        .add()
        .unwrap();

    let err = match deck.build(
        BuildOptions::new()
            .artifacts_dir(root.clone())
            .output(root.join("deck.apkg")),
    ) {
        Ok(_) => panic!("build must reject media input target symlink"),
        Err(err) => err,
    };

    assert!(
        err.report
            .diagnostics
            .iter()
            .any(|diagnostic| diagnostic.message.contains("symlink")),
        "unexpected diagnostics: {:?}",
        err.report.diagnostics
    );
    assert_eq!(std::fs::read(&victim_path).unwrap(), b"do not overwrite");
}

#[test]
fn package_repeated_builds_keep_file_media() {
    let root = tempfile::tempdir().unwrap();
    let source = root.path().join("hello.txt");
    std::fs::write(&source, b"hello").unwrap();
    let mut deck = Deck::builder("Media Deck").stable_id("media-deck").build();
    let media = deck.media().add(MediaSource::from_file(&source)).unwrap();
    deck.basic()
        .note("front", format!("<img src=\"{}\">", media.name()))
        .stable_id("n1")
        .add()
        .unwrap();
    let package = Package::single(deck);
    let artifacts_dir = root.path().join("artifacts");

    let first = package.build(&artifacts_dir).expect("first build");
    let first_bytes = std::fs::read(first.apkg_path()).unwrap();
    let second = package
        .build(&artifacts_dir)
        .unwrap_or_else(|error| panic!("repeated build should succeed: {error:#}"));

    assert_eq!(std::fs::read(second.apkg_path()).unwrap(), first_bytes);
    assert_eq!(std::fs::read(&source).unwrap(), b"hello");
}

#[test]
fn package_retries_after_media_failure_without_leaving_input_copies() {
    let root = tempfile::tempdir().unwrap();
    let source_a = root.path().join("a.txt");
    let source_b = root.path().join("b.txt");
    std::fs::write(&source_a, b"first source").unwrap();
    std::fs::write(&source_b, b"second source").unwrap();
    let mut deck = Deck::builder("Media Deck").stable_id("media-deck").build();
    let a = deck.media().add(MediaSource::from_file(&source_a)).unwrap();
    let b = deck.media().add(MediaSource::from_file(&source_b)).unwrap();
    deck.basic()
        .note("front", format!("[sound:{}][sound:{}]", a.name(), b.name()))
        .stable_id("n1")
        .add()
        .unwrap();
    let package = Package::single(deck);
    let artifacts_dir = root.path().join("artifacts");

    std::fs::remove_file(&source_b).unwrap();
    let failure = package.build(&artifacts_dir).err().expect("missing media");
    assert!(failure.to_string().contains("MEDIA.SOURCE_MISSING"));
    std::fs::write(&source_b, b"second source").unwrap();
    let build = package.build(&artifacts_dir).expect("retry after repair");

    build.inspect_apkg().expect("inspect repaired package");
    assert_eq!(std::fs::read(&source_a).unwrap(), b"first source");
    assert_eq!(std::fs::read(&source_b).unwrap(), b"second source");
}

#[test]
fn package_rebuild_accepts_newly_registered_media_content() {
    let root = tempfile::tempdir().unwrap();
    let source = root.path().join("hello.txt");
    let make_package = || {
        let mut deck = Deck::builder("Media Deck").stable_id("media-deck").build();
        let media = deck.media().add(MediaSource::from_file(&source)).unwrap();
        deck.basic()
            .note("front", format!("[sound:{}]", media.name()))
            .stable_id("n1")
            .add()
            .unwrap();
        Package::single(deck)
    };
    let artifacts_dir = root.path().join("artifacts");

    std::fs::write(&source, b"original media").unwrap();
    let first = make_package().build(&artifacts_dir).expect("initial build");
    let original = std::fs::read(first.apkg_path()).unwrap();
    std::fs::write(&source, b"updated media").unwrap();
    let updated = make_package().build(&artifacts_dir).expect("updated build");

    updated.inspect_apkg().expect("inspect updated package");
    assert_ne!(std::fs::read(updated.apkg_path()).unwrap(), original);
    assert_eq!(std::fs::read(&source).unwrap(), b"updated media");
}

#[test]
fn package_build_limits_are_explicit_and_block_publication_until_raised() {
    let root = tempfile::tempdir().unwrap();
    let source = root.path().join("hello.txt");
    std::fs::write(&source, b"hello").unwrap();
    let mut deck = Deck::builder("Media Deck").stable_id("media-deck").build();
    let media = deck.media().add(MediaSource::from_file(&source)).unwrap();
    deck.basic()
        .note("front", format!("[sound:{}]", media.name()))
        .stable_id("n1")
        .add()
        .unwrap();
    let package = Package::single(deck);
    let artifacts_dir = root.path().join("artifacts");
    let mut limits = anki_forge::writer::InspectLimits::default();
    limits.max_media_bytes = 4;

    let failure = package
        .build_with_limits(&artifacts_dir, limits.clone())
        .err()
        .expect("media budget must block the candidate");
    assert!(failure
        .to_string()
        .contains("INSPECT.RESOURCE_LIMIT_EXCEEDED"));
    assert!(!artifacts_dir.join("package.apkg").exists());

    limits.max_media_bytes = 5;
    let build = package
        .build_with_limits(&artifacts_dir, limits)
        .expect("explicitly raised media budget");
    build
        .inspect_apkg()
        .expect("inspect package with its budget");
    assert!(build.apkg_path().is_file());
    assert_eq!(std::fs::read(&source).unwrap(), b"hello");
}

#[test]
fn package_result_retains_its_inspection_limits_for_later_reads() {
    let root = tempfile::tempdir().unwrap();
    let source = root.path().join("hello.txt");
    let make_package = || {
        let mut deck = Deck::builder("Media Deck").stable_id("media-deck").build();
        let media = deck.media().add(MediaSource::from_file(&source)).unwrap();
        deck.basic()
            .note("front", format!("[sound:{}]", media.name()))
            .stable_id("n1")
            .add()
            .unwrap();
        Package::single(deck)
    };
    let artifacts_dir = root.path().join("artifacts");
    let mut limits = anki_forge::writer::InspectLimits::default();
    limits.max_media_bytes = 5;
    std::fs::write(&source, b"hello").unwrap();
    let limited = make_package()
        .build_with_limits(&artifacts_dir, limits)
        .expect("build with five-byte budget");

    // The explicit output path can later be replaced by another successful build.
    std::fs::write(&source, b"longer").unwrap();
    let replaced = make_package().build(&artifacts_dir).unwrap();
    replaced
        .inspect_apkg()
        .expect("default budget accepts replacement");
    let failure = limited
        .inspect_apkg()
        .expect_err("earlier result must retain its selected budget");
    assert!(failure
        .to_string()
        .contains("INSPECT.RESOURCE_LIMIT_EXCEEDED"));
}

#[test]
fn deck_basic_flow_example_shape_matches_the_public_happy_path() {
    let mut deck = Deck::builder("Spanish").stable_id("spanish-v1").build();

    deck.basic()
        .note("hola", "hello")
        .stable_id("es-hola")
        .add()
        .expect("add basic");

    deck.cloze()
        .note("La capital de Espana es {{c1::Madrid}}")
        .extra("Europe")
        .stable_id("geo-es-capital")
        .add()
        .expect("add cloze");

    let heart = deck
        .media()
        .add(MediaSource::from_bytes(
            "heart.png",
            vec![0x89, 0x50, 0x4E, 0x47],
        ))
        .expect("add media");

    deck.image_occlusion()
        .note(heart)
        .mode(IoMode::HideAllGuessOne)
        .rect(10, 20, 80, 40)
        .header("Heart")
        .back_extra("Identify the chamber")
        .comments("Left ventricle")
        .stable_id("anatomy-heart-1")
        .add()
        .expect("add image occlusion");

    deck.validate().expect("deck should validate");

    assert_eq!(deck.notes().len(), 3);
    assert_eq!(deck.notes()[0].id(), "es-hola");
    assert_eq!(deck.notes()[1].id(), "geo-es-capital");
    assert_eq!(deck.notes()[2].id(), "anatomy-heart-1");
}

#[test]
fn package_single_export_surfaces_support_bytes_and_package_stable_id() {
    let mut deck = Deck::builder("Spanish").stable_id("spanish-v1").build();
    deck.basic()
        .note("hola", "hello")
        .stable_id("es-hola")
        .add()
        .expect("add basic note");

    let base_package = Package::single(deck.clone());
    let overridden_package = Package::single(deck.clone()).with_stable_id("package-v1");

    let deck_bytes = deck.to_apkg_bytes().expect("deck bytes");
    let base_bytes = base_package.to_apkg_bytes().expect("base package bytes");
    let overridden_bytes = overridden_package
        .to_apkg_bytes()
        .expect("overridden package bytes");

    assert_eq!(deck_bytes, base_bytes);
    assert_eq!(base_bytes, overridden_bytes);

    let base_build = base_package
        .build(unique_artifacts_dir("deck-export-base-build"))
        .expect("base build");
    let overridden_build = overridden_package
        .build(unique_artifacts_dir("deck-export-overridden-build"))
        .expect("overridden build");
    assert_eq!(
        base_build.package_build_result().apkg_ref.as_deref(),
        Some("artifacts/spanish-v1/package.apkg")
    );
    assert_eq!(
        base_build.package_build_result().staging_ref.as_deref(),
        Some("artifacts/spanish-v1/staging/manifest.json")
    );
    assert_eq!(
        overridden_build.package_build_result().apkg_ref.as_deref(),
        Some("artifacts/package-v1/package.apkg")
    );
    assert_eq!(
        overridden_build
            .package_build_result()
            .staging_ref
            .as_deref(),
        Some("artifacts/package-v1/staging/manifest.json")
    );

    let mut written = Vec::new();
    overridden_package
        .write_to(&mut written)
        .expect("write package bytes");
    assert_eq!(written, overridden_bytes);

    let write_path = unique_artifacts_dir("deck-export-write-apkg").join("export.apkg");
    overridden_package
        .write_apkg(&write_path)
        .expect("write apkg to path");
    assert_eq!(
        std::fs::read(&write_path).expect("read written apkg"),
        overridden_bytes
    );
}

#[test]
fn deck_export_rejects_invalid_deserialized_deck_during_bytes_export() {
    let deck: Deck = serde_json::from_value(json!({
        "name": "Spanish",
        "stable_id": null,
        "notes": [
            {
                "Basic": {
                    "id": "",
                    "stable_id": "   ",
                    "front": "hola",
                    "back": "hello",
                    "tags": [],
                    "generated": false
                }
            }
        ],
        "next_generated_note_id": 1,
        "media": {}
    }))
    .expect("deserialize invalid deck");

    let err = deck
        .to_apkg_bytes()
        .expect_err("invalid deck should fail export");
    assert!(
        err.to_string().contains("DECK.BLANK_STABLE_ID"),
        "unexpected error: {err:#}"
    );

    let mut written = Vec::new();
    let err = deck
        .write_to(&mut written)
        .expect_err("invalid deck should fail writer export");
    assert!(
        err.to_string().contains("DECK.BLANK_STABLE_ID"),
        "unexpected error: {err:#}"
    );
    assert!(written.is_empty());
}

#[test]
fn deck_build_reports_invalid_deserialized_deck_validation() {
    let deck: Deck = serde_json::from_value(json!({
        "name": "Spanish",
        "stable_id": null,
        "notes": [
            {
                "Basic": {
                    "id": "",
                    "stable_id": "   ",
                    "front": "hola",
                    "back": "hello",
                    "tags": [],
                    "generated": false
                }
            }
        ],
        "next_generated_note_id": 1,
        "media": {}
    }))
    .expect("deserialize invalid deck");

    let err = deck
        .build(
            BuildOptions::new()
                .output(unique_artifacts_dir("deck-invalid-build").join("deck.apkg")),
        )
        .expect_err("invalid deck should fail build facade");

    assert!(err
        .report
        .diagnostic_codes()
        .iter()
        .any(|code| code == "DECK.BLANK_STABLE_ID"));
}

#[test]
fn package_single_with_stable_id_keeps_root_deck_and_changes_export_identity() {
    let mut deck = Deck::builder("Spanish").stable_id("spanish-v1").build();
    deck.basic()
        .note("hola", "hello")
        .stable_id("es-hola")
        .add()
        .expect("add basic note");

    let package = Package::single(deck.clone()).with_stable_id("package-v1");

    assert_eq!(package.root_deck().stable_id(), Some("spanish-v1"));
    assert_eq!(
        deck.to_apkg_bytes().expect("deck bytes"),
        Package::single(deck.clone())
            .to_apkg_bytes()
            .expect("base package bytes")
    );
    assert_eq!(
        Package::single(deck.clone())
            .to_apkg_bytes()
            .expect("base package bytes"),
        package.to_apkg_bytes().expect("override package bytes")
    );
}

fn unique_artifacts_dir(label: &str) -> std::path::PathBuf {
    let mut dir = std::env::temp_dir();
    let nonce = format!(
        "anki-forge-{label}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("clock")
            .as_nanos()
    );
    dir.push(nonce);
    std::fs::create_dir_all(&dir).expect("create artifacts dir");
    dir
}
