use std::path::PathBuf;

pub mod build_cmd;
pub mod compat_oracle;
pub mod diff_cmd;
pub mod fixtures;
pub mod gates;
pub mod inspect_cmd;
pub mod manifest;
pub mod normalize_cmd;
pub mod package;
pub mod policies;
pub mod product_build_cmd;
pub mod registry;
pub mod schema;
pub mod semantics;
pub mod summary;
pub mod versioning;

pub fn contract_manifest_path() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../contracts/manifest.yaml")
}
