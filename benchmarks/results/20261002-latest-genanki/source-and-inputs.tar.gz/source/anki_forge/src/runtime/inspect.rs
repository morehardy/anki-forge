use std::path::Path;

use crate::writer_core::{inspect_apkg, inspect_staging, InspectReport};

pub fn inspect_staging_path(path: impl AsRef<Path>) -> anyhow::Result<InspectReport> {
    inspect_staging(path)
}

pub fn inspect_apkg_path(path: impl AsRef<Path>) -> anyhow::Result<InspectReport> {
    Ok(inspect_apkg(path)?)
}
