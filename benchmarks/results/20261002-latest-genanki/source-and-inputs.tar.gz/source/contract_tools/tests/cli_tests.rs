use ankiforge::tools::build_context_ref;
use serde_json::Value;
use std::{
    fs,
    path::{Path, PathBuf},
    process::Command,
    sync::atomic::{AtomicU64, Ordering},
};
use tempfile::tempdir;

fn cargo_bin() -> &'static str {
    env!("CARGO_BIN_EXE_contract_tools")
}

fn run_cli(args: &[&str]) -> std::process::Output {
    Command::new(cargo_bin())
        .args(args)
        .output()
        .expect("contract_tools binary should run")
}

#[test]
fn contract_manifest_path_points_to_contracts_manifest() {
    let manifest = contract_tools::contract_manifest_path();

    assert!(manifest.ends_with("contracts/manifest.yaml"));
    assert!(
        manifest.exists(),
        "manifest exists at {}",
        manifest.display()
    );
}

fn basic_normalized_ir() -> Value {
    let blake3 = "ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f";
    serde_json::json!({
        "kind": "normalized-ir",
        "schema_version": "0.1.0",
        "document_id": "demo-doc",
        "resolved_identity": "document:demo-doc",
        "notetypes": [
            {
                "id": "basic-main",
                "kind": "normal",
                "name": "Basic",
                "original_stock_kind": "basic",
                "fields": [
                    { "name": "Front", "ord": 0, "prevent_deletion": false },
                    { "name": "Back", "ord": 1, "prevent_deletion": false }
                ],
                "templates": [
                    {
                        "name": "Card 1",
                        "ord": 0,
                        "question_format": "{{Front}}",
                        "answer_format": "{{FrontSide}}\n\n<hr id=answer>\n\n{{Back}}"
                    }
                ],
                "css": ""
            }
        ],
        "notes": [
            {
                "id": "note-1",
                "notetype_id": "basic-main",
                "deck_name": "Default",
                "fields": {
                    "Front": "front",
                    "Back": "back <img src=\"sample.jpg\">"
                },
                "tags": ["demo"]
            }
        ],
        "media_objects": [
            {
                "id": format!("obj:blake3:{blake3}"),
                "object_ref": format!("media://blake3/{blake3}"),
                "blake3": blake3,
                "sha1": "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d",
                "size_bytes": 5,
                "mime": "image/jpeg"
            }
        ],
        "media_bindings": [
            {
                "id": "media:sample.jpg",
                "object_id": format!("obj:blake3:{blake3}"),
                "export_filename": "sample.jpg"
            }
        ],
        "media_references": [
            {
                "owner_kind": "note",
                "owner_id": "note-1",
                "location_kind": "field",
                "location_name": "Back",
                "raw_ref": "sample.jpg",
                "ref_kind": "html_src",
                "media_id": "media:sample.jpg",
                "resolution_status": "resolved"
            }
        ]
    })
}

fn write_basic_normalized_ir(temp_dir: &std::path::Path) -> std::path::PathBuf {
    let blake3 = "ea8f163db38682925e4491c5e58d4bb3506ef8c14eb78a86e908c5624a67200f";
    let object_dir = temp_dir
        .join(".anki-forge-media/objects/blake3")
        .join(&blake3[0..2])
        .join(&blake3[2..4]);
    fs::create_dir_all(&object_dir).expect("create temp media object store");
    fs::write(object_dir.join(blake3), b"hello").expect("write temp media object");

    let input = temp_dir.join("basic-normalized-ir.json");
    fs::write(
        &input,
        serde_json::to_string_pretty(&basic_normalized_ir()).unwrap(),
    )
    .expect("write normalized ir fixture");
    input
}

fn load_declared_build_context_ref() -> String {
    let manifest =
        contract_tools::manifest::load_manifest(contract_tools::contract_manifest_path())
            .expect("repo manifest should load");
    let context_path =
        contract_tools::manifest::resolve_asset_path(&manifest, "build_context_default")
            .expect("build context asset should resolve");
    let raw = fs::read_to_string(context_path).expect("read build context asset");
    let context: ankiforge::tools::BuildContext =
        serde_yaml::from_str(&raw).expect("decode build context asset");
    build_context_ref(&context).expect("build context ref")
}

fn load_declared_writer_policy_ref() -> String {
    let manifest =
        contract_tools::manifest::load_manifest(contract_tools::contract_manifest_path())
            .expect("repo manifest should load");
    let policy_path = contract_tools::manifest::resolve_asset_path(&manifest, "writer_policy")
        .expect("writer policy asset should resolve");
    let raw = fs::read_to_string(policy_path).expect("read writer policy asset");
    let policy: ankiforge::tools::WriterPolicy =
        serde_yaml::from_str(&raw).expect("decode writer policy asset");
    ankiforge::tools::policy_ref(&policy.id, &policy.version)
}

fn build_basic_package(
    temp_dir: &std::path::Path,
) -> (Value, std::path::PathBuf, std::path::PathBuf) {
    let manifest = contract_tools::contract_manifest_path();
    let input = write_basic_normalized_ir(temp_dir);
    let artifacts_dir = temp_dir.join("artifacts");
    let output = run_cli(&[
        "build",
        "--manifest",
        manifest.to_str().unwrap(),
        "--input",
        input.to_str().unwrap(),
        "--writer-policy",
        "default",
        "--build-context",
        "default",
        "--artifacts-dir",
        artifacts_dir.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);

    assert!(
        output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let build_result: Value = serde_json::from_slice(&output.stdout).expect("build JSON");
    (
        build_result,
        artifacts_dir.join("staging/manifest.json"),
        artifacts_dir.join("package.apkg"),
    )
}

fn build_basic_package_with_default_selectors(
    temp_dir: &std::path::Path,
) -> (Value, std::path::PathBuf, std::path::PathBuf) {
    let manifest = contract_tools::contract_manifest_path();
    let input = write_basic_normalized_ir(temp_dir);
    let artifacts_dir = temp_dir.join("artifacts-defaults");
    let output = run_cli(&[
        "build",
        "--manifest",
        manifest.to_str().unwrap(),
        "--input",
        input.to_str().unwrap(),
        "--artifacts-dir",
        artifacts_dir.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);

    assert!(
        output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let build_result: Value = serde_json::from_slice(&output.stdout).expect("build JSON");
    (
        build_result,
        artifacts_dir.join("staging/manifest.json"),
        artifacts_dir.join("package.apkg"),
    )
}

#[test]
fn verify_command_succeeds_for_the_repo_contract_bundle() {
    let manifest_path = copied_bundled_manifest_path("cli-verify");
    let output = run_cli(&["verify", "--manifest", manifest_path.to_str().unwrap()]);

    assert!(
        output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        String::from_utf8_lossy(&output.stdout).contains("verification passed"),
        "stdout: {}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[test]
fn verify_command_fails_when_manifest_is_missing() {
    let output = run_cli(&["verify", "--manifest", "contracts/missing.yaml"]);

    assert!(
        !output.status.success(),
        "expected failure but command succeeded"
    );
}

#[test]
fn summary_command_prints_bundle_version_and_public_axis() {
    let manifest =
        contract_tools::manifest::load_manifest(contract_tools::contract_manifest_path())
            .expect("repo manifest should load");
    let output = run_cli(&["summary", "--manifest", manifest.path.to_str().unwrap()]);

    assert!(
        output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains(&format!("bundle_version: {}", manifest.data.bundle_version)),
        "stdout: {stdout}"
    );
    assert!(
        stdout.contains("public_axis: bundle_version"),
        "stdout: {stdout}"
    );
    assert!(stdout.contains("component_versions:"), "stdout: {stdout}");
    assert!(stdout.contains("authoring_protocol: phase2-v1"));
    assert!(stdout.contains("writer_protocol: phase3-v1"));
    assert!(stdout.contains(&load_declared_writer_policy_ref()));
    assert!(stdout.contains(&load_declared_build_context_ref()));

    for (name, asset) in &manifest.data.assets {
        let entry = format!("  {name}: {asset}");
        assert!(stdout.contains(&entry), "stdout: {stdout}");
    }
}

#[test]
fn normalize_contract_json_includes_required_top_level_fields() {
    let manifest =
        contract_tools::manifest::load_manifest(contract_tools::contract_manifest_path())
            .expect("repo manifest should load");
    let input = manifest
        .contracts_root
        .join("fixtures/valid/minimal-authoring-ir.json");

    let output = run_cli(&[
        "normalize",
        "--manifest",
        manifest.path.to_str().unwrap(),
        "--input",
        input.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);

    assert!(
        output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    let value: Value = serde_json::from_str(&stdout).expect("stdout should be valid JSON");
    let object = value.as_object().expect("stdout should be a JSON object");

    for key in [
        "kind",
        "result_status",
        "tool_contract_version",
        "policy_refs",
        "comparison_context",
        "diagnostics",
    ] {
        assert!(object.contains_key(key), "missing key {key} in {stdout}");
    }
}

#[test]
fn normalize_command_rejects_invalid_authoring_input_shape() {
    let manifest =
        contract_tools::manifest::load_manifest(contract_tools::contract_manifest_path())
            .expect("repo manifest should load");
    let temp = tempdir().expect("tempdir");
    let input = temp.path().join("invalid-authoring.json");
    fs::write(
        &input,
        r#"{"kind":"authoring-ir","schema_version":"0.1.0","metadata":{"document_id":"doc-bad"}}"#,
    )
    .expect("write invalid input");

    let output = run_cli(&[
        "normalize",
        "--manifest",
        manifest.path.to_str().unwrap(),
        "--input",
        input.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);

    assert!(
        !output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn normalize_command_matches_anki_forge_runtime_output() {
    let manifest = contract_tools::contract_manifest_path();
    let repo_root = manifest.parent().unwrap().parent().unwrap();
    let input = repo_root.join("contracts/fixtures/valid/minimal-authoring-ir.json");

    let runtime = ankiforge::tools::load_runtime(&manifest).unwrap();
    let runtime_result = ankiforge::tools::normalize_from_path(&runtime, &input).unwrap();

    let cli_output = run_cli(&[
        "normalize",
        "--manifest",
        manifest.to_str().unwrap(),
        "--input",
        input.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);

    assert!(cli_output.status.success());
    let cli_json: serde_json::Value = serde_json::from_slice(&cli_output.stdout).unwrap();
    let runtime_json = serde_json::to_value(runtime_result).unwrap();
    assert_eq!(cli_json, runtime_json);
}

#[test]
fn build_command_emits_contract_json_with_manifest_backed_refs() {
    let temp = tempdir().expect("tempdir");
    let (build_result, staging_manifest, apkg_path) = build_basic_package(temp.path());

    assert_eq!(build_result["kind"], "package-build-result");
    assert_eq!(build_result["result_status"], "success");
    assert_eq!(
        build_result["writer_policy_ref"],
        load_declared_writer_policy_ref()
    );
    assert_eq!(
        build_result["build_context_ref"],
        load_declared_build_context_ref()
    );
    assert_eq!(
        build_result["staging_ref"],
        "artifacts/staging/manifest.json"
    );
    assert_eq!(build_result["apkg_ref"], "artifacts/package.apkg");
    assert!(build_result["artifact_fingerprint"]
        .as_str()
        .expect("artifact fingerprint")
        .starts_with("artifact:"));
    assert!(build_result["package_fingerprint"]
        .as_str()
        .expect("package fingerprint")
        .starts_with("package:"));
    assert!(staging_manifest.exists(), "staging manifest should exist");
    assert!(apkg_path.exists(), "apkg should exist");
}

#[test]
fn build_command_defaults_writer_policy_and_build_context() {
    let temp = tempdir().expect("tempdir");
    let (build_result, staging_manifest, apkg_path) =
        build_basic_package_with_default_selectors(temp.path());

    assert_eq!(build_result["kind"], "package-build-result");
    assert_eq!(build_result["result_status"], "success");
    assert_eq!(
        build_result["staging_ref"],
        "artifacts/staging/manifest.json"
    );
    assert_eq!(build_result["apkg_ref"], "artifacts/package.apkg");
    assert!(build_result["writer_policy_ref"]
        .as_str()
        .unwrap()
        .starts_with("writer-policy.default@"));
    assert!(build_result["build_context_ref"]
        .as_str()
        .unwrap()
        .starts_with("build-context:"));
    assert!(staging_manifest.exists(), "staging manifest should exist");
    assert!(apkg_path.exists(), "apkg should exist");
}

#[test]
fn build_command_matches_anki_forge_runtime_output() {
    let manifest = contract_tools::contract_manifest_path();
    let repo_root = manifest.parent().unwrap().parent().unwrap();
    let build_input = repo_root.join("contracts/fixtures/phase3/inputs/basic-normalized-ir.json");
    let artifacts_dir = tempdir().unwrap();

    let runtime = ankiforge::tools::load_runtime(&manifest).unwrap();
    let runtime_result = ankiforge::tools::build_from_path(
        &runtime,
        &build_input,
        "default",
        "default",
        artifacts_dir.path(),
    )
    .unwrap();

    let cli_output = run_cli(&[
        "build",
        "--manifest",
        manifest.to_str().unwrap(),
        "--input",
        build_input.to_str().unwrap(),
        "--writer-policy",
        "default",
        "--build-context",
        "default",
        "--artifacts-dir",
        artifacts_dir.path().to_str().unwrap(),
        "--output",
        "contract-json",
    ]);

    assert!(cli_output.status.success());
    let cli_json: serde_json::Value = serde_json::from_slice(&cli_output.stdout).unwrap();
    let runtime_json = serde_json::to_value(runtime_result).unwrap();
    assert_eq!(cli_json, runtime_json);
}

#[test]
fn build_command_requires_artifacts_dir() {
    let temp = tempdir().expect("tempdir");
    let manifest = contract_tools::contract_manifest_path();
    let input = write_basic_normalized_ir(temp.path());

    let output = run_cli(&[
        "build",
        "--manifest",
        manifest.to_str().unwrap(),
        "--input",
        input.to_str().unwrap(),
        "--writer-policy",
        "default",
        "--build-context",
        "default",
        "--output",
        "contract-json",
    ]);

    assert!(
        !output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("artifacts-dir"),
        "stderr: {}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn inspect_and_diff_commands_emit_contract_json_for_real_fixture() {
    let temp = tempdir().expect("tempdir");
    let (_build_result, staging_manifest, apkg_path) = build_basic_package(temp.path());

    let staging_output = run_cli(&[
        "inspect",
        "--staging",
        staging_manifest.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);
    assert!(
        staging_output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&staging_output.stdout),
        String::from_utf8_lossy(&staging_output.stderr)
    );
    let staging_report: Value =
        serde_json::from_slice(&staging_output.stdout).expect("staging inspect JSON");
    assert_eq!(staging_report["kind"], "inspect-report");
    assert_eq!(staging_report["source_kind"], "staging");
    assert_eq!(staging_report["observation_status"], "complete");
    assert!(staging_report["observations"]["field_metadata"].is_array());
    assert!(staging_report["observations"]["browser_templates"].is_array());
    assert!(staging_report["observations"]["template_target_decks"].is_array());

    let apkg_output = run_cli(&[
        "inspect",
        "--apkg",
        apkg_path.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);
    assert!(
        apkg_output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&apkg_output.stdout),
        String::from_utf8_lossy(&apkg_output.stderr)
    );
    let apkg_report: Value =
        serde_json::from_slice(&apkg_output.stdout).expect("apkg inspect JSON");
    assert_eq!(apkg_report["kind"], "inspect-report");
    assert_eq!(apkg_report["source_kind"], "apkg");
    assert_eq!(apkg_report["observation_status"], "complete");
    assert!(apkg_report["observations"]["field_metadata"].is_array());
    assert!(apkg_report["observations"]["browser_templates"].is_array());
    assert!(apkg_report["observations"]["template_target_decks"].is_array());

    let left = temp.path().join("left.inspect.json");
    let right = temp.path().join("right.inspect.json");
    fs::write(
        &left,
        serde_json::to_string_pretty(&staging_report).unwrap(),
    )
    .unwrap();
    fs::write(&right, serde_json::to_string_pretty(&apkg_report).unwrap()).unwrap();

    let diff_output = run_cli(&[
        "diff",
        "--left",
        left.to_str().unwrap(),
        "--right",
        right.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);
    assert!(
        diff_output.status.success(),
        "stdout: {}\nstderr: {}",
        String::from_utf8_lossy(&diff_output.stdout),
        String::from_utf8_lossy(&diff_output.stderr)
    );
    let diff_report: Value = serde_json::from_slice(&diff_output.stdout).expect("diff JSON");
    assert_eq!(diff_report["kind"], "diff-report");
    assert_eq!(diff_report["comparison_status"], "complete");
    assert_eq!(diff_report["changes"], serde_json::json!([]));
}

#[test]
fn inspect_resource_limits_reach_cli_and_tool_operations() {
    use std::io::Write;
    let root = tempdir().unwrap();
    let apkg = root.path().join("meta-bomb.apkg");
    let mut archive = zip::ZipWriter::new(fs::File::create(&apkg).unwrap());
    archive
        .start_file(
            "meta",
            zip::write::SimpleFileOptions::default()
                .compression_method(zip::CompressionMethod::Deflated),
        )
        .unwrap();
    archive.write_all(&[8, 3, 18, 128, 128, 4]).unwrap();
    archive.write_all(&vec![0; 65_536]).unwrap();
    archive.finish().unwrap();
    let direct: ankiforge::tools::InspectError = ankiforge::tools::inspect_apkg(&apkg).unwrap_err();
    assert!(direct.limit_exceeded().is_some());
    let runtime = ankiforge::tools::inspect_apkg_path(&apkg).unwrap_err();
    assert!(runtime
        .to_string()
        .contains("INSPECT.RESOURCE_LIMIT_EXCEEDED"));
    let output = run_cli(&[
        "inspect",
        "--apkg",
        apkg.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);
    assert!(!output.status.success());
    assert!(
        output.stdout.is_empty(),
        "no successful partial report on limit errors"
    );
    assert!(String::from_utf8_lossy(&output.stderr).contains("INSPECT.RESOURCE_LIMIT_EXCEEDED"));
}

#[test]
fn inspect_cleans_temporary_collection_on_success_and_sqlite_failure() {
    use std::io::Write;
    let root = tempdir().unwrap();
    let baseline = build_basic_stock_baseline(root.path());
    let scratch = root.path().join("inspect-tmp");
    fs::create_dir(&scratch).unwrap();
    for valid in [true, false] {
        if !valid {
            let mut archive = zip::ZipWriter::new(fs::File::create(&baseline).unwrap());
            archive
                .start_file(
                    "collection.anki21b",
                    zip::write::SimpleFileOptions::default(),
                )
                .unwrap();
            archive
                .write_all(&zstd::stream::encode_all(&b"not a database"[..], 0).unwrap())
                .unwrap();
            archive.finish().unwrap();
        }
        let output = Command::new(cargo_bin())
            .args([
                "inspect",
                "--apkg",
                baseline.to_str().unwrap(),
                "--output",
                "contract-json",
            ])
            .env("TMPDIR", &scratch)
            .env("TMP", &scratch)
            .env("TEMP", &scratch)
            .output()
            .unwrap();
        assert_eq!(
            output.status.success(),
            valid,
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        assert_eq!(fs::read_dir(&scratch).unwrap().count(), 0);
    }
}

#[test]
fn inspect_and_diff_commands_match_anki_forge_runtime_output() {
    let manifest = contract_tools::contract_manifest_path();
    let repo_root = manifest.parent().unwrap().parent().unwrap();
    let build_input = repo_root.join("contracts/fixtures/phase3/inputs/basic-normalized-ir.json");
    let artifacts_dir = tempdir().unwrap();

    let runtime = ankiforge::tools::load_runtime(&manifest).unwrap();
    let _build_result = ankiforge::tools::build_from_path(
        &runtime,
        &build_input,
        "default",
        "default",
        artifacts_dir.path(),
    )
    .unwrap();

    let staging_path = artifacts_dir.path().join("staging/manifest.json");
    let apkg_path = artifacts_dir.path().join("package.apkg");

    let runtime_staging = ankiforge::tools::inspect_staging_path(&staging_path).unwrap();
    let runtime_apkg = ankiforge::tools::inspect_apkg_path(&apkg_path).unwrap();

    let cli_staging = run_cli(&[
        "inspect",
        "--staging",
        staging_path.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);
    assert!(cli_staging.status.success());
    let cli_staging_json: serde_json::Value = serde_json::from_slice(&cli_staging.stdout).unwrap();
    assert_eq!(
        cli_staging_json,
        serde_json::to_value(&runtime_staging).unwrap()
    );

    let cli_apkg = run_cli(&[
        "inspect",
        "--apkg",
        apkg_path.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);
    assert!(cli_apkg.status.success());
    let cli_apkg_json: serde_json::Value = serde_json::from_slice(&cli_apkg.stdout).unwrap();
    assert_eq!(cli_apkg_json, serde_json::to_value(&runtime_apkg).unwrap());

    let left = artifacts_dir.path().join("left.inspect.json");
    let right = artifacts_dir.path().join("right.inspect.json");
    fs::write(
        &left,
        serde_json::to_string_pretty(&runtime_staging).unwrap(),
    )
    .unwrap();
    fs::write(&right, serde_json::to_string_pretty(&runtime_apkg).unwrap()).unwrap();

    let runtime_diff = ankiforge::tools::diff_from_paths(&left, &right).unwrap();
    let cli_diff = run_cli(&[
        "diff",
        "--left",
        left.to_str().unwrap(),
        "--right",
        right.to_str().unwrap(),
        "--output",
        "contract-json",
    ]);
    assert!(cli_diff.status.success());
    let cli_diff_json: serde_json::Value = serde_json::from_slice(&cli_diff.stdout).unwrap();
    assert_eq!(cli_diff_json, serde_json::to_value(runtime_diff).unwrap());
}

fn temp_contract_root(label: &str) -> PathBuf {
    static NEXT_TEMP_ROOT_ID: AtomicU64 = AtomicU64::new(0);
    let unique = NEXT_TEMP_ROOT_ID.fetch_add(1, Ordering::Relaxed);
    std::env::temp_dir().join(format!(
        "anki-forge-cli-tests-{}-{}-{}",
        label,
        std::process::id(),
        unique
    ))
}

fn copy_tree(src: &Path, dst: &Path) {
    fs::create_dir_all(dst).expect("create destination tree");
    for entry in fs::read_dir(src).expect("read source tree") {
        let entry = entry.expect("read source entry");
        let src_path = entry.path();
        let dst_path = dst.join(entry.file_name());
        if src_path.is_dir() {
            copy_tree(&src_path, &dst_path);
        } else {
            fs::copy(&src_path, &dst_path).expect("copy source file");
        }
    }
}

fn copied_bundled_manifest_path(label: &str) -> PathBuf {
    let root = temp_contract_root(label);
    copy_tree(
        contract_tools::contract_manifest_path()
            .parent()
            .expect("contracts root for bundled manifest"),
        &root,
    );

    let artifacts_root = root.join("artifacts");
    if artifacts_root.exists() {
        fs::remove_dir_all(&artifacts_root).expect("remove generated artifact tree");
    }

    root.join("manifest.yaml")
}

fn build_basic_stock_baseline(root: &Path) -> PathBuf {
    let mut project = ankiforge::Project::new("inspect-tests").unwrap();
    project
        .add("one", ankiforge::Note::basic("front", "back"))
        .unwrap();
    let path = root.join("baseline.apkg");
    project.build(ankiforge::BuildOptions::to(&path)).unwrap();
    path
}
