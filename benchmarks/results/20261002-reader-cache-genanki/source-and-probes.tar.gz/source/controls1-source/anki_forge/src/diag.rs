use std::{collections::BTreeMap,sync::{Mutex,OnceLock},time::Instant};
static STATS: OnceLock<Mutex<BTreeMap<&'static str,(u64,u128)>>> = OnceLock::new();
pub struct Scope(&'static str,Instant);
impl Scope {pub fn new(label:&'static str)->Self{Self(label,Instant::now())}}
impl Drop for Scope {fn drop(&mut self){let ns=self.1.elapsed().as_nanos();let mut s=STATS.get_or_init(Default::default).lock().unwrap();let v=s.entry(self.0).or_default();v.0+=1;v.1+=ns;}}
pub fn count(label:&'static str,n:u64){let mut s=STATS.get_or_init(Default::default).lock().unwrap();s.entry(label).or_default().0+=n;}
pub fn snapshot_budget()->usize{static B:OnceLock<usize>=OnceLock::new();*B.get_or_init(||std::env::var("ANKIFORGE_DIAG_SNAPSHOT_BUDGET").ok().and_then(|s|s.parse().ok()).unwrap_or(4*1024*1024))}
pub fn finish(){let s=STATS.get_or_init(Default::default).lock().unwrap();eprintln!("[DEBUG-residual-20261002] {}",serde_json::to_string(&*s).unwrap());}
