use crate::writer_core::{BuildContext, WriterPolicy};

pub(crate) fn load_embedded_writer_defaults() -> anyhow::Result<(WriterPolicy, BuildContext)> {
 let _diagnostic_scope=crate::diag::Scope::new("runtime.defaults");
    super::embedded::load_writer_defaults()
}
