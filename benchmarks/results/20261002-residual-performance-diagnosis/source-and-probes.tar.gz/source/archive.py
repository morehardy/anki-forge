from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
W=Path(__file__).resolve().parent;R=W.parents[2];O=R/'benchmarks/results/20261002-residual-performance-diagnosis'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=['baseline-plan.json','baseline-results.json','baseline-summary.json','baseline.log','control-plan.json','control-results.json','control-summary.json','control.log','detail-plan.json','detail-results.json','detail-summary.json','detail.log','source-before.json','source-after.json','identity-check.json','runtime-match.json','build-historical.json','build-probe.json','build-detail.json','source.patch','probe.patch','detail.patch','audit.py','audit.json']
for name in files:shutil.copy2(W/name,O/name)
shutil.copy2(R/'benchmarks/results/20261002-optimized-genanki/host-hardware.json',O/'host-hardware.json')
manifest={}
def archive(name,entries):
 hashes={}
 with tarfile.open(O/name,'w:gz') as tar:
  for path,arc in entries:
   assert path.is_file() and arc not in hashes
   hashes[arc]=sha(path);tar.add(path,arcname=arc,recursive=False)
 with tarfile.open(O/name) as tar:
  members=tar.getmembers();assert len(members)==len(hashes)
  for m in members:assert m.isfile() and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==hashes[m.name]
 manifest[name]={'sha256':sha(O/name),'members':hashes,'member_count':len(hashes),'verified':True}
raw=[]
for stem in ('baseline','control','detail'):
 for case in sorted(W.glob(stem+'-*')):
  if case.is_dir():
   for p in sorted(case.rglob('*')):
    if p.is_file():assert p.suffix not in ('.apkg','.anki2');raw.append((p,'raw/'+str(p.relative_to(W))))
for name in files:raw.append((W/name,'raw/'+name))
archive('measurements-and-validation.tar.gz',raw)
sources=[]
for folder in ('probe-source','detail-source'):
 for p in sorted((W/folder).rglob('*')):
  if p.is_file():sources.append((p,'source/'+str(p.relative_to(W))))
for name in ('baseline.py','setup_probe.py','build_probe.py','controls.py','setup_detail.py','build_detail.py','detail.py','freeze.py','report.py','archive.py','build-probe.log','build-detail.log','probe.patch','detail.patch','source.patch'):
 sources.append((W/name,'source/'+name))
# Historical source and its exact earlier build hash are retained for independent rebuilding.
H=R/'benchmarks/.work/diagnosis-20261002'
for p in sorted((H/'historical-source').rglob('*')):
 if p.is_file():sources.append((p,'source/historical-source/'+str(p.relative_to(H/'historical-source'))))
for name in ('build-historical.json','historical-source-check.json'):
 sources.append((H/name,'source/'+name))
# Exact fixture descriptions; binary media data remains in the referenced frozen full benchmark archive/workspace.
for profile in json.loads((W/'control-plan.json').read_text())['profiles']:
 p=R/'benchmarks/.work/optimized-20261002/fixtures'/profile/'inputs/1000.json';sources.append((p,'source/inputs/'+profile+'/1000.json'))
archive('source-and-probes.tar.gz',sources)
(O/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:dict(member_count=v['member_count'],verified=v['verified'],bytes=(O/k).stat().st_size) for k,v in manifest.items()}))
