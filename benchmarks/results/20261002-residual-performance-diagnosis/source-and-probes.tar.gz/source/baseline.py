"""Same-session reproduction on immutable optimized and historical binaries."""
from pathlib import Path
import json,os,subprocess,sys,statistics
W=Path(__file__).resolve().parent;R=W.parents[2]
sys.path.insert(0,str(R/'benchmarks'))
import bench,verify
frozen=json.loads((R/'benchmarks/results/20261002-optimized-genanki/source-snapshot.json').read_text())
current=bench.identity_snapshot(bench.registry())
relevant=lambda p:p.startswith(('anki_forge/','contract_tools/','benchmarks/adapters/','benchmarks/native/')) or p in ('Cargo.toml','Cargo.lock','rust-toolchain.toml')
changed={p: {'frozen':v,'current':current['source_files'].get(p)} for p,v in frozen['source_files'].items() if relevant(p) and current['source_files'].get(p)!=v}
assert not changed,changed
assert current['executables']==frozen['executables']
bench.save(W/'source-before.json',current)
bench.save(W/'runtime-match.json',{'optimized_archive':'20261002-optimized-genanki','runtime_sources_match':True,'executables_match':True,'matched_source_files':sum(relevant(p) for p in frozen['source_files'])})
import shutil
shutil.copy2(R/'benchmarks/adapters/rust/target/release/anki-forge-benchmark',W/'binaries/official-optimized')
old=R/'benchmarks/.work/diagnosis-20261002'
record=json.loads((old/'build-historical.json').read_text());assert bench.sha256(old/'binaries/historical')==record['binary_sha256']
assert all(bench.sha256(old/'historical-source'/p)==sha for p,sha in record['source_files'].items())
shutil.copy2(old/'binaries/historical',W/'binaries/historical')
shutil.copy2(old/'build-historical.json',W/'build-historical.json')
profiles=['basic-mixed-text-v1','basic-image-unique-v2']
rows=[]
bench.save(W/'baseline-plan.json',dict(profiles=profiles,notes=1000,warmup_repeats=1,timing_repeats=5,expected_exports=24,versions={'optimized':bench.sha256(W/'binaries/official-optimized'),'historical':bench.sha256(W/'binaries/historical')},historical_instrumented=True,current_instrumented=False,source_commit=bench.command(['git','rev-parse','HEAD'])))
def power(): return subprocess.check_output(['pmset','-g','batt'],text=True).strip()
for role,repeats in [('warmup',1),('timing',5)]:
 for repeat in range(repeats):
  for profile in profiles:
   for mode in (['optimized','historical'] if repeat%2==0 else ['historical','optimized']):
    case=W/f'baseline-{role}-{repeat}-{profile}-{mode}';case.mkdir()
    inp=R/'benchmarks/.work/optimized-20261002/fixtures'/profile/'inputs/1000.json'
    doc=json.loads(inp.read_text());out=case/'output.apkg'
    before=power();assert before.splitlines()[0]=="Now drawing from 'AC Power'"
    binary=W/'binaries'/('official-optimized' if mode=='optimized' else 'historical')
    env=dict(os.environ,TMPDIR=str(case),TMP=str(case),TEMP=str(case))
    p=subprocess.run([str(bench.COLLECTOR),'60',str(case/'stdout.log'),str(case/'stderr.log'),str(binary),str(inp),str(out)],capture_output=True,text=True,check=True,env=env)
    after=power();assert after.splitlines()[0]==before.splitlines()[0]
    m=json.loads(p.stdout);bench.save(case/'measurement.json',m);assert m['exit_code']==0 and not m['signal'] and not m['leftover_descendants']
    checked=verify.verify_artifact(out,doc,bench.INSPECTOR);bench.save(case/'verification.json',checked);assert checked['status']=='passed'
    if role=='timing' and repeat==0:
     with (case/'oracle.stdout.log').open('w') as stdout,(case/'oracle.stderr.log').open('w') as stderr:
      subprocess.run([str(bench.ORACLE),str(inp),str(out),str(case/'anki.json')],check=True,stdout=stdout,stderr=stderr,timeout=120)
     assert json.loads((case/'anki.json').read_text())['status']=='passed'
    row=dict(role=role,repeat=repeat,profile=profile,mode=mode,elapsed_ms=m['elapsed_ns']/1e6,rss_mib=m['peak_rss_bytes']/2**20,logical_sha256=checked['physical']['logical_sha256'],power_before=before,power_after=after)
    rows.append(row);bench.save(W/'baseline-results.json',{'status':'running','rows':rows});print(json.dumps({k:row[k] for k in ('role','repeat','profile','mode','elapsed_ms')}),flush=True);out.unlink()
assert len(rows)==24
for p in profiles: assert len({r['logical_sha256'] for r in rows if r['profile']==p})==1
bench.save(W/'baseline-results.json',{'status':'completed','rows':rows})
summary={p:{m:statistics.median(r['elapsed_ms'] for r in rows if r['profile']==p and r['mode']==m and r['role']=='timing') for m in ['optimized','historical']} for p in profiles}
bench.save(W/'baseline-summary.json',summary);print(json.dumps(summary),flush=True)
