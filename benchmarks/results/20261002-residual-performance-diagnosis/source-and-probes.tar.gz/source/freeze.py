from pathlib import Path
import sys,json,subprocess,datetime
W=Path(__file__).resolve().parent;R=W.parents[2];sys.path.insert(0,str(R/'benchmarks'));import bench
before=json.loads((W/'source-before.json').read_text());after=bench.identity_snapshot(bench.registry());bench.save(W/'source-after.json',after)
assert before==after,'Source/dependency/input/executable identity changed'
for stem,source,binary in [('probe','probe-source','probe'),('detail','detail-source','detail')]:
 b=json.loads((W/f'build-{stem}.json').read_text());assert bench.sha256(W/'binaries'/binary)==b['binary_sha256'];assert all(bench.sha256(W/source/p)==v for p,v in b['source_files'].items())
bench.save(W/'identity-check.json',dict(unchanged=True,source_files=len(before['source_files']),upstream_revision=before['upstream_revision'],official_binary_sha256=bench.sha256(W/'binaries/official-optimized'),restored_active_binary=True,head=bench.command(['git','rev-parse','HEAD']),start_utc=datetime.datetime.fromtimestamp((W/'baseline-plan.json').stat().st_mtime,datetime.timezone.utc).isoformat(),end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),power=subprocess.check_output(['pmset','-g','batt'],text=True).strip(),uptime=subprocess.check_output(['uptime'],text=True).strip(),system=subprocess.check_output(['sw_vers'],text=True).strip()))
with (W/'source.patch').open('w') as f:subprocess.run(['git','diff','--binary','HEAD'],stdout=f,check=True)
print('All production sources, inputs, executables, dependencies and both private source copies unchanged')
