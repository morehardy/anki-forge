use std::{collections::BTreeMap, sync::{Mutex,OnceLock},time::Instant};
static STATS: OnceLock<Mutex<BTreeMap<&'static str,(u64,u128)>>> = OnceLock::new();
pub struct Scope(&'static str,Instant);
impl Scope { pub fn new(label: &'static str)->Self { Self(label,Instant::now()) } }
impl Drop for Scope { fn drop(&mut self) { let ns=self.1.elapsed().as_nanos();let mut stats=STATS.get_or_init(Default::default).lock().unwrap();let value=stats.entry(self.0).or_default();value.0+=1;value.1+=ns; } }
pub fn finish(){let stats=STATS.get_or_init(Default::default).lock().unwrap();eprintln!("[DEBUG-perf-20261002] {}",serde_json::to_string(&*stats).unwrap());}
