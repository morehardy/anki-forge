from pathlib import Path
import json,datetime
W=Path(__file__).resolve().parent;R=W.parents[2];O=R/'benchmarks/results/20261002-residual-performance-diagnosis';O.mkdir(exist_ok=False)
control=json.loads((W/'control-summary.json').read_text());detail=json.loads((W/'detail-summary.json').read_text());ident=json.loads((W/'identity-check.json').read_text())
labels=['文本','独立图片','独立音频','独立混合媒体','共享混合媒体']
def f(n):return f'{n:.3f}'
def stage(c,k):return c['stages'].get(k,{'ms':0})['ms']
lines=['# 优化后的剩余性能损耗诊断','',
'主要损耗来自 **4 MiB 全局快照预算溢出后，每个媒体对象各建一个临时文件**。1,000 张独立图片有 935 个快照落盘；导入和退出清理合计约 247 ms。相同探针仅把预算提高到 128 MiB，整次进程耗时从 414.679 ms 降到 244.814 ms（−41.0%），同时 RSS 从 43.27 MiB 增到 102.05 MiB。音频和混合媒体也出现同方向的大幅下降。','',
'当前最有价值的下一步是保留有界内存和独立快照所有权，用分块共享 spool 减少临时文件数量。提高预算是因果对照，不能直接视为兼顾内存的生产方案。身份检查和同步仍有固定成本，但量级较小；媒体并行处理本身有明确收益。','',
'## 运行边界与复现','',
f'测量及冻结区间：2026-10-02 18:13:54–18:25:19 Asia/Taipei。当前 HEAD `{ident["head"]}`；这期间所有 2,110 个登记源码、输入、依赖、工具身份完全一致。与 [优化后完整 benchmark](../20261002-optimized-genanki/report.md) 相比，253 个相关运行时源码和全部工具二进制一致；HEAD 的差异来自 README/网站品牌提交。官方优化版 exporter SHA-256 为 `{ident["official_binary_sha256"]}`。','',
'同一 M1 Pro / 32 GiB / macOS 27.0 主机，所有进程前后均检查 AC Power。结束时系统 load averages 为 14.97 / 15.73 / 15.80；桌面背景负载、缓存和充电状态没有隔离。每格 1 次预热 + 5 次计时，使用原生进程计时器，一次只运行一个 exporter；矩阵每轮以预先保存的种子随机排列。RSS 是这次计时进程的 OS 高水位，属于诊断指标，与正式 benchmark 的独立 RSS 采样协议不同。','',
'先交错复测旧版和当前未插桩版：1,000 条文本 53.969 → 70.255 ms，1,000 张图片 257.175 → 454.790 ms。旧版是上一轮已核验来源的历史 Deck 探针，含粗粒度计时；当前是官方未插桩 Project 二进制。因此它支持剩余差距的复现，不能用差值直接估算单个新特性的净成本。','',
'本轮控制矩阵中的官方未插桩结果见下表。它和先行复测的差异说明会话内也有波动，几个毫秒的控制结果不足以作稳定收益承诺。','',
'| 1,000 条场景 | 官方版 ms | 默认探针 ms | 全部默认样本 ms |','|---|---:|---:|---|']
for name,c in zip(labels,control):lines.append(f'| {name} | {f(c["official"]["median_ms"])} | {f(c["default"]["median_ms"])} | '+', '.join(f(x) for x in c['default']['samples_ms'])+' |')
lines+=['','所有原始样本和预热都保留。插桩版/官方版时间中位数差约 −3.0% 至 +3.8%，没有采用选择性删除或替换采样。','',
'## 1. 快照临时文件是独立媒体的主要成本','',
'生产路径在 `media/snapshot.rs:131` 的 `spill_memory()` 中创建、写入并关闭独立 NamedTempFile；reader 在 `:232` 重开文件，最后一个 Media/Project 所有者释放时清理 TempPath。Probe 控制只改变全局快照驻留预算，单对象 1 MiB 阈值、快照内容哈希、压缩、检查、输出同步完全保留。','',
'| 场景 | 默认溢出文件数 | 默认导入 ms | 默认清理 ms | 128 MiB 导入 ms | 128 MiB 清理 ms |','|---|---:|---:|---:|---:|---:|']
for name,c in zip(labels,control):
 a=c['default'];b=c['snapshot_memory'];lines.append(f'| {name} | {a["stages"].get("snapshot.spilled_files",{}).get("count",0)} | {f(stage(a,"adapter.assets"))} | {f(stage(a,"adapter.cleanup"))} | {f(stage(b,"adapter.assets"))} | {f(stage(b,"adapter.cleanup"))} |')
lines+=['','| 场景 | 默认 4 MiB / ms | 强制全落盘 / ms | 128 MiB / ms | 默认 RSS / MiB | 128 MiB RSS / MiB |','|---|---:|---:|---:|---:|---:|']
for name,c in zip(labels,control):lines.append(f'| {name} | {f(c["default"]["median_ms"])} | {f(c["snapshot_disk"]["median_ms"])} | {f(c["snapshot_memory"]["median_ms"])} | {c["default"]["rss_mib"]:.2f} | {c["snapshot_memory"]["rss_mib"]:.2f} |')
lines+=['',
'图片默认快照溢出阶段自身为 86.295 ms；清理为 67.113 ms。全部驻留内存后，媒体准备 wall time 也从 49.160 降到 37.787 ms。导入、清理和准备阶段的方向一致，支持文件创建/写入/关闭/重开/删除链路是主要损耗，而不只是 codec 耗时。清理阶段包含所有对象释放，不能把每一个纳秒都归为 unlink。','',
'独立音频整体 −37.3%，独立混合媒体 −38.4%。共享媒体只有 49 个资产，默认没有溢出，提高预算没有改变该路径；87.735 对 77.544 ms 的反向差异属于保留的无效控制/环境波动。文本同样没有媒体；其预算对照基本不变。','',
'下一步应试验分块共享 spool/区段 reader：减少文件个数，并保持全局内存上限、独立不可变快照、最后所有者清理、失败后所有权、fork 行为、低文件描述符使用和哈希检查。不能仅提高预算就宣称兼顾内存；图片 102 MiB 已超过现有 64 MiB 验收目标。','',
'## 2. 完整检查和身份校验是次要固定成本','',
'默认探针的包检查如下；完整检查包含媒体解码/哈希、identity 验证和 collection 读取，列之间存在包含关系。','',
'| 场景 | 完整 native inspect ms | 其中媒体读取 ms | 其中 identity validate ms | 其中 collection 读取 ms |','|---|---:|---:|---:|---:|']
for name,c in zip(labels,control):a=c['default'];lines.append('| '+name+' | '+' | '.join(f(stage(a,k)) for k in ['inspect.native','inspect.media','identity.validate','inspect.collection'])+' |')
lines+=['',
'单独细分探针保持校验行为与字节序列相同；仅把 identity checksum 的原 helper 原样内联以分别计时 Value 构建、排序和序列化。得到：','',
'| 身份相关阶段 | 文本 ms | 独立图片 ms | 次数/含义 |','|---|---:|---:|---|']
keys=[('identity.validate','identity.validate 总计','1；检查阶段'),('identity.media_history','媒体历史与名称检查','1；包含在 validate 中'),('identity.validate_note_mapping','note 身份映射检查','1；包含在 validate 中'),('identity.validate_note_rows','SQLite note/card 内容检查','1；包含在 validate 中'),('identity.checksum','identity checksum 总计','2；生成和验证'),('identity.checksum_to_value','其中 serde_json::to_value','2；包含在 checksum 中'),('identity.checksum_sort','其中递归键排序','2；包含在 checksum 中'),('identity.checksum_serialize','其中 JSON 序列化','2；包含在 checksum 中'),('identity.file_hash','collection 文件哈希','2；生成和验证'),('inspect.identity_parse','读取/解析 identity JSON','1；检查阶段')]
for k,name,n in keys:lines.append(f'| {name} | {f(stage(detail[0]["default"],k))} | {f(stage(detail[1]["default"],k))} | {n} |')
lines+=['',
'图片比文本多约 6.3 ms 的媒体历史检查，代码在 `identity/validation.rs:46` 中遍历历史与活动名称，执行 validate_name、NFC/Unicode case-fold 身份键、BTreeSet 去重及历史比对。阶段测量定位了该函数；尚未进一步隔离键生成与树比较各自的占比。可评估复用规范化键/共享遍历，但不能取消历史一致性或 portable filename 冲突检查。','',
'文本的 note/card 行检查约 4.23 ms。生成侧另有 identity.bind 约 2.66 ms、identity.envelope 约 2.58 ms。完整 native inspect 约 12.5 ms，而本次历史文本 summary 约 5.06 ms；检查范围不同，这支持额外身份工作是文本剩余差距的一部分，不代表旧版语义与新接口等价。','',
'JSON 不是主因：两次 checksum 合计约 2.2–3.1 ms，排序几乎为零。不能依据 `sort_all_objects()` 的源码外观优先重写键排序。可在保持 canonical 字节和完整证据的前提下评估减少 Value/String 中间分配，以及复用已解码的 model/note 事实；收益上限需要新的单变量对照。','',
'## 3. 媒体并行有效；重复同步收益不稳定','',
'| 场景 | 默认整体 ms | 单 worker 整体 ms | 默认媒体准备 ms | 单 worker 媒体准备 ms | 跳过首次候选同步整体 ms |','|---|---:|---:|---:|---:|---:|']
for name,c in zip(labels,control):lines.append(f'| {name} | {f(c["default"]["median_ms"])} | {f(c["serial_media"]["median_ms"])} | {f(stage(c["default"],"media.prepare_all"))} | {f(stage(c["serial_media"],"media.prepare_all"))} | {f(c["skip_retain_sync"]["median_ms"])} |')
lines+=['',
'图片的 prepare_all 从 49.160 增到 173.575 ms；音频从 29.098 增到 90.903 ms。共享媒体也从 1.769 增到 5.333 ms。该证据否定“直接取消媒体线程会提速”的假设。文本没有媒体，serial flag 的小幅差异是负控制波动。线程数/队列的其他设计尚未测试。','',
'默认文件同步两次：`build_api/artifact.rs:146` 的候选接管同步，和 `:209` 的最终发布文件同步，再在 `:233` 同步目标目录。三个阶段中位数合计，文本约 18.3 ms、图片约 22.8 ms。跳过首次候选同步仍保留最终文件/目录同步；文本后两步从约 8.7 增到 13.2 ms，图片文件同步从 3.9 增到 10.6 ms。同步成本会转移，整体矩阵结果包括图片变慢，不能承诺省去一个 sync_all 就节省其原阶段全部耗时。','',
'此开关只在私有探针中存在。临时产物、最终发布持久性和失败事实受到 ADR-0023 约束；下一步若合并同步，需要先说明候选交付及失败语义并复测。','',
'## 诊断证据和下一步顺序','',
'1. 优先试验有界共享/分块快照 spool，目标是压低 870–935 个独立临时文件带来的导入及清理成本。','2. 再复用 portable media identity/检查事实，减少媒体历史遍历和重复解码，同时保留完整原始包验证。','3. 最后评估候选发布同步合并、canonical JSON 分配；此次数据不支持将 JSON 排序或线程移除作为首要优化。','',
'本次是检查结果，未新增生产代码修改。原有优化工作树保留，官方 exporter 已恢复；所有 debug 计时和开关位于忽略的 `.work/residual-20261002` 私有源码副本。','',
'216 次导出全部通过原始 SQLite、字段/card/deck、媒体、语义检查；36 个选定真实输出通过固定上游 Anki import/content/render 检查。所有版本/控制每个 profile 的学习内容 digest 一致。每个 warmup 也校验，没有以无媒体、缩短检查或改变数据来获取正向结果。离线 audit 已从原始记录重算全部中位数、RSS、阶段时间及计数。','',
'详见 [证据索引](README.md)、[单变量汇总](control-summary.json)、[身份细分](detail-summary.json)、[审计结果](audit.json)。阶段时间是 inclusive wall time；单独取中位数不能精确相加还原整体。prepare_one 在多个 worker 上重叠，其累计耗时不能加到端到端耗时。','']
(O/'report.md').write_text('\n'.join(lines))
print(O)
