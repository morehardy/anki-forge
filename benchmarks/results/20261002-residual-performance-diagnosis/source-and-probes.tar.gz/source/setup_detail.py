from pathlib import Path
import shutil,re,subprocess
W=Path(__file__).resolve().parent;S=W/'detail-source';shutil.copytree(W/'probe-source',S)
def scope(file,function,label):
 p=S/'anki_forge/src'/file;s=p.read_text();m=list(re.finditer(r'\bfn '+function+r'\s*(?:<[^\n]*>)?\s*\(',s));assert len(m)==1,(file,function);a=s.index('{',m[0].end())+1;p.write_text(s[:a]+f'\n let _detail_scope=crate::diag::Scope::new("{label}");'+s[a:])
for args in [('build_api/identity.rs','identity_checksum','identity.checksum'),('build_api/identity.rs','file_hash','identity.file_hash'),('build_api/identity.rs','digest','identity.key_digest'),('build_api/identity/content.rs','hash','identity.content_hash'),('build_api/identity/content.rs','model_from_collection','identity.model_content'),('build_api/identity/validation.rs','validate_media_history','identity.media_history')]:scope(*args)
p=S/'anki_forge/src/build_api/identity.rs';s=p.read_text();old='    let json = crate::writer_core::canonical_json::to_canonical_json(identity)?;';assert s.count(old)==1
s=s.replace(old,'''    let mut value = {let _s=crate::diag::Scope::new("identity.checksum_to_value");serde_json::to_value(identity)?};
    {let _s=crate::diag::Scope::new("identity.checksum_sort");value.sort_all_objects();}
    let json = {let _s=crate::diag::Scope::new("identity.checksum_serialize");serde_json::to_string(&value)?};''')
p.write_text(s)
p=S/'anki_forge/src/build_api/identity/validation.rs';s=p.read_text().replace('        let mut model_ids =','        let _model_scope=crate::diag::Scope::new("identity.validate_models");\n        let mut model_ids =',1).replace('        let count: usize = db.query_row("SELECT COUNT(*) FROM notes"','        drop(_model_scope);\n        let count: usize = db.query_row("SELECT COUNT(*) FROM notes"',1).replace('        let mut guids =','        let _mapping_scope=crate::diag::Scope::new("identity.validate_note_mapping");\n        let mut guids =',1).replace('        let mut content =','        drop(_mapping_scope);\n        let _rows_scope=crate::diag::Scope::new("identity.validate_note_rows");\n        let mut content =',1);p.write_text(s)
p=S/'anki_forge/src/writer_core/inspect.rs';s=p.read_text().replace('    let identity: Option<crate::build::identity::IdentityEnvelope> = if require_identity {','    let _parse_scope=crate::diag::Scope::new("inspect.identity_parse");\n    let identity: Option<crate::build::identity::IdentityEnvelope> = if require_identity {',1).replace('    let (version, mut limitations) = read_package_version(&mut archive)?;','    drop(_parse_scope);\n    let (version, mut limitations) = read_package_version(&mut archive)?;',1);p.write_text(s)
subprocess.run(['diff','-ru',str(W/'probe-source'),str(S)],stdout=(W/'detail.patch').open('w'),check=False)
build=(W/'build_probe.py').read_text().replace('probe-source','detail-source').replace("binaries/probe'","binaries/detail'").replace('build-probe','build-detail');(W/'build_detail.py').write_text(build)
control=(W/'controls.py').read_text();a=control.index('profiles=');b=control.index('def power()');control=control[:a]+"profiles=['basic-mixed-text-v1','basic-image-unique-v2']\nmodes={'default':{}}\n"+control[b:]
control=control.replace('control-','detail-').replace('expected_exports=180','expected_exports=12').replace('expected_anki_checks=30','expected_anki_checks=2').replace('==180','==12').replace('==30','==2').replace("'probe'","'detail'")
(W/'detail.py').write_text(control)
