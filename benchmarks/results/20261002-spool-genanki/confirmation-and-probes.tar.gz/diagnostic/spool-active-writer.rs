//! Bounded spill blocks shared only by their live immutable snapshot segments.
use std::{
    fs::File,
    io::{self, Read, Seek, SeekFrom, Write},
    sync::{Arc, Mutex, Weak},
};

const BLOCK_BYTES: u64 = 4 * 1024 * 1024;

#[derive(Default)]
pub(super) struct Pool {
    current: Weak<Block>,
    length: u64,
}

#[derive(Debug)]
struct Block {
    writer: Mutex<Option<File>>,
    path: Option<tempfile::TempPath>,
    process: u32,
}

impl Block {
    fn path(&self) -> &std::path::Path {
        self.path.as_deref().expect("live spill block owns a path")
    }
}

impl Drop for Block {
    fn drop(&mut self) {
        // Arc counts are copied at fork. A child must never unlink parent storage.
        if self.process != std::process::id() {
            if let Some(path) = self.path.take() {
                std::mem::forget(path);
            }
        }
    }
}

#[derive(Debug)]
pub(super) struct Segment {
    block: Arc<Block>,
    offset: u64,
    length: u64,
}

impl Pool {
    // The process-local snapshot cache serializes append operations. No file
    // strong storage owner remains in the cache between calls. Only the active
    // block owns a write descriptor; completed blocks reopen readers on demand.
    pub(super) fn store(&mut self, bytes: &[u8]) -> io::Result<Segment> {
        let previous = self.current.upgrade();
        let (block, offset) = match previous {
            Some(block) if self.length + bytes.len() as u64 <= BLOCK_BYTES => (block, self.length),
            previous => {
                // A failed replacement must not leave a closed writer reusable.
                self.current = Weak::new();
                self.length = 0;
                if let Some(block) = previous {
                    // Completed blocks keep no descriptors, even with many live segments.
                    block
                        .writer
                        .lock()
                        .unwrap_or_else(|e| e.into_inner())
                        .take();
                }
                let (file, path) = tempfile::NamedTempFile::new()?.into_parts();
                (
                    Arc::new(Block {
                        writer: Mutex::new(Some(file)),
                        path: Some(path),
                        process: std::process::id(),
                    }),
                    0,
                )
            }
        };
        let mut writer = block.writer.lock().unwrap_or_else(|e| e.into_inner());
        // Readers open independent descriptors, so only serialized appends move
        // this writer's cursor. At most the active block retains a writer.
        let file = writer.as_mut().expect("active spill block has a writer");
        if let Err(error) = file.write_all(bytes) {
            let _ = file.set_len(offset);
            writer.take();
            self.current = Weak::new();
            self.length = 0;
            return Err(error);
        }
        drop(writer);
        self.length = offset + bytes.len() as u64;
        self.current = Arc::downgrade(&block);
        Ok(Segment {
            block,
            offset,
            length: bytes.len() as u64,
        })
    }
}

impl Segment {
    pub(super) fn reader(&self) -> io::Result<Reader> {
        let mut file = File::open(self.block.path())?;
        file.seek(SeekFrom::Start(self.offset))?;
        Ok(Reader {
            file,
            offset: self.offset,
            length: self.length,
            position: 0,
        })
    }
}

pub(super) struct Reader {
    file: File,
    offset: u64,
    length: u64,
    position: u64,
}

impl Read for Reader {
    fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
        let limit = self
            .length
            .saturating_sub(self.position)
            .min(bytes.len() as u64) as usize;
        let count = self.file.read(&mut bytes[..limit])?;
        self.position += count as u64;
        Ok(count)
    }
}

impl Seek for Reader {
    fn seek(&mut self, from: SeekFrom) -> io::Result<u64> {
        let position = match from {
            SeekFrom::Start(position) => i128::from(position),
            SeekFrom::Current(delta) => i128::from(self.position) + i128::from(delta),
            SeekFrom::End(delta) => i128::from(self.length) + i128::from(delta),
        };
        let invalid =
            || io::Error::new(io::ErrorKind::InvalidInput, "invalid snapshot segment seek");
        let position = u64::try_from(position).map_err(|_| invalid())?;
        let absolute = self.offset.checked_add(position).ok_or_else(invalid)?;
        self.file.seek(SeekFrom::Start(absolute))?;
        self.position = position;
        Ok(position)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn readers_are_independent_and_cannot_cross_segment_boundaries() {
        let mut pool = Pool::default();
        let first = pool.store(b"first").unwrap();
        let second = pool.store(b"second").unwrap();
        assert!(Arc::ptr_eq(&first.block, &second.block));
        let path = first.block.path().to_owned();
        let mut a = first.reader().unwrap();
        let mut b = second.reader().unwrap();
        assert_eq!(a.seek(SeekFrom::End(-2)).unwrap(), 3);
        let mut bytes = Vec::new();
        a.read_to_end(&mut bytes).unwrap();
        assert_eq!(bytes, b"st");
        assert_eq!(a.seek(SeekFrom::Current(-5)).unwrap(), 0);
        bytes.clear();
        a.read_to_end(&mut bytes).unwrap();
        assert_eq!(bytes, b"first");
        assert_eq!(b.seek(SeekFrom::End(-3)).unwrap(), 3);
        bytes.clear();
        b.read_to_end(&mut bytes).unwrap();
        assert_eq!(bytes, b"ond");
        assert!(b.seek(SeekFrom::Start(20)).is_ok());
        assert_eq!(b.read(&mut [0; 10]).unwrap(), 0);
        assert!(b.seek(SeekFrom::End(-7)).is_err());
        drop((a, b, first));
        assert!(path.exists(), "another segment still owns the shared block");
        drop(second);
        assert!(!path.exists(), "weak pool must not retain dead storage");
    }

    #[test]
    fn full_blocks_rotate_and_each_block_has_its_own_cleanup_owner() {
        let mut pool = Pool::default();
        let first = pool.store(&vec![1; BLOCK_BYTES as usize]).unwrap();
        let second = pool.store(b"next block").unwrap();
        assert!(!Arc::ptr_eq(&first.block, &second.block));
        assert!(first.block.writer.lock().unwrap().is_none());
        assert!(second.block.writer.lock().unwrap().is_some());
        let first_path = first.block.path().to_owned();
        let second_path = second.block.path().to_owned();
        drop(first);
        assert!(!first_path.exists());
        assert!(second_path.exists());
        drop(second);
        assert!(!second_path.exists());
        let fresh = pool.store(b"fresh").unwrap();
        assert_eq!(fresh.offset, 0, "expired weak block must start a new file");
    }

    #[test]
    fn inherited_block_cleanup_preserves_parent_path() {
        let file = tempfile::NamedTempFile::new().unwrap();
        let path = file.path().to_owned();
        drop(Block {
            writer: Mutex::new(None),
            path: Some(file.into_temp_path()),
            process: std::process::id().wrapping_add(1),
        });
        assert!(path.exists());
        std::fs::remove_file(path).unwrap();
    }
}
