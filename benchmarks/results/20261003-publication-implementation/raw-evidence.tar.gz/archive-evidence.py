from pathlib import Path
import hashlib,json,tarfile
R=Path.cwd();W=R/'tmp/publication-performance';D=R/'benchmarks/results/20261003-publication-implementation';D.mkdir(exist_ok=True)
raw=[]
for p in W.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.txt','.py','.sh','.md','.yaml','.diff']:
  raw.append((p,p.name))
 if p.is_dir() and ('-batch' in p.name or p.name.startswith('smoke-') or p.name in ['harness-v1','harness-v2','harness-v3','rss-diagnosis','live-diagnosis','node-before-source','node-cow-source','anki-roundtrip']):
  for f in p.rglob('*'):
   if f.is_file():raw.append((f,str(f.relative_to(W))))
B=R/'tmp/publication-implementation-baseline'
for name in ['source-sha256.json','worktree.patch','head.txt','status.txt','Cargo.lock','prerequisite-files.json','prerequisite-commit.txt']:
 p=B/name
 if p.exists():raw.append((p,'implementation-baseline/'+name))
def archive(name,files):
 inventory={relative:hashlib.sha256(p.read_bytes()).hexdigest() for p,relative in files}
 (D/(name+'.manifest.json')).write_text(json.dumps(inventory,indent=2)+'\n')
 with tarfile.open(D/(name+'.tar.gz'),'w:gz') as output:
  for p,relative in sorted(files,key=lambda x:x[1]):output.add(p,arcname=relative,recursive=False)
archive('raw-evidence',raw)
inputs=[];baselines=[]
for folder in ['fixtures','sdk-fixtures','standard-fixtures']:
 for p in (W/folder).rglob('*'):
  if not p.is_file():continue
  relative=str(p.relative_to(W))
  if p.suffix=='.apkg':baselines.append((p,relative))
  elif p.name=='input.json' or p.parent.name!='media':inputs.append((p,relative))
archive('fixture-inputs',inputs)
archive('baseline-packages',baselines)
print(json.dumps({p.name:p.stat().st_size for p in D.glob('*.tar.gz')},indent=2))
