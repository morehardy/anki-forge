from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,time
R=Path.cwd();W=R/'tmp/publication-performance';S=W/'variant-source'
core={}
with tarfile.open(R/'tmp/publication-implementation-baseline/source.tar.gz') as archive:
 for member in archive:
  if member.name.startswith('anki_forge/') and member.isfile():core[member.name]=archive.extractfile(member).read()
records=[]
for variant in ['baseline','manifest','media']:
 shutil.rmtree(S/'anki_forge')
 for name,data in core.items():
  p=S/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 names=[]
 if variant=='manifest':names=['writer_core/staging.rs','writer_core/build.rs','build_api/candidate.rs']
 if variant=='media':names=['media/snapshot.rs']
 for name in names:shutil.copy2(R/'anki_forge/src'/name,S/'anki_forge/src'/name)
 for name in ['Cargo.toml','Cargo.lock','src/main.rs','src/control.rs']:
  shutil.copy2(R/'benchmarks/adapters/rust'/name,S/'benchmarks/adapters/rust'/name)
 argv=['cargo','build','--release','--locked','--offline','--manifest-path',str(S/'benchmarks/adapters/rust/Cargo.toml'),'--features','controls','--bin','publication-control']
 inventory={str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for base in [S/'anki_forge',S/'benchmarks/adapters/rust'] for p in base.rglob('*') if p.is_file() and 'target' not in p.parts}
 (W/f'{variant}-control-source.json').write_text(json.dumps(inventory,indent=2)+'\n')
 with (W/f'{variant}-control-build.log').open('w') as log:
  subprocess.run(argv,env={**os.environ,'CARGO_TARGET_DIR':str(R/'benchmarks/adapters/rust/target')},stdout=log,stderr=subprocess.STDOUT,check=True)
 destination=W/'binaries'/f'{variant}-control'
 shutil.copy2(R/'benchmarks/adapters/rust/target/release/publication-control',destination)
 records.append({'variant':variant,'argv':argv,'binary_sha256':hashlib.sha256(destination.read_bytes()).hexdigest()})
 (W/'control-builds.json').write_text(json.dumps(records,indent=2)+'\n')
