from pathlib import Path
import subprocess
root=Path.cwd()
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
manifest={'anki_forge/src/build_api/candidate.rs','anki_forge/src/writer_core/build.rs','anki_forge/src/writer_core/staging.rs'}
media={'anki_forge/src/media/snapshot.rs','anki_forge/tests/consumers/media_snapshot_lifecycle.rs','anki_forge/tests/media_snapshot_lifecycle_tests.rs'}
cow=['bindings/node/native/src/lib.rs','bindings/node/native/src/artifact.rs','bindings/node/native/src/prepared.rs']
paths=subprocess.check_output(['git','ls-files','-m','-o','--exclude-standard','-z']).decode().split('\0')
selected=sorted({p for p in paths if p and p not in manifest|media and (p.startswith(('anki_forge/','bindings/','contracts/','docs/adr/','docs/rfcs/')) or p in ['scripts/check_rust_crate_payload.sh','scripts/packaged_consumer/src/main.rs','docs/superpowers/specs/2026-10-03-publication-performance-spec.md'])})
subprocess.run(['git','add','-A','--',*selected],check=True)
for name in cow:
 source=(root/name).read_text()
 before=source.replace('Option<std::sync::Arc<ankiforge::Project>>','Option<ankiforge::Project>').replace('Option<std::sync::Arc<Project>>','Option<Project>')
 if name.endswith('/lib.rs'):
  before=before.replace('inner: std::sync::Arc<Project>','inner: Project').replace('inner: std::sync::Arc::new(inner)','inner')
  start=before.index('        // The core builder consumes a value.')
  end=before.index('\n    }',start)
  before=before[:start]+'        self.inner = self.inner.clone().default_deck(name)'+before[end:]
  before=before.replace('std::sync::Arc::make_mut(&mut self.inner)','self.inner')
 assert before!=source,name
 oid=subprocess.check_output(['git','hash-object','-w','--stdin'],input=before.encode()).decode().strip()
 subprocess.run(['git','update-index','--cacheinfo','100644',oid,name],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','feat(publication): prepare inspect and publish a single owned candidate'],check=True)
for paths,message in [(cow,'perf(node): share immutable project snapshots with copy on write'),(sorted(manifest),'perf(writer): omit unused native staging manifest materialization'),(sorted(media),'perf(media): reuse live large byte snapshots before temporary writes')]:
 subprocess.run(['git','add','--',*paths],check=True)
 subprocess.run(['git','diff','--cached','--check'],check=True)
 subprocess.run(['git','commit','-m',message],check=True)
(root/'tmp/publication-performance/implementation-commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
