from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
R=Path.cwd(); W=R/'tmp/publication-performance'; S=W/'rss-source'; S.mkdir(exist_ok=True)
with tarfile.open(R/'tmp/publication-implementation-baseline/source.tar.gz') as archive:
 for member in archive:
  if member.name.startswith(('anki_forge/','benchmarks/adapters/rust/')): archive.extract(member,S,filter='data')
(S/'Cargo.toml').write_text('[workspace]\nmembers = ["anki_forge"]\nresolver = "2"\n[workspace.package]\nedition = "2021"\nrust-version = "1.92"\n[workspace.lints.rust]\nunsafe_code = "allow"\n')
core={str(p.relative_to(S)):p.read_bytes() for p in (S/'anki_forge').rglob('*') if p.is_file()}
probe='''\n#[allow(dead_code)]
pub(crate) fn publication_rss_probe(stage: &str) {
    unsafe extern "C" { fn getrusage(who: i32, usage: *mut i64) -> i32; }
    let mut usage = [0_i64; 32];
    if unsafe { getrusage(0, usage.as_mut_ptr()) } == 0 {
        eprintln!("[DEBUG-publication-rss] {} {}", stage, usage[4]);
    }
}
'''
for variant in ['baseline','combined']:
 shutil.rmtree(S/'anki_forge')
 for name,data in core.items():
  p=S/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 if variant=='combined':
  for name in ['build_api/mod.rs','build_api/pipeline.rs','build_api/prepared.rs','build_api/candidate.rs','writer_core/staging.rs','writer_core/build.rs','media/snapshot.rs']:
   shutil.copy2(R/'anki_forge/src'/name,S/'anki_forge/src'/name)
 p=S/'anki_forge/Cargo.toml';p.write_text(p.read_text().replace('unsafe_code = "forbid"','unsafe_code = "allow"'))
 p=S/'anki_forge/src/lib.rs';p.write_text(p.read_text()+probe)
 for name,marks in {
  'build_api/pipeline.rs':[
   ('        let baseline = match &options.mode {','baseline-start'),
   ('        let baseline_counts = baseline.as_ref().map','baseline-end'),
   ('        let identity = super::identity::PackageIdentity::prepare(','identity-start'),
   ('        let notes = self','notes-start'),
   ('        let (candidate, mut report) =','candidate-start'),
   ('        let (inspected, envelope) =','inspection-start'),
   ('        if inspected.observation_status','inspection-end')],
  'build_api/candidate.rs':[
   ('    let mut normalized =','normalize-start'),
   ('    let mut report = BuildReport {','normalize-end'),
   ('    let cards = identity.bound_card_count','identity-bind-end'),
   ('    let attempt = crate::writer_core::build','writer-start'),
   ('    let result = attempt.result;','writer-end')],
  'writer_core/build.rs':[
   ('    let materialized = match package','manifest-start'),
   ('    let apkg = if build_context.emit_apkg','apkg-start'),
   ('    let mut result = success_result','apkg-end')],
 }.items():
  p=S/'anki_forge/src'/name;s=p.read_text()
  for needle,tag in marks:
   if needle not in s:print('unmatched',variant,name,tag)
   else:s=s.replace(needle,f'    crate::publication_rss_probe("{tag}");\n'+needle,1)
  p.write_text(s)
 for name in ['Cargo.toml','main.rs']:
  shutil.copy2(W/'harness-v1'/name,S/'benchmarks/adapters/rust'/('src/main.rs' if name=='main.rs' else name))
 command=['cargo','build','--release','--locked','--offline','--manifest-path',str(S/'benchmarks/adapters/rust/Cargo.toml')]
 if variant=='combined':command+=['--features','prepared-publication']
 with (W/f'rss-{variant}-build.log').open('w') as log:
  subprocess.run(command,env={**os.environ,'CARGO_TARGET_DIR':str(R/'benchmarks/adapters/rust/target')},stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copy2(R/'benchmarks/adapters/rust/target/release/anki-forge-benchmark',W/f'rss-{variant}')
 (W/f'rss-{variant}-source.json').write_text(json.dumps({str(p.relative_to(S)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (S/'anki_forge/src').rglob('*.rs')},indent=2))
