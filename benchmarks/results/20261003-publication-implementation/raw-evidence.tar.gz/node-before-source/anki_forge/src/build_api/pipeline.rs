use std::{collections::BTreeMap, error::Error, time::Instant};

use super::{BuildError, BuildErrorKind as Kind, BuildOptions, BuildOutput, OutputTarget};
use crate::{
    product::model::{
        ProductCustomNoteTypeV2, ProductCustomNoteV2, ProductDocument, ProductDocumentV2Payload,
        ProductFieldContentV2, ProductFieldV2, ProductGenerationRuleV2, ProductMediaSourceV2,
        ProductMediaV2, ProductNoteTypeV2, ProductNoteV2, ProductTemplateV2,
    },
    schema::GenerationRule,
    Project,
};

impl Project {
    /// Builds and inspects an APKG using the explicit output request. Successful
    /// output always owns an artifact; a report alone never represents success.
    pub fn build(&self, options: BuildOptions) -> Result<BuildOutput, BuildError> {
        let started = Instant::now();
        let mut result = self
            .prepare_publication(options)
            .and_then(super::PreparedPublication::publish);
        let elapsed = started.elapsed();
        match &mut result {
            Ok(output) => output.report.duration = elapsed,
            Err(error) => error.report.duration = elapsed,
        }
        result
    }

    /// Generates and fully inspects a private candidate for one later publication.
    /// Policy-blocked comparisons remain readable; `publish` enforces the policy.
    pub fn prepare_publication(
        &self,
        options: BuildOptions,
    ) -> Result<super::PreparedPublication, BuildError> {
        super::PreparedPublication::prepare(self, options)
    }

    pub(crate) fn prepare_candidate(
        &self,
        options: &BuildOptions,
    ) -> Result<(super::artifact::PrivateCandidate, super::BuildReport), BuildError> {
        let started = Instant::now();
        let mut result = self.prepare_candidate_inner(options);
        let elapsed = started.elapsed();
        match &mut result {
            Ok((_, report)) => report.duration = elapsed,
            Err(error) => error.report.duration = elapsed,
        }
        result
    }

    fn prepare_candidate_inner(
        &self,
        options: &BuildOptions,
    ) -> Result<(super::artifact::PrivateCandidate, super::BuildReport), BuildError> {
        crate::project::validate_deck(&self.default_deck).map_err(|cause| {
            BuildError::new(Kind::Configuration, cause.code(), "invalid default deck")
                .caused_by(cause)
        })?;
        if matches!(&options.output, OutputTarget::Persistent(path) if path.as_os_str().is_empty())
        {
            return Err(BuildError::new(
                Kind::Configuration,
                "BUILD.OUTPUT_INVALID",
                "output path cannot be empty",
            ));
        }
        if matches!(options.mode, super::BuildMode::Create) && options.update_policy.is_some() {
            return Err(BuildError::new(
                Kind::Configuration,
                "BUILD.UPDATE_POLICY_WITHOUT_BASELINE",
                "an explicit update policy requires update_from",
            ));
        }
        let baseline = match &options.mode {
            super::BuildMode::Create => None,
            super::BuildMode::Update(path) => {
                if path.as_os_str().is_empty() {
                    return Err(BuildError::new(
                        Kind::Configuration,
                        "BUILD.BASELINE_INVALID",
                        "baseline path cannot be empty",
                    ));
                }
                if let OutputTarget::Persistent(output) = &options.output {
                    let aliases_baseline =
                        crate::path_alias::paths_alias(output, path).map_err(|cause| {
                            BuildError::new(
                                Kind::Configuration,
                                "BUILD.OUTPUT_INVALID",
                                "could not distinguish output from update baseline",
                            )
                            .caused_by(cause)
                        })?;
                    if aliases_baseline {
                        return Err(BuildError::new(
                            Kind::Configuration,
                            "BUILD.OUTPUT_INVALID",
                            "output must not replace the original update baseline; choose a separate destination",
                        ));
                    }
                }
                let (summary, envelope) = crate::writer_core::inspect::inspect_native_package(
                    path,
                    &options.inspect_limits,
                )
                .map_err(|cause| inspection_error(cause, "inspect baseline APKG"))?;
                if summary.observation_status != "complete" {
                    return Err(BuildError::new(
                        Kind::Validation,
                        "UPDATE.BASELINE_INCOMPLETE",
                        "required baseline inspection was incomplete",
                    ));
                }
                Some((summary, envelope))
            }
        };
        let baseline_counts = baseline.as_ref().map(|(summary, _)| super::BuildCounts {
            notes: summary.notes,
            cards: summary.cards,
            media: summary.media,
        });
        match self.prepare_from_baseline(options, baseline) {
            Ok((candidate, mut report)) => {
                report.baseline_counts = baseline_counts;
                Ok((candidate, report))
            }
            Err(mut error) => {
                error.report.baseline_counts = baseline_counts;
                Err(error)
            }
        }
    }

    fn prepare_from_baseline(
        &self,
        options: &BuildOptions,
        baseline: Option<(
            crate::writer_core::inspect::ApkgInspectSummary,
            super::identity::IdentityEnvelope,
        )>,
    ) -> Result<(super::artifact::PrivateCandidate, super::BuildReport), BuildError> {
        let identity = super::identity::PackageIdentity::prepare(
            self,
            baseline.as_ref().map(|(_, envelope)| &envelope.identity),
        )?;
        let inputs = tempfile::Builder::new()
            .prefix("ankiforge-input-")
            .tempdir()
            .map_err(|cause| {
                BuildError::new(
                    Kind::Io,
                    "BUILD.WORKSPACE_FAILED",
                    "create private build inputs",
                )
                .caused_by(cause)
            })?;
        let mut media = Vec::new();
        for asset in self.assets.values() {
            media.push(ProductMediaV2 {
                id: asset.filename().to_owned(),
                source: ProductMediaSourceV2::File {
                    path: format!("assets/{}", asset.filename()),
                },
                export_as: asset.filename().to_owned(),
                source_path: Some(format!("project.assets[{:?}]", asset.filename())),
            });
        }
        let note_types = self
            .models
            .values()
            .map(|model| {
                let fields = model
                    .fields()
                    .iter()
                    .map(|field| ProductFieldV2 {
                        name: field.display_name().into(),
                        key: field.key().as_str().into(),
                        identity: false,
                        sort: field.is_sort(),
                        required: field.is_required(),
                        source_path: None,
                    })
                    .collect();
                let bindings = model
                    .fields()
                    .iter()
                    .map(|field| (field.key().as_str(), field.display_name()))
                    .collect::<BTreeMap<_, _>>();
                let compile = |source: &str| {
                    let parsed = crate::authoring_core::parse_template(source);
                    crate::authoring_core::template_parser::rewrite_fields(
                        source, &parsed, &bindings,
                    )
                };
                let templates = model
                    .templates()
                    .iter()
                    .map(|template| ProductTemplateV2 {
                        name: template.display_name().into(),
                        key: template.key().as_str().into(),
                        front: compile(template.front_source()),
                        back: compile(template.back_source()),
                        browser_front: template.browser_front_source().map(compile),
                        browser_back: template.browser_back_source().map(compile),
                        target_deck: template.target_deck_name().map(str::to_owned),
                        source_path: None,
                        generation_rule: match template.generation_rule() {
                            GenerationRule::AnkiDefault => None,
                            GenerationRule::All(keys) => Some(ProductGenerationRuleV2::All {
                                fields: keys.iter().map(ToString::to_string).collect(),
                            }),
                            GenerationRule::Any(keys) => Some(ProductGenerationRuleV2::Any {
                                fields: keys.iter().map(ToString::to_string).collect(),
                            }),
                        },
                    })
                    .collect();
                ProductNoteTypeV2::Custom(ProductCustomNoteTypeV2 {
                    stock_kind: model.stock_kind().map(str::to_owned),
                    id: model_id(model.key()),
                    name: Some(model.display_name().into()),
                    note_type_kind: Some(
                        if model.cloze_field().is_some() {
                            "cloze"
                        } else {
                            "normal"
                        }
                        .into(),
                    ),
                    cloze_field: model.cloze_field().map(ToString::to_string),
                    fields,
                    templates,
                    identity: None,
                    css: Some(model.css().into()),
                    source_path: Some(format!("project.models[{:?}]", model.key())),
                })
            })
            .collect();
        let notes = self
            .notes
            .iter()
            .map(|(key, note)| {
                let mut fields: BTreeMap<_, _> = note
                    .fields
                    .iter()
                    .map(|(key, value)| {
                        (
                            key.to_string(),
                            ProductFieldContentV2::Html {
                                value: value.render(),
                            },
                        )
                    })
                    .collect();
                if let Some(occlusion) = &note.occlusion {
                    fields.insert(
                        "occlusion".into(),
                        ProductFieldContentV2::Html {
                            value: occlusion.render(&identity.mask_ordinals(key)),
                        },
                    );
                    fields.insert(
                        "image".into(),
                        ProductFieldContentV2::Html {
                            value: occlusion.image.image().render(),
                        },
                    );
                }
                ProductNoteV2::Custom(ProductCustomNoteV2 {
                    note_type_id: model_id(note.model.key()),
                    stable_id: Some(key.clone()),
                    deck_name: note.deck.as_ref().unwrap_or(&self.default_deck).clone(),
                    fields,
                    tags: note.tags.clone(),
                    source_path: Some(format!("project.notes[{key:?}]")),
                })
            })
            .collect();
        let document = ProductDocument::from_native_payload(
            self.namespace.clone(),
            Some(self.default_deck.clone()),
            ProductDocumentV2Payload {
                version: 3,
                note_types,
                notes,
                media,
                transport_diagnostics: Vec::new(),
            },
        );
        let (candidate, mut report) =
            super::candidate::generate(self, document, inputs.path(), identity)?;
        let (inspected, envelope) = crate::writer_core::inspect::inspect_native_package(
            candidate.path(),
            &options.inspect_limits,
        )
        .map_err(|cause| {
            let mut error = inspection_error(cause, "inspect candidate APKG");
            error.report = Box::new(report.clone());
            error
        })?;
        if inspected.observation_status != "complete" {
            let mut error = BuildError::new(
                Kind::Validation,
                "BUILD.INSPECT_INCOMPLETE",
                "required candidate inspection was incomplete",
            );
            error.report = Box::new(report);
            return Err(error);
        }
        report.counts.notes = inspected.notes;
        report.counts.cards = inspected.cards;
        report.counts.media = inspected.media;
        if let Some((summary, baseline)) = baseline {
            let comparison = crate::update::ComparisonReport::analyze(
                &baseline,
                &envelope,
                super::BuildCounts {
                    notes: summary.notes,
                    cards: summary.cards,
                    media: summary.media,
                },
                report.counts,
                &options.update_policy.clone().unwrap_or_default(),
            );
            report
                .diagnostics
                .extend(comparison.diagnostics().iter().cloned());
            report.comparison = Some(comparison);
        }
        Ok((candidate, report))
    }
}

fn model_id(key: &str) -> String {
    format!("model:{key}")
}

fn inspection_error(cause: crate::writer_core::InspectError, message: &str) -> BuildError {
    let (mut kind, mut code) = if cause.limit_exceeded().is_some() {
        (Kind::ResourceLimit, "INSPECT.RESOURCE_LIMIT_EXCEEDED")
    } else {
        (Kind::Validation, "BUILD.INSPECT_FAILED")
    };
    let mut source = cause.source();
    while let Some(error) = source {
        if let Some(evidence) = error.downcast_ref::<super::identity::EvidenceError>() {
            code = evidence.code;
        }
        if error.is::<std::io::Error>() && kind != Kind::ResourceLimit {
            kind = Kind::Io;
        }
        source = error.source();
    }
    BuildError::new(kind, code, message).caused_by(cause)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{update::CompareOptions, Note};
    use std::time::Duration;

    fn project() -> Project {
        let mut project = Project::new("failure-duration").unwrap();
        project.add("one", Note::basic("front", "back")).unwrap();
        project
    }

    #[test]
    fn baseline_inspection_failures_record_elapsed_work_for_build_and_compare() {
        let root = tempfile::tempdir().unwrap();
        let malformed = root.path().join("malformed.apkg");
        std::fs::write(&malformed, b"not a ZIP archive").unwrap();
        let project = project();
        for baseline in [root.path().join("missing.apkg"), malformed] {
            let started = Instant::now();
            let error = project
                .build(BuildOptions::temporary().update_from(&baseline))
                .unwrap_err();
            assert!(error.report().duration() > Duration::ZERO);
            assert!(error.report().duration() <= started.elapsed());
            assert!(error.publications().is_empty());
            assert_eq!(error.report().counts().notes, 0);
            assert!(error.source().is_some());

            let started = Instant::now();
            let error = project
                .compare(CompareOptions::against(&baseline))
                .unwrap_err();
            assert!(error.report().duration() > Duration::ZERO);
            assert!(error.report().duration() <= started.elapsed());
            assert!(error.source().is_some());
        }
    }

    #[test]
    fn early_configuration_errors_record_duration_without_fabricating_observations() {
        let error = project().build(BuildOptions::to("")).unwrap_err();
        assert_eq!(error.kind(), Kind::Configuration);
        assert!(error.report().duration() > Duration::ZERO);
        assert_eq!(error.report().counts().notes, 0);
        assert!(error.report().baseline_counts().is_none());
        assert!(error.publications().is_empty());
    }
}
