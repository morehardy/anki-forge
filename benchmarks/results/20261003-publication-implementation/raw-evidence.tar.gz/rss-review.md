# 宽字段 RSS 验收阻塞

工作负载：1,000 条笔记，正反面各约 8 KiB；每格独立 3 个 RSS 进程。

| 场景 | 批次 | baseline MiB | candidate MiB | 增加 MiB | 允许增加 MiB |
|---|---:|---:|---:|---:|---:|
| manifest | 1 | 119.500 | 139.766 | 20.266 | 11.950 |
| combined | 1 | 119.031 | 139.375 | 20.344 | 11.903 |
| combined-reuse | 1 | 123.125 | 143.078 | 19.953 | 12.312 |
| manifest | 2 | 118.938 | 139.734 | 20.797 | 11.894 |
| combined | 2 | 119.250 | 139.531 | 20.281 | 11.925 |
| combined-reuse | 2 | 123.156 | 143.078 | 19.922 | 12.316 |

两个完整批次重复超过 spec 的 RSS 门槛，不能按原 spec 默认启用或宣布验收完成。计时目标均通过不抵消此项失败。

隔离诊断：高水位分歧在 Project 字段渲染时已经出现，早于 staging manifest 和 APKG inspection。系统分配器包装探针记录 baseline 的 Rust 存活分配峰值为 40,171,247 bytes，组合为 40,171,016 bytes，完成后的 Rust 存活量均为 20,675,031 bytes；该探针不统计 SQLite/zstd 内部 C 分配，而且自身会改变分配布局，不能用这些数字替换正式 RSS 样本。诊断支持分配器复用差异，不能证明所有平台无内存回归。

原始数据：core-batch1/summary.json、core-batch2/summary.json；诊断：rss-diagnosis/、live-diagnosis/。所有探针只存在于隔离源码，不进入产品。

待决策：继续遵守原门槛，保留候选但暂不默认启用；或显式修订 spec，接受本机宽字段场景约 20 MiB 的 RSS 增加，保留限制说明。其他功能、打包和性能控制组仍需完成。

补充控制：standalone compare 的 wide1k 也连续两批触发同类 RSS 门槛，第一批 122.141 → 142.906 MiB，第二批 122.672 → 142.859 MiB。这表明待决策范围包含 P1 变体的既有 compare 控制，不只 manifest/组合路径。
